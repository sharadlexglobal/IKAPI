# MASTER CODING PROMPT: AUTONOMOUS LEGAL RESEARCH PIPELINE
# Give this prompt to Claude to build the complete feature
# Version: 1.0 | Date: 28 February 2026

---

## WHAT YOU ARE BUILDING

You are adding a major new feature to an EXISTING Python Flask application called CourtCraft.ai. The existing app already has a working Indian Kanoon (IK) search interface. You are building an **Autonomous Legal Research Pipeline** — an end-to-end system where:

```
INPUT:  Litigation pleading text (writ petition, bail application, etc.)
                    ↓
STEP 1: QUESTION EXTRACTION (Claude API)
        Extract 80-120 legal research questions from the pleading
        using the Legal Research Question Extractor prompt
                    ↓
STEP 2: QUERY GENERATION (Claude API)
        Convert each research question into 3-7 Indian Kanoon 
        search queries using multi-strategy approach
                    ↓
STEP 3: SEARCH EXECUTION (Indian Kanoon API)
        Run all queries programmatically against IK API
        Deduplicate by document ID, rank by citation count
                    ↓
STEP 4: JUDGMENT FETCHING (Indian Kanoon API)
        Fetch full text of top-ranked judgments
        Cache everything in database
                    ↓
STEP 5: JUDGMENT GENOME EXTRACTION (Claude API)
        Extract structured JSON genome from each relevant judgment
        using the Judgment Genome Project prompt
                    ↓
STEP 6: SYNTHESIS & OUTPUT (Claude API)
        Combine extracted genomes + original pleading + research questions
        Generate final output (research memo, case matrix, arguments)
                    ↓
OUTPUT: Multiple formats — research memo, case law matrix, 
        supporting/opposing precedent lists, recommended arguments
```

This is a COMPLETE LOOP: Pleading → Questions → Search → Judgments → Extraction → Analysis → Back to Pleading.

---

## EXISTING APP ARCHITECTURE

The app is a Python Flask application with:
- **Backend**: Flask (Python 3.12+)
- **Frontend**: HTML/CSS/JS (Jinja2 templates), ultra-premium dark theme
- **Database**: PostgreSQL (for caching judgments — may or may not be implemented yet)
- **APIs Used**: Indian Kanoon API, Anthropic Claude API
- **Deployment**: Replit or similar cloud platform

### What Already Works:
1. Indian Kanoon search interface — text search with all operators (ANDD, ORR, NOTT, phrase search)
2. Field filters — doctypes, fromdate, todate, sortby, author, bench, title, cite
3. Smart Search — Claude Haiku converts natural language to IK query
4. Document viewer — displays judgment text
5. Search tips panel with examples
6. Input validation

### What You Are Adding:
The Autonomous Pipeline feature — a NEW route/page where a user can:
1. Paste or upload a litigation pleading
2. Click "Analyze" 
3. Watch the pipeline execute (with progress indicators)
4. See the results in a beautiful, structured interface

---

## THE THREE MASTER PROMPTS (Store as Python variables)

### PROMPT 1: LEGAL RESEARCH QUESTION EXTRACTOR

**Purpose:** Takes a litigation pleading and extracts legal research questions.

**Key characteristics:**
- Reads pleading using 6-step methodology (Prayer first, then Synopsis, then Questions of Law, then Facts for gaps, then Legal Submissions, then Annexures)
- Generates questions across 14 categories: Jurisdictional, Limitation, Statutory Interpretation, Constitutional, Substantive Merits, Procedural, Interim Relief, Evidence, Opposition Anticipation, Precedent Chain, Equitable, Court-Specific, Strategic, Cross-Statute
- Each question has: question_id, question text, why_this_matters, source_paragraphs, question_type (STRENGTHEN/ANTICIPATE/EXPOSE_GAP/JUDGE_CONCERN), perspective (ADVOCATE/OPPONENT/JUDGE), importance (CRITICAL/HIGH/MEDIUM/LOW), urgency, research_direction, sub_questions, fact_anchor, is_gate_question, depends_on
- Special category for Opposition Anticipation with: anticipated_argument, argument_strength, counter_strategy_direction, likelihood
- Decision tree with gate questions and dependency chains
- Priority matrix: must_research_before_hearing, important, good_to_know
- Summary with: top 5 case-winning questions, biggest vulnerability, what judge will ask first, senior advocate's note
- Output: JSON conforming to the Legal Research Questions Schema v2.0

**System prompt structure:**
```python
QUESTION_EXTRACTOR_SYSTEM_PROMPT = """[Role: Senior Advocate 60+ years]
[Reading Methodology: 6 steps — Prayer first...]
[Question Anatomy: 4 components — Legal proposition + Statutory anchor + Factual context + Answer format]
[14 Categories with prefixes: J_, LIM_, STAT_, CONST_, SUB_, PROC_, INT_, EVID_, OPP_, PREC_, EQ_, COURT_, STRAT_, CROSS_]
[3 Perspectives: ADVOCATE, OPPONENT, JUDGE]
[4 Question types: STRENGTHEN, ANTICIPATE, EXPOSE_GAP, JUDGE_CONCERN]
[Decision tree: gate questions + dependency chains]
[Output: JSON only, conforming to schema]"""
```

### PROMPT 2: SEARCH QUERY GENERATOR

**Purpose:** Takes extracted research questions and converts each into multiple Indian Kanoon search queries using multi-strategy approach.

**Key characteristics:**
- For each research question, generates 3-7 IK-compatible search queries
- Uses 6 strategies: Concept Decomposition, Synonym Expansion, Citation Chain seeds, Judge/Bench Targeting, Date-Bounded search, Statute-Specific search
- Every query must use correct IK syntax: ANDD, ORR, NOTT (case-sensitive, double letters), "phrase search" in double quotes
- Every query must include appropriate filters: doctypes, fromdate, todate, sortby
- Prioritizes queries: PRIMARY (must run), SECONDARY (run if time permits), EXPLORATORY (run for completeness)
- Groups queries by research question ID so results can be traced back

**System prompt structure:**
```python
QUERY_GENERATOR_SYSTEM_PROMPT = """You are a legal search engineer. 
Convert legal research questions into Indian Kanoon API search queries.

IK SYNTAX RULES:
- Boolean: ANDD, ORR, NOTT (case-sensitive, double letters, spaces required)
- Phrases: "exact phrase" in double quotes
- Filters: doctypes: <court>, fromdate: DD-MM-YYYY, todate: DD-MM-YYYY, sortby: mostrecent
- Field search: title: <keyword>, author: <judge>, bench: <judge>, cite: <citation>
- Available doctypes: supremecourt, highcourts, rajasthan, jodhpur, delhi, bombay, kolkata, chennai, drat, [all others]

MULTI-STRATEGY APPROACH:
For each question, generate:
1. PRIMARY query — direct legal terms + relevant court filter
2. SYNONYM query — alternative legal terminology for same concept
3. STATUTE query — specific section numbers + Act name
4. LANDMARK query — title: search for known landmark cases on point
5. RECENT query — same terms + fromdate filter for last 3 years + sortby: mostrecent
6. BROAD query — wider terms without court filter for maximum recall
7. CITATION query (if applicable) — cite: for known citations

Output: JSON array of query objects, each with:
  query_id, parent_question_id, strategy, formInput (the actual IK query string),
  priority (PRIMARY/SECONDARY/EXPLORATORY), expected_result_type
"""
```

### PROMPT 3: JUDGMENT GENOME EXTRACTOR

**Purpose:** Takes a judgment text and extracts the complete structured genome.

**Key characteristics:**
- 6 Dimensions: Visible, Structural, Invisible, Weaponizable, Synthesis, Audit
- Visible: case identity, story (plain + legal), procedural journey, provisions, precedents, ratio, obiter, operative order
- Structural: syllogisms (with chain logic), dependency tree (flat nodes), interpretive method, rhetorical architecture
- Invisible: hidden assumptions, silent arguments (with 3-step stress test), fact-sensitivity matrix, counterfactuals, alternative interpretations, doctrinal undercurrent
- Weaponizable: sword uses, shield uses, vulnerability map (with durability score 1-10), distinguishing playbook, cross-domain transplants (with Gate 7 validation), temporal vulnerability
- Synthesis: interpretive lineage map, genome summary (with consistency check), practitioner's cheat sheet (cite when / don't cite when / killer paragraph / hidden gem), questions created
- Audit: 12 checks (5 internal consistency + 3 statutory verification + 4 analytical claims) + final certification (COURT_USE / RESEARCH_USE_ONLY / DRAFT)
- 7 Verification Gates embedded throughout
- Confidence markers: VERIFIED, SOUND_INFERENCE, SPECULATIVE, UNVERIFIED
- Output: JSON conforming to Judgment Genome Schema v3.1

---

## INDIAN KANOON API REFERENCE

### Authentication
```
All requests: POST with header "Authorization: Token <IK_API_TOKEN>"
```

### Endpoints

**Search:**
```
POST https://api.indiankanoon.org/search/
Params: formInput=<query>&pagenum=<n>&maxcites=<n>&maxpages=<n>
Returns: { docs: [{tid, title, headline, docsource, publishdate, numcites, numcitedby, citation, fragment, ...}] }
```

**Document Full Text:**
```
POST https://api.indiankanoon.org/doc/<tid>/
Params: maxcites=<n>&maxcitedby=<n>
Returns: { doc: "<html>", title, tid, ... , citeList: [...], citedbyList: [...] }
```

**Document Fragment (Relevant Paragraphs Only):**
```
POST https://api.indiankanoon.org/docfragment/<tid>/?formInput=<query>
Returns: { headline: ["<para1>", "<para2>"], title, tid }
```

**Document Metadata (Lightweight):**
```
POST https://api.indiankanoon.org/docmeta/<tid>/
Returns: { tid, publishdate, doctype, title, numcites, numcitedby }
```

### Available Court Filters (doctypes)
- Supreme Court: `supremecourt`
- All High Courts: `highcourts` (or specific: `rajasthan`, `jodhpur`, `delhi`, `bombay`, `kolkata`, `chennai`, `allahabad`, `andhra`, `chattisgarh`, `gauhati`, `gujarat`, `himachal_pradesh`, `jharkhand`, `karnataka`, `kerala`, `madhyapradesh`, `orissa`, `patna`, `punjab`, `sikkim`, `uttaranchal`, `lucknow`, `meghalaya`, `kolkata_app`, `jammu`, `srinagar`)
- All Judgments: `judgments`
- Tribunals: `drat`, `cat`, `itat`, `consumer`, `greentribunal`, `cci`, `tdsat`, `aptel`, `cegat`, `stt`, `cerc`, `cic`, `clb`, `copyrightboard`, `ipab`, `mrtp`, `sebisat`, `trademark`
- All Tribunals: `tribunals`
- District Courts: `delhidc`
- Laws: `laws`

### IK Query Syntax
```
# Boolean (CASE-SENSITIVE, double letters, spaces required)
murder ANDD kidnapping
murder ORR kidnapping  
murder ANDD NOTT kidnapping

# Phrase
"freedom of speech"

# Combined
"right to privacy" ANDD "article 21" ANDD NOTT "public interest"

# With filters
"section 21" ANDD "pre-deposit" doctypes: supremecourt,drat fromdate: 01-01-2020 sortby: mostrecent

# Field search
title: kesavananda
author: chandrachud
bench: nariman
cite: 1993 AIR 2178
```

---

## BACKEND ARCHITECTURE TO BUILD

### New Files to Create:

```
pipeline/
├── __init__.py
├── config.py              # All 3 master prompts as Python variables
│                           # API config (Anthropic, IK)
│                           # JSON schemas as variables
│
├── question_extractor.py   # Step 1: Pleading → Research Questions
│   ├── extract_questions(pleading_text, citation) → QuestionsJSON
│   └── Uses QUESTION_EXTRACTOR_SYSTEM_PROMPT
│
├── query_generator.py      # Step 2: Research Questions → IK Search Queries
│   ├── generate_queries(questions_json) → List[IKQuery]
│   └── Uses QUERY_GENERATOR_SYSTEM_PROMPT
│
├── search_executor.py      # Step 3: Execute queries against IK API
│   ├── execute_queries(queries) → SearchResults
│   ├── deduplicate_results(results) → DeduplicatedResults
│   ├── rank_by_citations(results) → RankedResults
│   └── Uses IK API directly (no LLM)
│
├── judgment_fetcher.py     # Step 4: Fetch full text of top judgments
│   ├── fetch_judgments(ranked_results, top_n=30) → List[JudgmentText]
│   ├── cache_judgment(tid, text, metadata) → None
│   ├── get_cached_judgment(tid) → JudgmentText | None
│   └── Uses IK API + database cache
│
├── genome_extractor.py     # Step 5: Judgment → Structured Genome JSON
│   ├── extract_genome(judgment_text, citation) → GenomeJSON
│   └── Uses JUDGMENT_GENOME_SYSTEM_PROMPT
│
├── synthesizer.py          # Step 6: Combine everything → Final output
│   ├── synthesize_research(pleading, questions, genomes) → ResearchMemo
│   ├── generate_case_matrix(genomes, questions) → CaseMatrix
│   ├── generate_arguments(genomes, questions, side="petitioner") → Arguments
│   └── Uses Claude API with synthesis prompts
│
├── pipeline_orchestrator.py # Main orchestrator — runs Steps 1-6 in sequence
│   ├── run_pipeline(pleading_text, options) → PipelineResult
│   ├── Manages progress callbacks for frontend
│   ├── Handles errors at each step gracefully
│   └── Returns partial results if any step fails
│
└── models.py               # Data classes / Pydantic models
    ├── PleadingInput
    ├── ResearchQuestion
    ├── IKQuery
    ├── SearchResult
    ├── JudgmentGenome
    ├── PipelineResult
    └── PipelineProgress
```

### New Routes to Add to Existing app.py:

```python
# ── Pipeline Routes ────────────────────────────────
@app.route("/pipeline")
def pipeline_page():
    """Serve the pipeline frontend page."""

@app.route("/api/pipeline/start", methods=["POST"])
def pipeline_start():
    """Start the pipeline. Accepts {pleading_text, citation, options}.
    Returns {pipeline_id} immediately. Processing happens async."""

@app.route("/api/pipeline/status/<pipeline_id>")
def pipeline_status(pipeline_id):
    """Returns current progress: {step, progress_pct, message, partial_results}"""

@app.route("/api/pipeline/result/<pipeline_id>")
def pipeline_result(pipeline_id):
    """Returns the full result once pipeline completes."""

@app.route("/api/pipeline/questions/<pipeline_id>")
def pipeline_questions(pipeline_id):
    """Returns just the extracted questions (Step 1 result)."""

@app.route("/api/pipeline/genomes/<pipeline_id>")
def pipeline_genomes(pipeline_id):
    """Returns just the judgment genomes (Step 5 result)."""
```

### API Key Management:
```python
# Environment variables
ANTHROPIC_API_KEY = os.environ.get("ANTHROPIC_API_KEY")
IK_API_TOKEN = os.environ.get("IK_API_TOKEN")

# Anthropic: Used for Steps 1, 2, 5, 6
# IK API: Used for Steps 3, 4
```

### Rate Limiting & Cost Control:
```python
# IK API: Respect rate limits (check IK documentation)
# Anthropic API: 
#   - Step 1 (Question extraction): 1 call, ~30K output tokens
#   - Step 2 (Query generation): 1 call, ~10K output tokens
#   - Step 5 (Genome extraction): 1 call PER JUDGMENT — this is the expensive step
#     Limit to top 10-15 judgments to control costs
#   - Step 6 (Synthesis): 1-3 calls, ~20K output tokens
# 
# Total per pipeline run: ~15-20 API calls, ~200-300K tokens
# 
# Cost optimization:
#   - Cache everything — never re-fetch a judgment, never re-extract a genome
#   - Use docfragment first to validate relevance before full fetch
#   - Use docmeta for lightweight filtering
#   - Batch where possible
```

---

## FRONTEND ARCHITECTURE

### Design System (MUST follow):
- **Theme**: Dark mode, same as existing app
- **Color palette**: 
  - Background: #06080f (deep), #0d1117 (surface)
  - Accent colors per pipeline step:
    - Step 1 (Questions): Electric Teal #00e8b8
    - Step 2 (Queries): Lavender Indigo #818cf8
    - Step 3 (Search): Solar Amber #fbbf24
    - Step 4 (Fetch): Coral Rose #fb7185
    - Step 5 (Genome): Electric Violet #c084fc
    - Step 6 (Synthesis): Neon Cyan #22d3ee
- **Fonts**: Outfit (headings), DM Sans (body), JetBrains Mono (code/data)
- **Feel**: Ultra-modern, lively, 7-star premium — NOT luxurious/gold, but vibrant/electric

### Pipeline Page Layout:

```
┌─────────────────────────────────────────────────────────┐
│ HEADER (existing app header)                            │
├─────────────────────────────────────────────────────────┤
│                                                         │
│  INPUT SECTION (when pipeline not running)               │
│  ┌─────────────────────────────────────────────────┐    │
│  │ Citation: [____________]  Type: [Writ Petition ▼]│    │
│  │                                                   │    │
│  │ [Paste litigation pleading text here...          ]│    │
│  │ [                                                ]│    │
│  │ [                                                ]│    │
│  │                                                   │    │
│  │ [▶ Run Pipeline]  [Options ▼]   3,456 chars      │    │
│  └─────────────────────────────────────────────────┘    │
│                                                         │
│  PROGRESS SECTION (when pipeline is running)             │
│  ┌─────────────────────────────────────────────────┐    │
│  │ ● Step 1: Extracting Questions    ████████░░ 80% │    │
│  │ ○ Step 2: Generating Queries      ░░░░░░░░░░  0% │    │
│  │ ○ Step 3: Searching Judgments     ░░░░░░░░░░  0% │    │
│  │ ○ Step 4: Fetching Full Text      ░░░░░░░░░░  0% │    │
│  │ ○ Step 5: Extracting Genomes      ░░░░░░░░░░  0% │    │
│  │ ○ Step 6: Synthesizing Research   ░░░░░░░░░░  0% │    │
│  └─────────────────────────────────────────────────┘    │
│                                                         │
│  RESULTS SECTION (when pipeline completes)               │
│  ┌─────────────────────────────────────────────────┐    │
│  │ [Questions] [Judgments] [Genomes] [Research Memo] │    │
│  │ [Case Matrix] [Arguments] [Download All ↓]       │    │
│  │                                                   │    │
│  │ (Tab content rendered based on selection)          │    │
│  └─────────────────────────────────────────────────┘    │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

### Results Tabs:

**Tab 1: Questions** — Shows the extracted research questions grouped by category, with gate questions highlighted, priority matrix shown as a kanban board (MUST RESEARCH / IMPORTANT / GOOD TO KNOW)

**Tab 2: Judgments Found** — Shows the ranked list of judgments found through search, with citation count, court, date, relevance score. Click to expand and see the judgment text.

**Tab 3: Genomes** — Shows the extracted genome for each judgment. Same UI as the Judgment Genome viewer (dimension tabs, cheat sheet first, etc.)

**Tab 4: Research Memo** — The synthesized research memo organized by legal issue, with case citations and key holdings.

**Tab 5: Case Matrix** — A table/grid: rows = legal issues (from questions), columns = judgments. Each cell shows whether the judgment supports/opposes/is neutral on that issue.

**Tab 6: Arguments** — Draft arguments organized by relief sought, with supporting authorities and page references.

---

## PIPELINE EXECUTION LOGIC (Detailed)

### Step 1: Question Extraction
```python
def extract_questions(pleading_text: str, pleading_type: str) -> dict:
    """
    Call Claude API with QUESTION_EXTRACTOR_SYSTEM_PROMPT.
    Input: raw pleading text + type (WRIT_PETITION, BAIL_APPLICATION, etc.)
    Output: JSON conforming to Legal Research Questions Schema v2.0
    
    Model: claude-sonnet-4-20250514 (or claude-opus-4-6 for highest quality)
    Max tokens: 30000
    Temperature: 0 (deterministic — legal precision required)
    """
```

### Step 2: Query Generation
```python
def generate_queries(questions_json: dict) -> list[dict]:
    """
    Call Claude API with QUERY_GENERATOR_SYSTEM_PROMPT.
    Input: The questions JSON from Step 1
    Output: List of IK query objects, each with:
      {
        query_id: "Q1_PRIMARY",
        parent_question_id: "J_1",
        strategy: "CONCEPT_DECOMPOSITION",
        formInput: "\"section 21\" ANDD \"waiver\" doctypes: supremecourt,drat sortby: mostrecent",
        priority: "PRIMARY",
        expected_doctypes: "supremecourt,drat"
      }
    
    IMPORTANT: 
    - Extract the TOP questions (CRITICAL + HIGH importance, MUST_RESEARCH urgency)
    - Generate queries only for the top 20-30 questions to control API costs
    - Each question gets 3-5 queries (not 7 for every question)
    - Total queries should be 60-100 per pipeline run
    """
```

### Step 3: Search Execution
```python
def execute_queries(queries: list[dict], ik_token: str) -> list[dict]:
    """
    Execute IK API searches. NO LLM involved — pure API calls.
    
    For each query:
    1. POST to https://api.indiankanoon.org/search/
       with formInput=query["formInput"]&pagenum=0&maxpages=3
    2. Parse response — extract docs array
    3. For each doc: store tid, title, numcitedby, publishdate, citation, fragment
    
    Then:
    4. Deduplicate across all queries by tid (same judgment found by multiple queries)
    5. For duplicates, merge: keep the judgment, note which queries found it
    6. Rank by numcitedby (descending) — most-cited = most authoritative
    7. Return top 50-100 unique results
    
    Rate limiting: 
    - Add 0.5s delay between API calls
    - If rate limited (HTTP 429), exponential backoff
    
    Error handling:
    - If a query fails, log it and continue with remaining queries
    - Return partial results even if some queries fail
    """
```

### Step 4: Judgment Fetching
```python
def fetch_judgments(ranked_results: list[dict], ik_token: str, top_n: int = 20) -> list[dict]:
    """
    Fetch full text of top-N ranked judgments.
    
    For each of the top_n results:
    1. Check cache — if judgment text is already cached, use it
    2. If not cached:
       a. First, call /docfragment/<tid>/?formInput=<original_query>
          to get just the relevant paragraphs
       b. If fragments look relevant, fetch full text via /doc/<tid>/
       c. Cache the full text + metadata
    3. Return list of {tid, title, full_text, metadata, relevant_fragments}
    
    Cost optimization:
    - docfragment is cheaper than full doc fetch
    - Only fetch full text for judgments whose fragments are relevant
    - Cache aggressively — never re-fetch
    """
```

### Step 5: Genome Extraction
```python
def extract_genomes(judgments: list[dict]) -> list[dict]:
    """
    For each judgment, call Claude API with JUDGMENT_GENOME_SYSTEM_PROMPT.
    
    This is the MOST EXPENSIVE step — one API call per judgment.
    
    Cost control:
    - Limit to top 10-15 judgments (by citation count)
    - For judgments ranked 15-30, extract only Dimensions 1 and 5 
      (Visible + Synthesis) — skip the deep analysis
    - Use claude-sonnet-4-20250514 (not Opus) for cost efficiency
    - Max tokens: 16000 per extraction (trimmed genome)
    
    For each judgment:
    1. Send judgment text + GENOME_SYSTEM_PROMPT to Claude
    2. Parse JSON response
    3. Store genome in cache/database
    4. Return list of genomes
    
    Error handling:
    - If extraction fails for one judgment, log and continue
    - Return partial results
    """
```

### Step 6: Synthesis
```python
def synthesize(pleading_text: str, questions: dict, genomes: list[dict]) -> dict:
    """
    The final synthesis — combine everything into usable output.
    
    Call Claude API with a SYNTHESIS prompt that receives:
    - The original pleading (summarized to save tokens)
    - The extracted questions (top 20)
    - The extracted genomes (key fields only — ratio, cheat sheet, vulnerability)
    
    Generate:
    1. Research Memo — organized by legal issue, with citations
    2. Case Matrix — issue vs. judgment grid
    3. Supporting Precedents — cases that help the client
    4. Opposing Precedents — cases the opponent may cite
    5. Recommended Arguments — draft arguments with authorities
    
    Model: claude-sonnet-4-20250514
    Max tokens: 20000
    """
```

---

## CRITICAL IMPLEMENTATION RULES

### Rule 1: Store All Prompts as Variables
Every prompt component must be a Python variable in config.py — NEVER hardcoded in route handlers or service functions. This enables:
- Version control of prompts
- A/B testing of prompt variants
- Easy updates without code changes

### Rule 2: Every API Call Must Be Wrapped
```python
# Pattern for every Claude API call:
def call_claude(system_prompt: str, user_message: str, max_tokens: int) -> dict:
    """Centralized Claude API caller with:
    - Retry logic (3 attempts with exponential backoff)
    - Timeout handling (300s default)
    - JSON extraction from response (strip markdown fences)
    - Error classification (rate limit vs. timeout vs. other)
    - Logging with request ID
    """
```

### Rule 3: Every IK API Call Must Be Wrapped
```python
# Pattern for every IK API call:
def call_ik_api(endpoint: str, params: dict, ik_token: str) -> dict:
    """Centralized IK API caller with:
    - Rate limiting (0.5s between calls)
    - Retry logic (3 attempts)
    - Response validation
    - Cache check before call
    - Logging
    """
```

### Rule 4: Pipeline Must Be Resumable
If any step fails, the pipeline should:
- Save the results of all completed steps
- Allow resuming from the failed step
- Return partial results to the frontend

### Rule 5: Frontend Must Show Progress
The pipeline takes 5-15 minutes. The frontend must:
- Show which step is currently executing
- Show progress within each step (e.g., "Searching: 23/67 queries complete")
- Show partial results as they become available (questions available after Step 1)
- Allow the user to view completed steps while later steps are still running

### Rule 6: Cost Visibility
The frontend should show estimated cost/token usage for each step, so the user understands the resource consumption.

---

## JSON SCHEMAS (Summary — Store full schemas in separate files)

### Schema 1: Legal Research Questions v2.0
Top-level keys: document_id, schema_version, extraction_metadata, case_context, question_categories (14 categories), decision_tree, priority_matrix, extraction_summary
Question object: question_id, question, sub_questions[], why_this_matters, source_paragraphs, fact_anchor, question_type, perspective, importance, urgency, is_gate_question, depends_on, research_direction, expected_research_output, linked_relief_ids, linked_statute_sections
Anticipatory object: question_id, anticipated_argument, argument_strength, research_question, counter_strategy_direction, vulnerability_in_own_pleading, likelihood

### Schema 2: IK Query Set
Top-level keys: source_pipeline_id, source_questions_id, generated_at, queries[]
Query object: query_id, parent_question_id, strategy, formInput, priority, expected_doctypes, expected_result_type

### Schema 3: Search Results (Deduplicated & Ranked)
Top-level keys: pipeline_id, total_queries_run, total_results, unique_results, ranked_results[]
Result object: tid, title, numcitedby, publishdate, court, citation, found_by_queries[], relevance_reasons[], rank

### Schema 4: Judgment Genome v3.1
(Full schema as previously defined — 6 dimensions, 384 fields, 285 required constraints)

### Schema 5: Pipeline Output
Top-level keys: pipeline_id, status, started_at, completed_at, pleading_summary, questions, queries_generated, search_results, judgments_fetched, genomes_extracted, synthesis (research_memo, case_matrix, supporting_precedents, opposing_precedents, recommended_arguments)

---

## WHAT TO BUILD FIRST (Implementation Order)

```
PHASE 1: Core Pipeline (Backend)
  1. pipeline/config.py — All prompts + schemas as variables
  2. pipeline/models.py — Data classes
  3. pipeline/question_extractor.py — Step 1
  4. pipeline/query_generator.py — Step 2  
  5. pipeline/search_executor.py — Step 3
  6. pipeline/judgment_fetcher.py — Step 4
  7. pipeline/genome_extractor.py — Step 5
  8. pipeline/synthesizer.py — Step 6
  9. pipeline/pipeline_orchestrator.py — Orchestrator

PHASE 2: API Routes
  10. Add pipeline routes to app.py
  11. Implement async execution (threading or background tasks)
  12. Implement progress tracking

PHASE 3: Frontend
  13. Pipeline page template (input + progress + results)
  14. Results tabs (questions, judgments, genomes, memo, matrix, arguments)
  15. Progress indicators with step-by-step animation
  16. Download/export functionality

PHASE 4: Polish
  17. Error handling for all edge cases
  18. Cost estimation display
  19. Caching layer (PostgreSQL or SQLite)
  20. Testing
```

---

## THE BIG PICTURE

This pipeline transforms CourtCraft from a "search tool" into a "legal intelligence engine." The input is a raw litigation document. The output is a complete research package that would take a team of junior lawyers a week to prepare manually. The system does it in 10-15 minutes.

The loop is:
```
PLEADING → QUESTIONS → SEARCH QUERIES → JUDGMENTS → GENOMES → SYNTHESIS → BACK TO PLEADING
```

Every step is powered by a carefully crafted prompt (for LLM steps) or a well-structured API integration (for IK steps). Every intermediate result is structured JSON. Every output is verifiable and traceable back to source paragraphs and judgment citations.

This is not a chatbot. This is an autonomous legal research agent.

---

*CourtCraft.ai — Autonomous Legal Research Pipeline*
*Master Coding Prompt v1.0*
