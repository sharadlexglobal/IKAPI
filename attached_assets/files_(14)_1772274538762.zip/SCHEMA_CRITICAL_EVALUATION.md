# CRITICAL EVALUATION: Judgment Genome JSON Schema v3.0
# Shortcomings, Gaps & Fixes

---

## EXECUTIVE SUMMARY

**Technical Validity:** The schema is syntactically valid JSON Schema draft-07. All 
`$ref` references resolve. All `required` fields exist in their `properties` blocks. 
All arrays have `items` definitions. No broken nullable types.

**However, 14 shortcomings found across 4 categories:**

| Category | Count | Severity Range |
|----------|-------|---------------|
| Prompt ↔ Schema Mapping Gaps (Missing Fields) | 5 | MEDIUM to HIGH |
| Data Modeling / Structural Flaws | 4 | MEDIUM to HIGH |
| Production-Readiness Issues | 3 | MEDIUM to HIGH |
| Minor / Cosmetic Issues | 2 | LOW |

---

## SHORTCOMING 1: Missing `source_paragraph` on Multiple Objects
### Severity: HIGH | Category: Prompt ↔ Schema Gap

**The Problem:**
The v3.0 prompt's Gate 1 (Source Traceability) mandates that EVERY factual claim 
must cite a ¶ number. But several schema objects are missing `source_paragraph`:

- `dimension_1_visible.case_identity` — No `source_paragraph` on any field. 
  Where did the case name, court, bench come from?
- `dimension_2_structural.rhetorical_architecture` — No `source_paragraph` on 
  `opening_move`, `persuasion_technique`, `tone`.
- `dimension_3_invisible.doctrinal_undercurrent.doctrines[]` — Has `source_paragraphs` 
  (good), but `tensions[]` has no `source_paragraph`.
- `dimension_4_weaponizable.shield_uses[]` — No `source_paragraph`.
- `dimension_4_weaponizable.distinguishing_playbook[]` — No `source_paragraph`.

**The Fix:**
Add `"source_paragraph": { "type": ["string", "null"] }` to every object that 
makes a claim traceable to the judgment text. For objects that are analytical 
(not directly from judgment), use `null` to indicate inference.

---

## SHORTCOMING 2: `syllogism.feeds_into` — Wrong Cardinality
### Severity: MEDIUM | Category: Data Modeling

**The Problem:**
`feeds_into` is typed as `["string", "null"]` — meaning a syllogism can only 
feed into ONE other syllogism. But in practice, a single syllogism's conclusion 
can feed into MULTIPLE downstream syllogisms. For example, "No false document" 
(Syllogism 1's conclusion) feeds into both the forgery chain AND may inform 
the cheating analysis indirectly.

**The Fix:**
```json
"feeds_into": {
  "type": "array",
  "items": { "type": "string" },
  "description": "IDs of syllogisms this conclusion feeds into"
}
```

---

## SHORTCOMING 3: `load_bearing_facts` — Single Syllogism Reference
### Severity: MEDIUM | Category: Data Modeling

**The Problem:**
`dependent_syllogism_id` is a single string. But a single load-bearing fact 
may be critical to MULTIPLE syllogisms. For example, "accused signed in his 
own name" is load-bearing for both the forgery syllogism AND the cheating 
syllogism (since impersonation affects both analyses).

**The Fix:**
```json
"dependent_syllogism_ids": {
  "type": "array",
  "items": { "type": "string" },
  "description": "IDs of ALL syllogisms from 2.1 that depend on this fact"
}
```

---

## SHORTCOMING 4: No `provisions_engaged` ↔ BNS/New Statute Cross-Reference
### Severity: HIGH | Category: Prompt ↔ Schema Gap

**The Problem:**
The v3.0 prompt's Gate 5 (Cross-Statutory Mapping) requires mapping old provisions 
to new ones (IPC → BNS). The schema captures this in `dimension_4_weaponizable.
temporal_vulnerability.cross_statutory_mapping` — but ONLY there.

The `provisions_engaged` array (Section 1.4) has NO field for the corresponding 
new provision. This means:
- A downstream system querying "what is the BNS equivalent of Section 464 IPC?" 
  cannot get the answer from the provisions list
- The mapping is buried in Dimension 4 instead of being attached to the provision 
  itself where it logically belongs
- There's no single source of truth — the mapping exists in one place but the 
  provision exists in another

**The Fix:**
Add to `provisions_engaged[]`:
```json
"corresponding_new_provision": {
  "type": ["object", "null"],
  "description": "Gate 5 — If the parent statute has been repealed/replaced",
  "properties": {
    "new_provision_id": { "type": "string" },
    "new_parent_statute": { "type": "string" },
    "verification_status": {
      "type": "string",
      "enum": ["VERIFIED", "UNVERIFIED_REQUIRES_CONFIRMATION"]
    },
    "language_status": {
      "type": "string",
      "enum": ["IDENTICAL", "SUBSTANTIALLY_SIMILAR", "MODIFIED", "UNKNOWN"]
    }
  }
}
```

---

## SHORTCOMING 5: `dependency_tree` — Recursive `$ref` Depth Problem
### Severity: MEDIUM-HIGH | Category: Production-Readiness

**The Problem:**
The `sub_dependencies` field uses a `$ref` pointing to itself — creating recursive 
nesting. While JSON Schema draft-07 technically allows this, it causes practical 
problems:

1. **Serialization depth:** Most JSON parsers have a max recursion depth. A complex 
   Constitution Bench judgment could have 5-6 levels of nested dependencies.
2. **LLM output:** Language models struggle with deeply recursive JSON structures. 
   They tend to either truncate or produce invalid nesting after 3-4 levels.
3. **Database storage:** Recursive structures don't map cleanly to relational 
   databases or even document stores without special handling.

**The Fix:**
Replace recursive nesting with a FLAT structure using parent references:
```json
"dependency_tree": {
  "type": "object",
  "properties": {
    "root_node": { "type": "string" },
    "nodes": {
      "type": "array",
      "items": {
        "type": "object",
        "required": ["node_id", "premise", "type", "is_critical"],
        "properties": {
          "node_id": { "type": "string" },
          "parent_node_id": { 
            "type": ["string", "null"], 
            "description": "null for root-level nodes" 
          },
          "branch_id": { "type": "string" },
          "premise": { "type": "string" },
          "type": { "type": "string", "enum": [...] },
          "is_critical": { "type": "boolean" },
          "source_paragraph": { "type": ["string", "null"] }
        }
      }
    }
  }
}
```
This is flat, database-friendly, and LLM-friendly while preserving the full 
tree structure through `parent_node_id` references.

---

## SHORTCOMING 6: No Unique ID / Primary Key Convention
### Severity: HIGH | Category: Production-Readiness

**The Problem:**
The schema uses `_id` fields inconsistently:
- `syllogism_id` uses "SYL_1" format
- `ratio_id` uses "RATIO_1" format
- `assumption_id`, `argument_id`, `cf_id`, `alt_id`, `vuln_id` etc. — 
  all use different ID patterns

But there is NO:
- Enforced format pattern (regex) on any ID field
- Global uniqueness constraint across the document
- Namespace convention to prevent ID collisions between sections (what if a 
  `SYL_1` and a `CF_1` both exist and a downstream system confuses them?)

When processing at scale (thousands of judgments), ID collisions across 
documents will cause data integrity issues.

**The Fix:**
Add a consistent ID convention with namespace prefixes and document-level 
uniqueness:
```json
"syllogism_id": {
  "type": "string",
  "pattern": "^SYL_[0-9]+$",
  "description": "Unique within this extraction. Format: SYL_1, SYL_2..."
},
"ratio_id": {
  "type": "string", 
  "pattern": "^RATIO_[0-9]+$"
},
"assumption_id": {
  "type": "string",
  "pattern": "^HA_[0-9]+$"
},
"argument_id": {
  "type": "string",
  "pattern": "^SA_[0-9]+$"
}
```

And add a top-level document ID:
```json
"document_id": {
  "type": "string",
  "description": "Globally unique extraction ID, e.g., UUID or citation-hash"
}
```

---

## SHORTCOMING 7: `genome_summary` Has No Consistency Verification Field
### Severity: MEDIUM | Category: Prompt ↔ Schema Gap

**The Problem:**
The v3.0 prompt says: "After writing the summary, cross-check EVERY factual and 
legal claim in it against the relevant section of the extraction. The summary must 
be CONSISTENT with Sections 1.6, 2.1, 3.1, 4.3, and 4.6."

But the schema's `genome_summary` is just a bare string with a `minLength`. There 
is no field to record whether the consistency check was performed or what sections 
were verified against.

**The Fix:**
```json
"genome_summary": {
  "type": "object",
  "required": ["text", "consistency_verified_against"],
  "properties": {
    "text": { 
      "type": "string", 
      "minLength": 200 
    },
    "consistency_verified_against": {
      "type": "array",
      "items": { "type": "string" },
      "description": "List of sections verified, e.g., ['1.6', '2.1', '3.1', '4.3', '4.6']"
    },
    "consistency_check_passed": { "type": "boolean" }
  }
}
```

---

## SHORTCOMING 8: Missing `obiter_dicta` Classification Rigor
### Severity: MEDIUM | Category: Prompt ↔ Schema Gap

**The Problem:**
The v3.0 prompt says: "For each obiter, confirm: 'Is this observation NECESSARY for 
the decision, or is it an aside?' If it's necessary, it's ratio, not obiter. 
Re-classify."

But the schema's `obiter_dicta[]` object has no field to record this verification. 
There's no machine-readable indicator that the obiter was tested against the 
ratio/obiter boundary.

**The Fix:**
Add to `obiter_dicta[]`:
```json
"necessity_check": {
  "type": "object",
  "required": ["is_necessary_for_decision", "verified"],
  "properties": {
    "is_necessary_for_decision": { 
      "type": "boolean", 
      "description": "If true, this should be reclassified as ratio" 
    },
    "verified": { "type": "boolean" }
  }
}
```

---

## SHORTCOMING 9: `alternative_method_analysis` Doesn't Show Steps
### Severity: MEDIUM | Category: Prompt ↔ Schema Gap

**The Problem:**
The prompt explicitly says: "you must actually APPLY the alternative method to 
the provision and walk through the analysis. Don't just assert 'purposive 
interpretation would change the outcome.' Show the steps."

But the schema's `alternative_method_analysis[].analysis` is a single string. 
There's no structured format to ensure the analysis actually walks through 
step-by-step application rather than making a bare assertion.

**The Fix:**
```json
"analysis_steps": {
  "type": "array",
  "items": { "type": "string" },
  "minItems": 2,
  "description": "Step-by-step application of the alternative method. Minimum 2 steps."
},
"analysis_narrative": {
  "type": "string",
  "description": "Full narrative of the alternative method analysis"
}
```
Replace the bare `analysis` string with both fields. The `analysis_steps` array 
with `minItems: 2` enforces that the analysis actually shows steps.

---

## SHORTCOMING 10: No `maxItems` on Unbounded Arrays
### Severity: MEDIUM | Category: Production-Readiness

**The Problem:**
Several arrays have no `maxItems` constraint:
- `provisions_engaged` — A complex judgment could have 30+ provisions
- `precedent_registry` — A Constitution Bench judgment could cite 100+ cases
- `syllogisms` — Typically 3-8, but no upper bound
- `counterfactual_analysis` — Could theoretically be unlimited
- `sword_uses` — Could be unlimited

Without `maxItems`, an LLM could generate enormous arrays that:
(a) Blow context window limits
(b) Produce diminishing-quality items at the tail
(c) Create processing/storage issues at scale

**The Fix:**
Add reasonable `maxItems` based on practical legal limits:
```json
"provisions_engaged":       { "maxItems": 30 },
"precedent_registry":       { "maxItems": 50 },
"syllogisms.items":         { "maxItems": 15 },
"hidden_assumptions":       { "maxItems": 10 },
"silent_arguments":         { "maxItems": 8 },
"counterfactual_analysis":  { "maxItems": 8 },
"alternative_interpretations": { "maxItems": 5 },
"sword_uses":               { "maxItems": 8 },
"shield_uses":              { "maxItems": 5 },
"vulnerabilities":          { "maxItems": 8 },
"distinguishing_playbook":  { "maxItems": 6 },
"cross_domain_transplants": { "maxItems": 5 },
"questions_created":        { "maxItems": 8 }
```

---

## SHORTCOMING 11: `operative_order.order_items[].action` Enum Incomplete
### Severity: LOW-MEDIUM | Category: Data Modeling

**The Problem:**
The `action` enum is:
```
SET_ASIDE, QUASHED, LEFT_UNDISTURBED, ALLOWED, DISMISSED, REMANDED, 
DIRECTED, MODIFIED, OTHER
```

Missing common judicial actions:
- `UPHELD` — Higher court upholding lower court's order
- `CONFIRMED` — Confirming an interim order
- `STAYED` — Staying operation of an order
- `COMMUTED` — Commuting a sentence
- `ENHANCED` — Enhancing a sentence
- `RESTORED` — Restoring an earlier order
- `REFERRED` — Referring to a larger bench

**The Fix:**
Expand the enum to include all common operative actions, or change to 
`"type": "string"` without an enum (since judicial orders are too diverse 
for a closed set), and add a `"pattern"` for format consistency instead.

---

## SHORTCOMING 12: No Versioning / Migration Path
### Severity: MEDIUM | Category: Production-Readiness

**The Problem:**
The schema has `"schema_version": "3.0.0"` as a `const`, but there is:
- No mechanism for backward compatibility with v2.0 extractions
- No migration path if the schema evolves to v3.1 or v4.0
- No `additionalProperties: false` at the top level to prevent undeclared 
  fields from silently appearing

If CourtCraft deploys this and later needs to add a field (say, `bhns_mapping` 
or `ai_model_used`), existing extractions will fail validation against the 
new schema unless migration is planned.

**The Fix:**
1. Add `"additionalProperties": false` at every object level where strict 
   validation is needed (at least top-level and Dimension 6 audit).
2. Use semantic versioning properly — `schema_version` should be a string 
   field, not a `const`, so older documents can coexist:
```json
"schema_version": {
  "type": "string",
  "pattern": "^[0-9]+\\.[0-9]+\\.[0-9]+$",
  "description": "Semantic version of the schema this document conforms to"
}
```
3. Document breaking vs. non-breaking changes in a CHANGELOG.

---

## SHORTCOMING 13: `strategic_ambiguity` Nested Inside Optional Object
### Severity: LOW | Category: Data Modeling

**The Problem:**
`rhetorical_architecture` itself is not required (it has no `required` array 
for its own properties). This means the entire rhetorical analysis — including 
the important `strategic_ambiguity` with its `ambiguity_type` enum — can be 
silently omitted.

The prompt treats this as a meaningful analytical section, not optional filler.

**The Fix:**
Add `"required"` to `rhetorical_architecture`:
```json
"required": ["opening_move", "persuasion_technique", "tone"]
```
`strategic_ambiguity` can remain optional (nullable) since not all judgments 
have it.

---

## SHORTCOMING 14: No Search / Index Guidance
### Severity: LOW | Category: Production-Readiness

**The Problem:**
At scale (thousands of judgments), you'll need to SEARCH across extractions. 
The schema doesn't indicate which fields should be indexed for search:
- `case_identity.case_name` — text search
- `provisions_engaged[].provision_id` — exact match / faceted search
- `domain` — faceted search
- `ratio_decidendi[].proposition` — full-text / semantic search
- `practitioners_cheat_sheet.cite_when[]` — semantic search
- `overall_durability_score` — range query
- `certification_level` — faceted filter

**The Fix:**
Add a top-level `_search_hints` object (not validated, but guiding downstream 
indexing):
```json
"_search_hints": {
  "type": "object",
  "description": "Non-validated hints for search engine indexing",
  "properties": {
    "primary_text_search_fields": { ... },
    "facet_fields": { ... },
    "range_query_fields": { ... }
  }
}
```
Or document this separately in an INDEX_GUIDE alongside the schema.

---

# SUMMARY: ALL 14 SHORTCOMINGS

| # | Shortcoming | Severity | Category | Fix Complexity |
|---|-------------|----------|----------|---------------|
| 1 | Missing `source_paragraph` on 5+ objects | HIGH | Mapping Gap | LOW — add field |
| 2 | `feeds_into` wrong cardinality (string, should be array) | MEDIUM | Data Modeling | LOW — change type |
| 3 | `dependent_syllogism_id` single ref (should be array) | MEDIUM | Data Modeling | LOW — change type |
| 4 | No BNS cross-reference on `provisions_engaged` | HIGH | Mapping Gap | MEDIUM — add nested object |
| 5 | Recursive `$ref` in dependency tree | MEDIUM-HIGH | Production | HIGH — restructure to flat |
| 6 | No consistent ID convention / document_id | HIGH | Production | MEDIUM — add patterns + doc ID |
| 7 | `genome_summary` lacks consistency verification field | MEDIUM | Mapping Gap | LOW — wrap in object |
| 8 | `obiter_dicta` missing necessity check field | MEDIUM | Mapping Gap | LOW — add nested object |
| 9 | `alternative_method_analysis` doesn't enforce steps | MEDIUM | Mapping Gap | LOW — add array field |
| 10 | No `maxItems` on unbounded arrays | MEDIUM | Production | LOW — add constraints |
| 11 | `order_items.action` enum incomplete | LOW-MEDIUM | Data Modeling | LOW — expand or remove enum |
| 12 | No versioning / migration path | MEDIUM | Production | MEDIUM — design strategy |
| 13 | `rhetorical_architecture` properties not required | LOW | Data Modeling | LOW — add required |
| 14 | No search indexing guidance | LOW | Production | LOW — add hints |

---

# WHAT IS CORRECT AND SOLID

Despite the 14 shortcomings, the schema has strong fundamentals:

✅ **Complete Dimension coverage** — All 6 dimensions + metadata fully represented
✅ **Verification gates are embedded as required fields** — stress_test, gate_7, 
   statutory_structure_check are all mandatory nested objects, not optional
✅ **Confidence markers** are proper enums on every analytical claim
✅ **Audit dimension** is fully structured with all 12 checks + certification
✅ **Cross-references** between sections exist (ratio → syllogism, counterfactual 
   → syllogism, load-bearing fact → syllogism)
✅ **Enum constraints** are well-designed for controlled vocabularies
✅ **Nullable types** are correctly used for optional fields
✅ **All required/properties alignment** passes (no orphan required fields)
✅ **The $ref for recursive dependency** is valid (even though the approach needs 
   restructuring)
