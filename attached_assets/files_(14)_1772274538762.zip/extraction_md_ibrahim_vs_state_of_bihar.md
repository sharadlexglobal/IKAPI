# Structured Extraction: Md. Ibrahim & Ors vs State of Bihar & Anr

---

## SECTION 1: CASE IDENTITY

| Field | Details |
|---|---|
| **Case Name** | Md. Ibrahim & Ors vs State of Bihar & Anr |
| **Court** | Supreme Court of India |
| **Bench Composition** | 2 Judges — Justice R.V. Raveendran & Justice R.M. Lodha |
| **Date of Judgment** | 04-09-2009 |
| **Case Number** | Criminal Appeal No. 1695 of 2009 (Arising out of SLP [Crl.] No. 6211 of 2007) |
| **Case Type** | Criminal — Quashing of charges / Interpretation of forgery, cheating & related IPC provisions |
| **Judgment Author** | Justice R.V. Raveendran |
| **Dissenting Judges** | None — Unanimous |

---

## SECTION 2: FACTUAL MATRIX

### Background Facts

The second respondent (complainant) filed a complaint before the Chief Judicial Magistrate, Madhubani, alleging that the first accused (Md. Ibrahim) had no connection with or title to certain land (Katha No. 715, Khasra No. 1971 and 1973, measuring 1 bigha, 5 Katha, 18 Dhurs). Despite this, the first accused executed two registered sale deeds dated 02.06.2003 in favour of the second accused for a portion of the land (8 Khatas and 13 Dhurs). The third, fourth, and fifth accused were respectively the witness, scribe, and stamp vendor for the sale deeds, and were alleged to have conspired with accused 1 and 2 to forge the documents. When the complainant confronted accused 1 and 2, they allegedly abused him, hit him with fists, and told him he could do whatever he wanted but they would get possession based on the documents.

The first accused's counter-version was that the complainant and he were cousins; their grandfathers (Badri Mian and Mithu Mian) were brothers and co-owners of the plots. Through family arrangement, a portion came to Girja (first accused's mother), whose husband got it mutated in his name and paid land revenue. After the husband's death, the first accused inherited and bonafide sold a portion to the second accused.

### Specific Trigger

Execution and registration of two sale deeds dated 02.06.2003 by the first accused in favour of the second accused, over land claimed by the complainant.

### Procedural History

| Stage | Court | Outcome |
|---|---|---|
| **Complaint** | Chief Judicial Magistrate, Madhubani | Cognizance taken (19.07.2003) under Sections 323, 341, 420, 467, 471, 504 IPC; referred for investigation u/s 156(3) CrPC |
| **Investigation** | Pandaul Police Station | FIR registered (10.10.2003); Charge-sheet filed (04.09.2004) |
| **Discharge Application** | Sub-Divisional Magistrate, Madhubani | Rejected (14.12.2005) — sufficient material for framing charges |
| **Quashing Petition (s.482 CrPC)** | Patna High Court | Dismissed — upheld Magistrate's finding |
| **SLP → Criminal Appeal** | Supreme Court of India | **Allowed in part** — Charges under Sections 420, 467, 471, 504 quashed; Charges under Sections 323 and 341 left undisturbed |

### Key Factual Elements the Court Relied Upon

1. The first accused executed the sale deeds **in his own name, as himself** — he did not impersonate the complainant or claim to act on behalf of the complainant.
2. There was a rival claim of ownership — the first accused claimed inheritance through family arrangement, while the complainant claimed exclusive ownership.
3. The complainant was **not the purchaser** under the sale deeds — he was a third party claiming ownership of the land.
4. No allegation existed that the first accused pretended to be the complainant while executing the sale deeds.
5. The dispute was essentially about **title to land** — a civil dispute dressed in criminal clothing.
6. The confrontation between the parties (abusing and hitting) were the only elements that could technically constitute criminal offences (Sections 323 and 341).

---

## SECTION 3: LEGAL PROVISIONS AT PLAY

### Provision 1: Section 464 — Making a False Document (IPC)

| Field | Details |
|---|---|
| **Provision ID** | Section 464, Indian Penal Code |
| **Nature** | Statutory |
| **Parent Legislation** | Indian Penal Code, 1860 |
| **Role in This Case** | **Primary provision being interpreted** — The definitional foundation. The court's entire analysis of forgery hinges on whether the sale deeds constitute "false documents" under this section. |
| **Constitutional Harmony Check** | Not tested against any constitutional provision |

### Provision 2: Section 463 — Forgery (IPC)

| Field | Details |
|---|---|
| **Provision ID** | Section 463, Indian Penal Code |
| **Nature** | Statutory |
| **Parent Legislation** | Indian Penal Code, 1860 |
| **Role in This Case** | Supporting provision — Defines "forgery" which is the condition precedent for Sections 467 and 471. Court uses this as the conceptual umbrella. |
| **Constitutional Harmony Check** | Not applicable |

### Provision 3: Section 467 — Forgery of Valuable Security (IPC)

| Field | Details |
|---|---|
| **Provision ID** | Section 467, Indian Penal Code |
| **Nature** | Statutory |
| **Parent Legislation** | Indian Penal Code, 1860 |
| **Role in This Case** | Charged provision whose applicability is challenged — Carries imprisonment for life or up to 10 years |
| **Constitutional Harmony Check** | Not applicable |

### Provision 4: Section 471 — Using Forged Document as Genuine (IPC)

| Field | Details |
|---|---|
| **Provision ID** | Section 471, Indian Penal Code |
| **Nature** | Statutory |
| **Parent Legislation** | Indian Penal Code, 1860 |
| **Role in This Case** | Charged provision whose applicability is challenged — Dependent on existence of forgery |
| **Constitutional Harmony Check** | Not applicable |

### Provision 5: Section 415/420 — Cheating (IPC)

| Field | Details |
|---|---|
| **Provision ID** | Sections 415 and 420, Indian Penal Code |
| **Nature** | Statutory |
| **Parent Legislation** | Indian Penal Code, 1860 |
| **Role in This Case** | Charged provision whose applicability is challenged — Court examines whether a third-party (non-purchaser) can allege cheating in a sale transaction |
| **Constitutional Harmony Check** | Not applicable |

### Provision 6: Section 504 — Intentional Insult to Provoke Breach of Peace (IPC)

| Field | Details |
|---|---|
| **Provision ID** | Section 504, Indian Penal Code |
| **Nature** | Statutory |
| **Parent Legislation** | Indian Penal Code, 1860 |
| **Role in This Case** | Charged provision whose applicability is challenged |
| **Constitutional Harmony Check** | Not applicable |

### Provisions 7 & 8: Sections 323 & 341 — Causing Hurt & Wrongful Restraint (IPC)

| Field | Details |
|---|---|
| **Provision IDs** | Sections 323 and 341, Indian Penal Code |
| **Nature** | Statutory |
| **Parent Legislation** | Indian Penal Code, 1860 |
| **Role in This Case** | Charges sustained — The only provisions whose ingredients were technically made out on the facts alleged |
| **Constitutional Harmony Check** | Not applicable |

### Provision 9: Section 482 CrPC — Inherent Powers of High Court

| Field | Details |
|---|---|
| **Provision ID** | Section 482, Code of Criminal Procedure, 1973 |
| **Nature** | Statutory (Procedural) |
| **Parent Legislation** | Code of Criminal Procedure, 1973 |
| **Role in This Case** | Procedural provision — Jurisdictional basis for the High Court petition that was dismissed and led to this appeal |
| **Constitutional Harmony Check** | Not applicable |

---

## SECTION 4: THE INTERPRETIVE CORE

---

### PROVISION: Section 464 IPC — Making a False Document

---

#### 4A. Prior Interpretive Layers (Precedent Landscape)

##### Precedent 1: G. Sagar Suri v. State of U.P. [2000 (2) SCC 636]

| Field | Details |
|---|---|
| **Court & Bench Size** | Supreme Court of India (bench size not specified in judgment) |
| **What It Held** | Criminal courts should be vigilant against complaints that attempt to give a criminal colour to matters that are essentially civil in nature — used to harass or pressurize opponents. |
| **Interpretive Layer** | Established the principle of judicial gatekeeping against criminalization of civil disputes. |
| **Relationship to Current Case** | ☑ **RELIED UPON** — The court uses this as a foundational principle to frame its entire analysis. The case before it is examined through this lens of distinguishing genuine criminal conduct from civil disputes dressed in criminal garb. |

##### Precedent 2: Indian Oil Corporation vs. NEPC India Ltd. [2006 (6) SCC 736]

| Field | Details |
|---|---|
| **Court & Bench Size** | Supreme Court of India (bench size not specified in judgment) |
| **What It Held** | While courts should guard against misuse of criminal process for civil disputes, it must also be recognized that some civil disputes genuinely contain ingredients of criminal offences, and if so, must be tried as criminal offences. |
| **Interpretive Layer** | Added a balancing counter-principle — the civil-nature of a dispute does not automatically immunize it from criminal prosecution if criminal ingredients exist. |
| **Relationship to Current Case** | ☑ **RELIED UPON** — Used alongside G. Sagar Suri to establish the balanced framework: protect against misuse, but don't immunize genuine criminal conduct just because a civil dispute exists. |

##### Precedent 3: Dr. Vimla vs. Delhi Administration [AIR 1963 SC 1572]

| Field | Details |
|---|---|
| **Court & Bench Size** | Supreme Court of India (bench size not specified in judgment) |
| **What It Held** | The expression "defraud" involves two elements: (a) deceit, and (b) injury to the person deceived. Injury includes non-economic/non-pecuniary harm — harm to body, mind, reputation, etc. Even where there is benefit to the deceiver but no corresponding loss to the deceived, the second condition is satisfied. |
| **Interpretive Layer** | Defined the conceptual boundaries of "defraud" — expanded beyond mere economic loss to include all forms of injury. |
| **Relationship to Current Case** | ☑ **RELIED UPON** — Used in the clarification section (¶15) to explain that while a sale of another's property may involve fraud, the remedy lies with the defrauded purchaser, not a third-party complainant. |

##### Precedent 4: State of UP vs. Ranjit Singh [1999 (2) SCC 617]

| Field | Details |
|---|---|
| **Court & Bench Size** | Supreme Court of India (bench size not specified in judgment) |
| **What It Held** | Reiterated the definition of "defraud" as established in Dr. Vimla. |
| **Interpretive Layer** | Reaffirmation layer — cemented the Dr. Vimla definition as settled law. |
| **Relationship to Current Case** | ☑ **REAFFIRMED** — Mentioned briefly to confirm the Dr. Vimla definition remains good law. |

---

#### 4B. The New Interpretive Layer (Current Judgment's Contribution)

##### On Section 464 (Making a False Document / Forgery):

| Field | Details |
|---|---|
| **Interpretive Method** | ☑ **Literal / Plain Meaning** — The court performs a close textual analysis of Section 464, parsing its three categories word by word, and concludes that the plain language does not cover the factual scenario before it. |
| **New Interpretation** | The court establishes a **critical distinction** that constitutes the new interpretive layer: There is a **fundamental difference** between (a) a person executing a sale deed **claiming property is his own** (even if it isn't), and (b) a person executing a sale deed by **impersonating the owner** or **falsely claiming authorization** from the owner. Only category (b) constitutes a "false document" under Section 464. Category (a) — however dishonest — does not meet the statutory definition of forgery because the person is not claiming to be someone else, nor claiming authorization from someone else. He is making a false claim of ownership, which is different from making a false document. |
| **How It Relates to Existing Layers** | ☑ **CLARIFICATORY** — Resolves a recurring confusion in criminal practice where complaints of forgery are routinely filed against persons who sell property they don't own. The court draws a bright line that had not been explicitly articulated with this precision before. |

**Reasoning Chain:**

1. **Starting point:** Sections 467 and 471 require "forgery" as a condition precedent (¶8-9).
2. **Step down:** Forgery under Section 463 requires "making a false document" (¶9).
3. **Step down:** Section 464 defines three categories of "false document" (¶10).
4. **Category elimination:** The sale deeds clearly don't fall under the second category (alteration of document) or third category (deception of person of unsound mind/intoxication) (¶12).
5. **First category analysis:** The first category requires that the document was made with intention that it be believed the document was made by **some other person** or **by authority of some other person** (¶12).
6. **Application to facts:** The first accused executed sale deeds **in his own name** — he did not impersonate the complainant or claim to act on the complainant's behalf. He claimed the property was his. A false claim of ownership ≠ a false document (¶12).
7. **Conclusion:** No false document → No forgery → Sections 467 and 471 not attracted (¶12).

##### On Section 415/420 (Cheating):

| Field | Details |
|---|---|
| **Interpretive Method** | ☑ **Literal / Plain Meaning** — Ingredients of cheating examined against the complaint's allegations. |
| **New Interpretation** | When a sale deed is executed conveying property with a false claim of ownership, the **only person who can allege cheating is the purchaser** (who was induced to part with consideration based on a false representation of ownership). A **third party** claiming to be the true owner **cannot** allege cheating under Sections 415-420 because no deception was practiced upon him, no inducement was offered to him, and no property was delivered by him. The remedy of the third party lies in civil law (suit for declaration of title, injunction, recovery of possession), not in criminal law of cheating. |
| **How It Relates to Existing Layers** | ☑ **CLARIFICATORY** — Clarifies the standing/locus question in cheating complaints arising from property sale disputes. |

**Reasoning Chain:**

1. Cheating requires: deception of a person → fraudulent inducement to deliver property or act/omit → resulting damage (¶13).
2. Section 420 additionally requires dishonest inducement to deliver property or alter/destroy a valuable security (¶13).
3. The complainant is NOT the purchaser — the purchaser is a co-accused (¶14).
4. No accused tried to deceive the complainant, no inducement was offered to him, and the first accused did not impersonate the complainant (¶14).
5. Therefore, ingredients of cheating are absent vis-à-vis the complainant (¶14).

##### On Section 504 (Intentional Insult):

| Field | Details |
|---|---|
| **Interpretive Method** | ☑ **Literal / Plain Meaning** |
| **New Interpretation** | A statement by an accused asserting their legal position regarding consequences of a transaction (e.g., "we will get possession, do what you want") does not amount to "intentional insult with intent to provoke breach of peace" under Section 504. It is merely a statement of the perceived legal consequence of the sale deeds. |
| **How It Relates to Existing Layers** | ☑ **APPLICATIVE** — Applies existing understanding of Section 504 to a specific factual scenario without changing its meaning. |

---

##### The Clarification Layer (¶15-16): Fraud Without Offence

The court adds an important **obiter clarification**: merely showing that a person acted "fraudulently" does not automatically mean a criminal offence has been committed. The Penal Code does not make fraud per se an offence — it makes **specific fraudulent acts** offences (listed in ¶16 as thirteen categories). Therefore, a fraudulent act is punishable only if it falls within one of these specified categories.

---

## SECTION 5: RATIO DECIDENDI vs OBITER DICTA

### Ratio Decidendi

1. **On Forgery (Primary Ratio):** When a person executes a sale deed in his own name claiming a property as his own (even if the property does not belong to him), he is NOT making a "false document" within the meaning of Section 464 IPC, because he is neither claiming to be someone else nor claiming authorization from someone else. Therefore, such an act does not constitute forgery under Section 463, and consequently, neither Section 467 nor Section 471 IPC is attracted.

2. **On Cheating:** When a sale deed is executed with a false claim of ownership, the person who can allege cheating is the purchaser who was induced to part with consideration — not a third party claiming to be the true owner, upon whom no deception was practiced and to whom no inducement was offered.

3. **On Civil vs. Criminal:** Where the substance of a complaint reveals a dispute over title to property, and the complaint averments (even if assumed true) do not disclose the ingredients of the charged criminal offences, the criminal proceedings in respect of those charges must be quashed.

### Obiter Dicta

1. **Fraud vs. Criminal Offence (¶15-16):** The court observes that merely alleging or showing that a person acted fraudulently does not mean a criminal offence was committed. Fraud is not per se an offence under the Penal Code — only specific fraudulent acts enumerated in the Code constitute offences. This observation, while not strictly necessary for the decision, provides an important analytical framework for future cases.

2. **Purchaser's Remedy (¶15):** The court notes that if a person sells property knowing it doesn't belong to him and thereby defrauds the purchaser, the purchaser (not a third party) may have a complaint of cheating. This preserves the purchaser's criminal remedy while denying it to third parties.

3. **Criminal-Civil Overlap (¶7):** The court acknowledges that several civil disputes may also contain ingredients of criminal offences and must be tried as criminal cases. This prevents the judgment from being cited as a blanket bar against criminal proceedings in property disputes.

---

## SECTION 6: DISSENTING OPINION

**None.** The judgment is unanimous. Both Justice R.V. Raveendran and Justice R.M. Lodha concurred.

---

## SECTION 7: THE INTERPRETIVE LINEAGE MAP

### PROVISION: Section 464 IPC — "Making a False Document"

| Year | Case | Interpretive Layer Added | Status After Current Judgment |
|---|---|---|---|
| 1860 | Indian Penal Code enacted | Three categories of false documents defined: (1) impersonation/false authority, (2) unauthorized alteration, (3) deception of incapacitated person | STILL GOOD LAW — foundation |
| 1963 | Dr. Vimla vs. Delhi Administration | Defined "defraud" as requiring both deceit AND injury (including non-pecuniary) | STILL GOOD LAW — RELIED UPON |
| 1999 | State of UP vs. Ranjit Singh | Reaffirmed the Dr. Vimla definition of "defraud" | STILL GOOD LAW — REAFFIRMED |
| 2000 | G. Sagar Suri vs. State of UP | Established judicial gatekeeping principle against criminalization of civil disputes | STILL GOOD LAW — RELIED UPON |
| 2006 | Indian Oil Corporation vs. NEPC India Ltd. | Balanced the G. Sagar Suri principle: civil nature doesn't immunize genuine criminal ingredients | STILL GOOD LAW — RELIED UPON |
| **2009** | **Md. Ibrahim vs. State of Bihar (CURRENT)** | **Drew bright-line distinction: selling property as one's own (false ownership claim) ≠ false document (impersonation/false authority). The former is NOT forgery. Third-party complainant cannot allege cheating in such transactions.** | **CURRENT POSITION** |

### PROVISION: Sections 415-420 IPC — Cheating

| Year | Case | Interpretive Layer Added | Status After Current Judgment |
|---|---|---|---|
| **2009** | **Md. Ibrahim vs. State of Bihar (CURRENT)** | **Locus to allege cheating in a sale transaction lies with the purchaser (the person deceived), not with a third party claiming to be the true owner of the property sold.** | **CURRENT POSITION** |

---

## SECTION 8: OPERATIVE ORDER & PRACTICAL IMPACT

### Final Order

Appeal allowed in part.

| Action | Detail |
|---|---|
| **Set aside** | Order of the Patna High Court |
| **Quashed** | Order dated 14.12.2005 of the Sub-Divisional Magistrate insofar as offences under Sections 420, 467, 471, and 504 IPC |
| **Quashed** | Charges framed under Sections 420, 467, 471, and 504 IPC |
| **Left undisturbed** | Order dated 14.12.2005 and charges under Sections 323 and 341 IPC |

### Directions Issued

None specific — the quashing is self-operative.

### Practical Impact

**For Practitioners:**

1. **Property dispute complainants** cannot secure forgery charges (Sections 467/471) against someone who sold their property by executing a sale deed in the seller's own name. The remedy is civil — suit for declaration, injunction, cancellation of sale deed.

2. **Cheating charges in property sale disputes** can only be sustained by the purchaser who was defrauded — not by a third party claiming true ownership.

3. **Defence counsel in similar cases** can directly cite this judgment at the discharge/charge stage to quash forgery and cheating charges where the accused executed documents in their own name.

4. **Magistrates** should apply this distinction at the cognizance stage itself — before referring complaints for investigation.

**Who Benefits:** Persons accused of forgery/cheating merely for executing sale deeds over disputed property in their own name.

**Who Is Adversely Affected:** Complainants who relied on criminal process (forgery/cheating charges) as leverage in property disputes. They must now pursue civil remedies.

### Questions Left Open

1. The court does not address scenarios where the accused had **knowledge** that the property didn't belong to them AND the purchaser was a colluding party (not a genuine purchaser) — such cases may raise different questions about intent and conspiracy.

2. The court does not address whether **Section 423 IPC** (fraudulent execution of deed with false statement of consideration) or **Section 421 IPC** (fraudulent removal/concealment of property) could apply in similar fact patterns — though it lists these sections in its catalogue of specific fraudulent acts made punishable (¶16).

3. The scope of criminal remedy available to the **true owner** of property when someone sells it fraudulently remains somewhat open — the court acknowledges the purchaser's remedy but does not comprehensively address what criminal provisions (if any) the true owner can invoke.

---

## SECTION 9: EXTRACTION METADATA

| Field | Details |
|---|---|
| **Extraction Confidence** | **HIGH** — The judgment is clearly written, analytically structured, and the ratio is explicitly stated. |
| **Ambiguities Noted** | (1) The court uses the phrase "even if it is assumed that it did not belong to him" (¶9) — this assumption-based analysis means the court never determined actual ownership, which was correctly left to civil courts. (2) The catalogue of fraudulent acts in ¶16 is comprehensive but the court does not analyze whether any of those other provisions could apply to the facts. |
| **Cross-References** | This judgment impacts: (a) Section 423 IPC (fraudulent execution of deed) — which was not charged but may have been closer to the facts; (b) Transfer of Property Act — the civil remedy for void/voidable sale deeds; (c) Specific Relief Act — declaratory suits and cancellation of instruments; (d) Registration Act — validity of registered documents when the executant has no title. |

---

*Extraction completed using the Structured Judgment Extraction Framework v1.0*
*Judgment source: Indian Kanoon (http://indiankanoon.org/doc/409057/)*
