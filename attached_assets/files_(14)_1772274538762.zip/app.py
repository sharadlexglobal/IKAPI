"""
Judgment Genome Project™ v3.0 — Backend Application
Flask API serving the extraction engine and frontend
"""

import json
import uuid
import os
from datetime import date
from flask import Flask, render_template, request, jsonify

# Try importing anthropic — graceful fallback if not installed
try:
    import anthropic
    HAS_ANTHROPIC = True
except ImportError:
    HAS_ANTHROPIC = False

from config import (
    ANTHROPIC_API_KEY,
    ANTHROPIC_MODEL,
    MAX_TOKENS,
    build_master_prompt,
    get_schema_summary,
    load_schema,
)

app = Flask(__name__)

# ============================================================
# ROUTES
# ============================================================

@app.route("/")
def index():
    """Serve the main frontend."""
    return render_template("index.html")


@app.route("/api/extract", methods=["POST"])
def extract():
    """
    Extract structured judgment genome from raw judgment text.
    Expects JSON body: { "judgment_text": "...", "citation": "..." }
    Returns: Full genome JSON conforming to schema v3.1
    """
    data = request.get_json(force=True)
    judgment_text = data.get("judgment_text", "").strip()
    citation = data.get("citation", "Unknown Citation")

    if not judgment_text:
        return jsonify({"error": "No judgment text provided"}), 400

    if len(judgment_text) < 200:
        return jsonify({"error": "Judgment text too short. Please provide the full judgment."}), 400

    # Build the prompt
    system_prompt = build_master_prompt()
    schema_description = get_schema_summary()

    user_message = f"""Extract the complete Judgment Genome from the following judgment text.

Output ONLY valid JSON conforming exactly to the schema below. No markdown fences, no explanation — ONLY the JSON object.

## SCHEMA:
{schema_description}

## JUDGMENT TEXT:
{judgment_text}"""

    # Call the API
    if not HAS_ANTHROPIC or not ANTHROPIC_API_KEY:
        return jsonify({
            "error": "API not configured",
            "message": "Set ANTHROPIC_API_KEY environment variable. Install anthropic: pip install anthropic"
        }), 503

    try:
        client = anthropic.Anthropic(api_key=ANTHROPIC_API_KEY)
        response = client.messages.create(
            model=ANTHROPIC_MODEL,
            max_tokens=MAX_TOKENS,
            system=system_prompt,
            messages=[{"role": "user", "content": user_message}],
        )

        # Extract the text content
        raw_text = response.content[0].text.strip()

        # Clean potential markdown fences
        if raw_text.startswith("```json"):
            raw_text = raw_text[7:]
        if raw_text.startswith("```"):
            raw_text = raw_text[3:]
        if raw_text.endswith("```"):
            raw_text = raw_text[:-3]
        raw_text = raw_text.strip()

        # Parse JSON
        genome = json.loads(raw_text)

        # Ensure metadata
        if "document_id" not in genome:
            genome["document_id"] = str(uuid.uuid4())
        if "schema_version" not in genome:
            genome["schema_version"] = "3.1.0"
        if "extraction_metadata" not in genome:
            genome["extraction_metadata"] = {}
        genome["extraction_metadata"]["extraction_date"] = date.today().isoformat()
        genome["extraction_metadata"]["judgment_citation"] = citation
        genome["extraction_metadata"]["framework_version"] = "Judgment Genome Project v3.0"
        genome["extraction_metadata"]["extractor"] = ANTHROPIC_MODEL

        return jsonify(genome)

    except json.JSONDecodeError as e:
        return jsonify({
            "error": "Failed to parse AI response as JSON",
            "detail": str(e),
            "raw_response": raw_text[:2000] if 'raw_text' in dir() else "No response"
        }), 422
    except anthropic.APIError as e:
        return jsonify({"error": f"Anthropic API error: {str(e)}"}), 502
    except Exception as e:
        return jsonify({"error": f"Unexpected error: {str(e)}"}), 500


@app.route("/api/schema", methods=["GET"])
def schema():
    """Return the JSON schema."""
    return jsonify(load_schema())


@app.route("/api/demo", methods=["GET"])
def demo():
    """Return a demo genome for frontend development/testing."""
    demo_path = os.path.join(os.path.dirname(__file__), "demo_genome.json")
    if os.path.exists(demo_path):
        with open(demo_path) as f:
            return jsonify(json.load(f))
    return jsonify({"error": "No demo data available"}), 404


# ============================================================
# MAIN
# ============================================================
if __name__ == "__main__":
    print("\n" + "=" * 60)
    print("  JUDGMENT GENOME PROJECT™ v3.0")
    print("  Sub-Atomic Legal Extraction Engine")
    print("=" * 60)
    print(f"  API Key configured: {'YES' if ANTHROPIC_API_KEY else 'NO'}")
    print(f"  Anthropic SDK:      {'YES' if HAS_ANTHROPIC else 'NO'}")
    print(f"  Model:              {ANTHROPIC_MODEL}")
    print(f"  Server:             http://127.0.0.1:5000")
    print("=" * 60 + "\n")
    app.run(debug=True, host="0.0.0.0", port=5000)
