LEGAL RESEARCH QUESTIONS
Extracted from: S.B. Civil Writ Petition — Virendra Bhandari vs Canara Bank & Others
Filed before: High Court of Rajasthan at Jaipur (Articles 226/227)
Client: Virendra Bhandari (Petitioner/Borrower/Appellant)
Date of extraction: 28 February 2026

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

GATE QUESTIONS (Answer these FIRST — they determine everything else)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

G-1. Whether a writ petition under Articles 226/227 of the Constitution is maintainable before the Rajasthan High Court challenging a Registrar's order of the DRAT Kolkata, when the Chamber Appeal against that very order is pending before the DRAT Chairperson — and if so, under which recognized exception to the alternative remedy bar?
[¶58, 42-43 | CRITICAL | If this fails, the entire petition is dismissed at threshold]

G-2. Whether the Rajasthan High Court has territorial jurisdiction to entertain a writ petition challenging an order passed by the DRAT Kolkata situated in West Bengal, or whether the petition should be filed before the Calcutta High Court within whose territorial jurisdiction the DRAT sits?
[¶58, 152 | CRITICAL | Jurisdiction objection could be fatal — Bank WILL raise this]

G-3. Whether the petitioner's Chamber Appeal filed on 10.01.2026 is within the limitation period prescribed under the RDB Act and DRAT Procedure Rules, given that the impugned Registrar's order is dated 22.07.2025 — a gap of 159 days?
[¶53, 96 | CRITICAL | If limitation is not condoned, the appeal itself dies and the writ has no foundation]


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

CATEGORY 1: JURISDICTIONAL & MAINTAINABILITY

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

J-1. Whether the principle laid down in Whirlpool Corporation vs Registrar of Trade Marks (1998) 8 SCC 1 — that writ jurisdiction is maintainable despite an alternative remedy where the statutory forum is not functioning or is unable to provide timely relief — applies to the present case where the DRAT Chairperson's tenure has expired and no hearing dates are being given?
[¶34-35, 74-75 | CRITICAL | This is the ONLY exception that can save maintainability]

J-2. Whether the two earlier orders of the Rajasthan High Court dated 21.04.2025 (WP 4548/2025) and 27.10.2025 (CWP 16303/2025) granting liberty to "approach DRAT" operate as a bar to the present writ petition, on the principle that a litigant who has been directed to an alternative forum cannot return to the High Court on the same cause of action?
[¶14, 18, 49 | HIGH | The Bank will argue the HC already sent the petitioner to DRAT twice]

J-3. Whether the DRAT Kolkata being non-functional due to the expiry of the Chairperson's tenure constitutes a circumstance that activates the High Court's extraordinary jurisdiction under Article 226, applying the doctrine that writ jurisdiction can be invoked when the statutory tribunal is rendered incapable of granting effective relief?
[¶34-35, 74 | HIGH | Must find specific SC authority where tribunal vacancy justified HC intervention]

J-4. Whether Section 18 of the Recovery of Debts and Bankruptcy Act, 1993 operates as a bar on the jurisdiction of civil courts including the High Court in writ jurisdiction, and if so, whether the bar extends to the challenge of a Registrar's administrative order or only to adjudicatory orders of the DRT/DRAT?
[¶58 | HIGH | Need to distinguish between adjudicatory bar and administrative action challenge]

J-5. Whether the Presiding Officer of the DRT Jaipur and the Registrar of the DRAT Kolkata are necessary parties, or whether the petition should have been filed only against the Bank as the real contesting respondent — and whether impleading the tribunal as a respondent is procedurally objectionable?
[¶20-25, 106 | MEDIUM | Court may take objection to tribunal being made a party]

J-6. Whether the petitioner is required to challenge the DRT Jaipur's order dated 02.05.2023 in OA No. 39/2013 separately, or whether the present petition challenging only the DRAT Registrar's order and seeking stay of e-auction is sufficient to protect his rights — given that the petition expressly states it does not seek to re-agitate the merits of the underlying OA?
[¶43, 82-83 | MEDIUM | Judge may ask: "Why are you not challenging the original decree?"]


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

CATEGORY 2: LIMITATION, DELAY & LACHES

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

LIM-1. What is the specific limitation period for filing a Chamber Appeal before the DRAT under Rule 6(5) of the DRAT Procedure Rules, 1994 against a Registrar's order, and is this period different from the 45-day period prescribed under Section 20 of the RDB Act for regular appeals against DRT orders?
[¶15-16, 53 | CRITICAL | If the 45-day period applies, 159 days is a massive delay]

LIM-2. Whether the express liberty granted by the Rajasthan High Court in its orders dated 21.04.2025 and 27.10.2025 to "approach DRAT" operates to extend, suspend, or reset the limitation period for filing the Chamber Appeal — and what is the legal effect of court-granted liberty on statutory limitation?
[¶14, 18, 53 | CRITICAL | This is the petitioner's ONLY explanation for the 159-day gap]

LIM-3. Whether the period spent by the petitioner in pursuing the writ petitions before the High Court (WP 4548/2025 dismissed on 21.04.2025, CWP 16303/2025 disposed on 27.10.2025) can be excluded from the limitation computation under Section 14 of the Limitation Act, 1963 as time spent prosecuting a remedy in good faith before a forum which lacked jurisdiction?
[¶14, 18, 53 | HIGH | Section 14 exclusion is the strongest limitation argument]

LIM-4. Whether the preparation of demand drafts in August 2025 totaling Rs. 13,25,000 and the filing of applications before DRAT constitute "bona fide steps" that demonstrate the petitioner's diligence and negate any allegation of laches — even though the Chamber Appeal itself was not filed until 10.01.2026?
[¶17, 52 | HIGH | Bank will argue: DDs were prepared but appeal was not filed for months]

LIM-5. Whether the principle established in Collector, Land Acquisition vs Mst. Katiji (1987) 2 SCC 107 — that the court should lean in favour of condonation when the delay is attributable to circumstances beyond the party's control — applies to delay in filing a Chamber Appeal before DRAT, and whether the petitioner's financial hardship, parallel proceedings, and institutional obstacles constitute sufficient cause?
[¶53, 96 | HIGH | Katiji is the foundational SC judgment on liberal condonation]

LIM-6. What is the exact timeline gap between 22.07.2025 (Registrar's order) and 21.04.2025 / 27.10.2025 (HC orders granting liberty)? The petition claims the delay is attributable to pursuing HC remedies, but the Registrar's order (22.07.2025) came AFTER the first HC order (21.04.2025). What was the petitioner doing between 22.07.2025 and 27.10.2025 — a period of approximately 97 days?
[¶14-18, 53 | HIGH | EXPOSE_GAP — this timeline gap is the biggest vulnerability in the pleading]

LIM-7. Whether the principle that "each day's delay must be explained" applies to appeals under the RDB Act before DRAT, and if so, can the petitioner provide a day-by-day explanation for the 159-day gap from 22.07.2025 to 10.01.2026?
[¶53 | MEDIUM | Some High Courts require strict day-by-day explanation]


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

CATEGORY 3: STATUTORY INTERPRETATION

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

STAT-1. What is the scope and nature of a "Chamber Appeal" under the DRAT Procedure Rules? Is it a regular appeal under Section 20 of the RDB Act, or a separate remedial mechanism? Does the Chairperson have original jurisdiction to hear Chamber Appeals against the Registrar's orders, or is it treated as an administrative review?
[¶26, 65 | HIGH | The legal nature of a Chamber Appeal determines what procedural rules apply]

STAT-2. Whether the Registrar of DRAT has the power to dismiss an application for waiver/reduction of pre-deposit under Section 21 of the RDB Act, or whether this power vests exclusively in the Appellate Tribunal (Chairperson) — and whether the Registrar's order dated 22.07.2025 was passed without jurisdiction?
[¶16, 51, 94 | CRITICAL | If Registrar had no jurisdiction, the order is void ab initio and limitation may not even arise]

STAT-3. What is the correct interpretation of Section 21 of the RDB Act regarding the pre-deposit requirement — is the 50% deposit of the debt due as determined by the DRT mandatory, or does the Appellate Tribunal have discretion to reduce or waive it, and what are the grounds on which waiver has been granted by various High Courts and the Supreme Court?
[¶51, 59, 94 | CRITICAL | Pre-deposit waiver is the KEY to the appeal being heard]

STAT-4. Whether the expression "for reasons to be recorded in writing" in Section 21 of the RDB Act imposes a mandatory obligation on the DRAT to consider and dispose of a waiver application on merits before refusing it, and whether a summary dismissal by the Registrar without recording reasons violates this statutory mandate?
[¶16, 51 | HIGH | Goes to the legality of the impugned Registrar's order]

STAT-5. What is the interplay between Section 20 (appeal), Section 21 (pre-deposit), and Section 25A (attachment of property) of the RDB Act — specifically, whether the filing of an appeal with a deposit application automatically stays execution proceedings, or whether a separate stay application is required?
[¶19, 59 | HIGH | Determines whether DRT can proceed with e-auction while appeal is pending]

STAT-6. What does the Supreme Court's judgment in Kotak Mahindra Bank Ltd. vs Ambuj A. Kasliwal (Civil Appeal No. 538/2021, decided 16.02.2025) actually hold regarding Section 21 pre-deposit requirements, and does it support the petitioner's position on waiver/reduction, or does it strengthen the Bank's argument that pre-deposit is mandatory?
[¶13, 48, 67, 111 | CRITICAL | The petition cites this case but does not clearly state what it held — need to verify the actual ratio]

STAT-7. Whether Rule 6 and Rule 6(5) of the DRAT Procedure Rules, 1994 prescribe a separate limitation period for Chamber Appeals distinct from Section 20 appeals, and what is the consequence of non-compliance — is the appeal time-barred or can it be condoned?
[¶15, 31 | HIGH | The specific rule determines the limitation period and condonation power]


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

CATEGORY 4: CONSTITUTIONAL LAW

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

CONST-1. Whether the right of appeal conferred by Section 20 of the RDB Act, once granted by statute, becomes a constitutional right enforceable under Article 14 (equality before law) and Article 21 (right to life and livelihood) — and whether making this right illusory through institutional delays and administrative obstacles amounts to a constitutional violation?
[¶46-47, 88-89 | HIGH | This is the petitioner's strongest constitutional argument]

CONST-2. Whether the principle of audi alteram partem (no man shall be condemned unheard) is violated when a borrower's property is auctioned while his statutory appeal remains pending and unheard — not due to his default but due to DRAT's adjournments and Chairperson vacancy?
[¶34-36, 46, 88 | HIGH | Natural justice violation is a separate constitutional ground]

CONST-3. Whether the right to property under Article 300A of the Constitution is violated when a person's immovable property is sold through e-auction without providing an effective opportunity to have his statutory appeal heard on merits — and what is the standard of judicial scrutiny applicable to deprivation of property under Article 300A?
[¶36, 49, 88 | HIGH | Article 300A — not fundamental right but constitutional right — frame correctly]

CONST-4. Whether conducting an e-auction of the petitioner's property on 13.03.2026 while his Chamber Appeal is pending hearing on 06.03.2026 (and unlikely to be heard due to Chairperson vacancy) would constitute a violation of the principle of proportionality, given that the original loan was Rs. 45 lakhs, the decree is Rs. 53.28 lakhs, and the property proposed for auction measures 12,210 square meters?
[¶40, 55, 98-99 | HIGH | Proportionality argument strengthens the constitutional case]

CONST-5. What is the scope of the High Court's supervisory jurisdiction under Article 227 of the Constitution over the DRAT — specifically, can the High Court issue directions to the DRAT to expedite hearing of a pending appeal, and can it stay execution proceedings pending before the DRT while the appeal is pending before the DRAT?
[¶29, 58, 102 | HIGH | Article 227 may be a stronger jurisdictional basis than Article 226]


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

CATEGORY 5: SUBSTANTIVE LAW — MERITS

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

SUB-1. Whether the Bank's failure to adjust or credit Rs. 36,00,000 received from the sale of property purchased by the petitioner's daughter Smt. Megha Bhandari constitutes unjust enrichment and/or bad faith, and what is the legal obligation of a decree-holder bank to give credit for amounts received towards the decretal amount?
[¶39, 52, 95, 117 | HIGH | If Rs. 36 lakhs is adjusted, the remaining liability drops dramatically]

SUB-2. Whether the FIR No. 0127/2015 registered against Bank officials regarding manipulation of security documents (plot numbers B-172 overwritten as B-172A) has any bearing on the recovery proceedings, and whether fraud vitiates the entire transaction including the DRT decree?
[¶5-6, 41, 54, 97 | MEDIUM | Fraud is alleged but is there a conviction? FIR alone may not be enough]

SUB-3. What is the legal position on whether a One-Time Settlement (OTS) once communicated and partially acted upon (demand draft submitted and encashed by the Bank) can be unilaterally cancelled by the Bank — and whether the Bank's conduct of encashing the DD and then cancelling the OTS constitutes estoppel?
[¶10-11, 45-46, 118 | HIGH | Promissory estoppel / part performance argument]

SUB-4. Whether the Bank's selective recovery action against the petitioner alone while ignoring equally liable partners, directors, and guarantors of M/s V.S. Bhandari Cold House Pvt. Ltd. constitutes discrimination and arbitrary action violating Article 14 of the Constitution?
[¶38, 56, 78, 99 | MEDIUM | Need to establish who the other liable parties are and that Bank hasn't pursued them]

SUB-5. Whether the Recovery Officer's show cause notice under Section 25A proposing attachment of 12,210 square meters against a security of 5,249 square meters is legally permissible, or whether the principle of proportionality limits the Recovery Officer's power to attach only the property that is the subject of the security interest?
[¶40, 55, 98 | MEDIUM | What does the DRT order and Recovery Certificate specify?]


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

CATEGORY 6: PROCEDURAL LAW

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

PROC-1. Whether the petitioner's deposit of Rs. 13,32,086 through four demand drafts dated December 2025 and January 2026 constitutes substantial compliance with the pre-deposit requirement under Section 21 of the RDB Act, given that the 50% of the decretal amount of Rs. 53,28,346 would be approximately Rs. 26,64,173 — and the deposit is approximately 25% of the decretal amount?
[¶21, 56-57, 60 | CRITICAL | The deposit is roughly HALF of what Section 21 requires — this is a major gap]

PROC-2. Whether a digitally signed copy of the Registrar's order dated 22.07.2025 downloaded from the official DRAT website can be accepted in lieu of a certified copy for the purposes of filing the Chamber Appeal, and what is the legal position on electronic records under the Bharatiya Sakshya Adhiniyam, 2023 (formerly Indian Evidence Act)?
[¶25, 69-70, 128 | HIGH | Registry raised this as a defect — need clear legal authority]

PROC-3. What is the procedure for filing a Chamber Appeal before the DRAT — is it the same as a regular appeal under Section 20, or does it have a separate procedure under the DRAT Procedure Rules? Does it require separate court fees, separate vakalatnama, separate index?
[¶65-66 | MEDIUM | Procedural compliance prevents registry objections from killing the appeal]

PROC-4. Whether the Registrar of DRAT can dismiss an appeal on the ground of defects without giving the appellant a reasonable opportunity to cure the defects, and what is the minimum period that must be granted for curing defects under the DRAT Procedure Rules?
[¶23-25, 29-30, 64-70 | MEDIUM | Pattern of registry obstruction needs to be legally characterized]

PROC-5. What is the legal effect of the DRAT Registry raising defects, then reporting defects cured, and then the matter being adjourned repeatedly without hearing — does this sequence constitute denial of access to justice actionable under Article 226?
[¶30-35, 70-75 | HIGH | This is the core narrative — registry accepted, then tribunal didn't hear]

PROC-6. Whether Section 22 of the RDB Act mandating that DRT and DRAT shall follow principles of natural justice creates a statutory obligation to hear an appeal before allowing execution, and whether this obligation binds the Recovery Officer as well?
[¶64, 107 | MEDIUM | Section 22 is a procedural safeguard that strengthens the NJ argument]


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

CATEGORY 7: INTERIM RELIEF & STAY

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

INT-1. What is the legal test for granting stay of an e-auction under the RDB Act when a statutory appeal is pending but the pre-deposit requirement has not been fully met — is there any Supreme Court or Rajasthan High Court authority that permits stay even when the pre-deposit is partial?
[¶36, 49-50, 93 | CRITICAL | The e-auction is on 13.03.2026 — this question decides whether the property survives]

INT-2. Whether an e-auction once conducted and confirmed in favour of a third-party purchaser creates rights in the auction purchaser that cannot be reversed — and what is the Supreme Court's position on setting aside confirmed auction sales? Specifically, find authority for the proposition that courts should stay auctions rather than face the complexity of setting them aside post-facto.
[¶49, 92 | CRITICAL | Irreversibility argument is the strongest ground for interim stay]

INT-3. Can the High Court grant ex-parte ad-interim stay of an e-auction scheduled within days when the appeal is pending before a different tribunal (DRAT), or does the principle that the appellate tribunal alone should grant stay in its own proceedings apply?
[¶104-105, 129-130 | HIGH | Jurisdictional propriety of HC staying proceedings in DRAT matters]

INT-4. Whether the three-fold test for interim relief (prima facie case, balance of convenience, irreparable injury) is satisfied when: (a) the appeal is pending and was not heard due to institutional failures, (b) the Bank's security is not diminished by a stay, and (c) the property once sold cannot be recovered?
[¶229-235 | HIGH | Need to find parallel facts in case law where all three limbs were satisfied]

INT-5. Whether the Bank can argue that it will suffer prejudice from a stay because the property may depreciate, the borrower may alienate it, or the debt is mounting — and what conditions (security, undertaking, status quo on property) can be offered to neutralize this argument?
[¶50, 93 | MEDIUM | Anticipate the Bank's opposition to stay and pre-empt it with conditions]

INT-6. What is the effect of the petitioner's payment of Rs. 13,32,086 through demand drafts on the balance of convenience — does the deposit of approximately 25% of the decree amount while claiming inability to pay 50% demonstrate sufficient bona fides to justify interim protection?
[¶21, 56-57, 80 | HIGH | Judge will ask: "You say you can't pay 50% but you've paid 25% — why not more?"]


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

CATEGORY 8: EVIDENCE & DOCUMENTARY

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

EVID-1. Has the petitioner filed a copy of the Bank's OTS approval letter followed by the OTS cancellation letter? Without these documents, the allegation of bad faith OTS cancellation is an assertion without proof.
[¶10-11, 45, 118 | HIGH | EXPOSE_GAP — OTS correspondence may not be on record]

EVID-2. Is there documentary proof on record of the Rs. 36,00,000 allegedly received by the Bank from the sale of the daughter's property — specifically, the sale deed, bank receipt, or account statement showing the Bank received this amount?
[¶39, 95, 117 | HIGH | EXPOSE_GAP — this is a Rs. 36 lakh claim without clear documentary proof identified in the pleading]

EVID-3. Has the petitioner filed the FIR No. 0127/2015 and any subsequent investigation report, chargesheet, or court proceedings related to the fraud allegations against Bank officials? An FIR alone without follow-up action over 10+ years may actually hurt the petitioner.
[¶6, 41, 54, 97 | MEDIUM | EXPOSE_GAP — a 2015 FIR with no visible progress by 2026 looks suspicious]

EVID-4. Are the four demand drafts (15.12.2025, 20.12.2025, 22.12.2025, 06.01.2026) totaling Rs. 13,32,086 still valid, or have they expired? Standard DD validity is 3 months — the earliest DD may expire in March 2026.
[¶21, 56-57 | HIGH | EXPOSE_GAP — if DDs expire before acceptance, the deposit argument collapses]

EVID-5. Has the petitioner filed copies of all correspondence with the DRAT Registry showing the defects raised, the curing of defects, and the timeline of compliance — to substantiate the narrative of institutional obstruction?
[¶23-35, 64-75 | MEDIUM | The entire "registry obstruction" narrative needs documentary backbone]

EVID-6. Has the petitioner filed proof of the Chairperson vacancy at DRAT Kolkata — an official notification, gazette notification, or administrative order showing that the Chairperson's tenure has expired and no replacement has been appointed?
[¶35, 74 | HIGH | This is a key factual claim — "DRAT is non-functional" — that needs proof]

EVID-7. What annexures (P-1 to P-19) have actually been filed, and is there a gap in the document numbering that suggests missing documents that should have been filed?
[¶153 | MEDIUM | Courts notice gaps in annexure numbering]


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

CATEGORY 9: OPPOSING PARTY ANTICIPATION

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

OPP-1. BANK WILL ARGUE: "The petitioner has an effective alternative remedy — the Chamber Appeal is pending before DRAT. This writ petition is not maintainable."
Research: Under what circumstances have courts entertained writ petitions DESPITE a pending appeal — specifically when the appellate forum is non-functional due to vacancy? Find: Whirlpool (1998) 8 SCC 1, ABL International (2004) 1 SCC 176, and any Rajasthan HC decisions on this point.
[¶58 | CERTAIN the Bank will argue this | CRITICAL]

OPP-2. BANK WILL ARGUE: "There is a delay of 159 days which is inordinate and demonstrates that the petitioner is not diligent but is deliberately delaying recovery to retain possession of the property."
Research: What is the maximum delay that has been condoned by courts in DRAT appeal filings? Find cases where delay of 100+ days was condoned in debt recovery appeals, and cases where it was refused — understand the boundary.
[¶53 | CERTAIN | CRITICAL]

OPP-3. BANK WILL ARGUE: "The petitioner has deposited only Rs. 13.32 lakhs against a statutory requirement of approximately Rs. 26.64 lakhs (50% of Rs. 53.28 lakhs). He has not even substantially complied with Section 21. No appeal can be entertained without compliance."
Research: What is the power of DRAT to waive or reduce the pre-deposit below 50%? Are there SC decisions permitting deposit of less than 50% in cases of demonstrated financial hardship? What about the Kotak Mahindra judgment the petitioner cites — does it actually help?
[¶51, 59 | CERTAIN | CRITICAL — This may be the Bank's STRONGEST argument]

OPP-4. BANK WILL ARGUE: "This is the petitioner's THIRD writ petition on substantially the same cause of action. WP 4548/2025 was dismissed on 21.04.2025, CWP 16303/2025 was disposed on 27.10.2025. This is an abuse of process and res judicata/constructive res judicata applies."
Research: Whether successive writ petitions on evolving facts (new orders, new circumstances like Chairperson vacancy) constitute the "same cause of action" for res judicata purposes, or whether each new impugned order creates a fresh cause of action.
[¶14, 18, 44 | HIGHLY LIKELY | HIGH]

OPP-5. BANK WILL ARGUE: "The petitioner is not a borrower in distress but a deliberate defaulter who has been using every legal maneuver to avoid paying a legitimate debt since 2013 — a period of 13 years."
Research: How do courts distinguish between a "deliberate defaulter using legal process to delay" and a "borrower bonafide pursuing legitimate remedies"? What factors do courts consider? Find cases where this distinction was made in favour of borrowers.
[¶42, 60, 103 | HIGHLY LIKELY | HIGH]

OPP-6. BANK WILL ARGUE: "The Rs. 36 lakhs from the daughter's property sale has already been adjusted in the Bank's accounts, and the petitioner is making a false claim. In any event, this is a disputed question of fact that cannot be adjudicated in writ jurisdiction."
Research: What is the evidentiary burden on the Bank to prove adjustment, and can the High Court in writ jurisdiction direct the Bank to produce its account statements showing whether the adjustment was made?
[¶39, 95, 117 | PROBABLE | HIGH]

OPP-7. BANK WILL ARGUE: "If the e-auction is stayed, the Bank will suffer prejudice because the property may be alienated, encumbered, or allowed to deteriorate. Public money is at stake."
Research: What conditions can be offered to neutralize this — an undertaking not to alienate, a direction to maintain the property, deposit of additional amounts? Find cases where courts balanced Bank's interest with borrower's appeal right.
[¶50, 93 | CERTAIN | HIGH]

OPP-8. BANK WILL ARGUE: "The fraud allegations regarding plot numbers are irrelevant to recovery proceedings and are a red herring. The FIR was filed in 2015 and no progress has been made in 11 years."
Research: Whether a pending FIR regarding manipulation of security documents can be raised as a defence in recovery proceedings, and whether the passage of time without prosecution progress weakens or strengthens the fraud defence.
[¶5-6, 97 | PROBABLE | MEDIUM]

OPP-9. BANK WILL ARGUE: "The petitioner's parallel liability to Punjab National Bank under SARFAESI demonstrates that he is a serial defaulter, not a victim of circumstances."
Research: Whether parallel proceedings by different banks can be used to characterize a borrower as a habitual defaulter, or whether each proceeding must be judged on its own merits.
[¶37, 57, 77, 100 | POSSIBLE | MEDIUM]


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

CATEGORY 10: PRECEDENT CHAIN ANALYSIS

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

PREC-1. The petition relies heavily on Kotak Mahindra Bank Ltd. vs Ambuj A. Kasliwal (SC, 16.02.2025). What is the EXACT ratio of this judgment? Does it actually support waiver/reduction of pre-deposit, or does it hold that pre-deposit is mandatory? Has this judgment been followed, distinguished, or doubted by any High Court since February 2025?
[¶13, 48, 67, 111 | CRITICAL | If Kotak Mahindra doesn't say what the petition implies, the entire pre-deposit argument crumbles]

PREC-2. Has the Supreme Court in Narayan Chandra Ghosh vs UCO Bank (1987) 1 SCC 693 or any subsequent judgment specifically addressed whether execution proceedings should be stayed when a statutory appeal is pending but the pre-deposit condition has not been fully met?
[¶ not cited — should have been | HIGH | This is a key lacuna — the petition doesn't cite the most relevant SC precedent]

PREC-3. What did the Rajasthan High Court hold in WP 4548/2025 (dismissed 21.04.2025) and CWP 16303/2025 (disposed 27.10.2025)? The petition mentions "liberty" was granted but does not reproduce the operative portion of these orders. The exact terms of the liberty determine whether the petitioner has complied with or exceeded the scope of the liberty granted.
[¶14, 18, 49 | HIGH | The earlier HC orders need to be read verbatim — "liberty to approach DRAT" may have conditions]

PREC-4. What is the current status of the law on whether registry defects and administrative delays at tribunals constitute grounds for invoking Article 226 writ jurisdiction? Find post-2020 Supreme Court or Rajasthan High Court decisions specifically in the context of DRT/DRAT proceedings.
[¶48, 91 | HIGH | The petition states this as a "well-settled principle" but doesn't cite the specific authority]

PREC-5. Has any court — Supreme Court or any High Court — specifically held that a Registrar of DRAT has NO jurisdiction to dismiss a Section 21 waiver application, and that this power belongs exclusively to the Chairperson/Appellate Tribunal?
[¶16, 51 | HIGH | If yes, the impugned order is void and the limitation problem may dissolve]


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

CATEGORY 11: EQUITABLE & DISCRETIONARY FACTORS

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

EQ-1. Does the petitioner come to court with clean hands? He admits the loan was taken, admits the decree was passed, and his primary argument is inability to pay the pre-deposit — which courts may view as inability to comply with a statutory condition. How do courts view borrowers who admit the debt but seek to delay the auction on procedural grounds?
[¶42-43, 80, 103 | HIGH | JUDGE_CONCERN — the judge's conscience is the battlefield here]

EQ-2. The petitioner has been in litigation since 2013 (OA filing) through 2026 — 13 years. How do courts view borrowers who have been litigating for over a decade without resolution? Is there a judicial trend toward declining discretionary relief for prolonged litigants?
[¶7, 42 | HIGH | EXPOSE_GAP — the 13-year timeline looks very bad from the court's perspective]

EQ-3. The petitioner alleges financial hardship but prepared demand drafts totaling Rs. 13.32 lakhs. The judge will ask: "If you can arrange Rs. 13.32 lakhs, why can't you arrange Rs. 26.64 lakhs? What is your actual financial position?" Is there an affidavit of financial capacity on record?
[¶21, 41, 56-57, 80 | HIGH | JUDGE_CONCERN — judges are suspicious of selective inability to pay]

EQ-4. What are the equities of the Bank's position — has the Bank been patient or aggressive? The Bank sanctioned the loan in 2009, filed OA in 2013, obtained decree in 2023, and the e-auction is in 2026. That is 17 years from loan to auction. Can the Bank legitimately argue it has been more than patient?
[¶2, 7, 36 | MEDIUM | Balance of equities requires understanding BOTH sides]

EQ-5. The petitioner's daughter purchased property from which Rs. 36 lakhs allegedly went to the Bank. Is this a genuine arm's-length transaction or a related-party transaction designed to show partial payment while retaining control of assets? How will the court view this?
[¶39, 117 | MEDIUM | EXPOSE_GAP — the daughter's transaction could be viewed with suspicion]


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

CATEGORY 12: COURT-SPECIFIC

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

COURT-1. What is the Rajasthan High Court's specific approach to writ petitions challenging DRT/DRAT proceedings — does it lean toward intervention or restraint? Find the last 10 significant Rajasthan HC decisions in DRT/DRAT writ matters from 2023-2026.
[General | HIGH | Know your court]

COURT-2. Has the Rajasthan High Court previously stayed e-auctions ordered by DRT Jaipur while an appeal was pending before DRAT Kolkata? Is there a specific precedent from this court on this exact procedural configuration?
[¶36 | HIGH | A same-court precedent is the strongest persuader]

COURT-3. What is the Rajasthan High Court's practice on listing urgent matters — does the Statement of Urgency ensure immediate listing, or is there an additional mentioning procedure before the Registrar Judicial?
[¶211-220 | MEDIUM | Practical — ensures the petition is actually heard before 13.03.2026]

COURT-4. Are there any Practice Directions or Administrative Orders of the Rajasthan High Court regarding interim stay of auction proceedings — specifically, does the Court require any special conditions (deposit, bond) before staying DRT auctions?
[General | MEDIUM | Anticipate conditions the court may impose]


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

CATEGORY 13: STRATEGIC & TACTICAL

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

STRAT-1. Should the petitioner offer to deposit an additional amount as a condition for stay — bringing the total deposit closer to 50% — to demonstrate bona fides and improve the chances of interim relief? What amount would be sufficient to satisfy the court?
[¶21, 56 | CRITICAL | Offering additional deposit at the hearing may swing the case]

STRAT-2. Should a separate, detailed Condonation of Delay application with a day-by-day affidavit explaining the 159-day gap be filed alongside this writ petition, rather than addressing it in a single paragraph (¶53)?
[¶53 | HIGH | ¶53 is too thin for a 159-day delay explanation — needs a standalone application]

STRAT-3. Should the petitioner file a separate application before the DRAT Kolkata for urgent listing of the Chamber Appeal — in parallel with this writ petition — so that if the HC directs "approach DRAT" a third time, the petitioner can show he has already done so and DRAT is not functioning?
[¶34-35 | HIGH | Pre-empts the "go to DRAT" dismissal]

STRAT-4. Should the petitioner's counsel orally offer specific undertakings at the hearing — such as undertaking not to alienate/encumber the property, depositing additional amounts in installments, or agreeing to expedited hearing of the appeal — to improve the chances of ad-interim relief?
[¶50, 93 | HIGH | Proactive undertakings show good faith and help the judge grant relief]

STRAT-5. Should the fraud allegations (¶5-6, FIR No. 0127/2015) be de-emphasized in the hearing given that no prosecution has materialized in 11 years, or should they be highlighted as evidence of the Bank's bad faith? What is the risk-reward of leading with fraud vs. leading with "right of appeal rendered illusory"?
[¶5-6 | MEDIUM | Leading with a stale FIR could undermine credibility]

STRAT-6. What is the exit strategy if the High Court refuses interim relief? Can the petitioner immediately approach the Supreme Court under Article 136, or should he attempt a different remedy first?
[General | MEDIUM | Plan B must be ready before the hearing]


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

CATEGORY 14: CROSS-STATUTE & REGULATORY

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

CROSS-1. What is the interplay between the DRT's recovery proceedings under the RDB Act and PNB's SARFAESI proceedings mentioned in ¶37 — can two different banks proceed simultaneously against the same property, and which proceeding has priority?
[¶37, 57, 100 | HIGH | Parallel proceedings create complications that could actually help the petitioner]

CROSS-2. Are there any RBI circulars or guidelines on One-Time Settlement (OTS) that mandate a minimum period for the borrower to comply, or that prohibit a Bank from cancelling an OTS after encashing the initial deposit? Specifically, check the RBI Master Circular on Recovery Management.
[¶10-11, 45, 118 | MEDIUM | RBI circulars on OTS can strengthen the bad faith argument]

CROSS-3. Whether Section 14 of the Limitation Act, 1963 (exclusion of time spent in proceedings in wrong court) applies to the time spent by the petitioner pursuing writ petitions before the High Court — and whether the High Court proceedings can be characterized as proceedings "in good faith" before a court "which lacked jurisdiction" for the purposes of Section 14?
[¶53 | HIGH | This is the strongest limitation defence but needs precise application]

CROSS-4. Does the SARFAESI Act, 2002 have any provision that affects the DRT's power to conduct e-auctions under the RDB Act, or are the two statutory regimes completely independent? Specifically, if PNB has already initiated SARFAESI proceedings on the same property, can DRT simultaneously auction it?
[¶37, 57, 77 | MEDIUM | Dual auction threat could be grounds for arguing disproportionate action]

CROSS-5. Are there any provisions in the Insolvency and Bankruptcy Code, 2016 that the petitioner could invoke to obtain a moratorium — and would a moratorium under IBC automatically stay the DRT auction proceedings?
[General | MEDIUM | IBC moratorium is a nuclear option — but may be available]


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

WHAT THE JUDGE WILL ASK FIRST

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

"Mr. Advocate, you have been sent to DRAT by this Court twice — on 21.04.2025 and 27.10.2025. Your appeal is pending there. Why are you back before this Court for the third time instead of pursuing your remedy before the DRAT? And why should this Court stay an auction when you have not even complied with the pre-deposit requirement under Section 21?"

You MUST have a researched, authority-backed answer to this question before stepping into court.


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

TOP 5 CASE-WINNING QUESTIONS

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

1. STAT-2: Whether the Registrar of DRAT had jurisdiction to dismiss the Section 21 waiver application, or whether this power vests exclusively in the Chairperson — because if the order is without jurisdiction, it is void, limitation may not apply, and the entire case resets.

2. INT-1: What is the legal test for staying an e-auction when a statutory appeal is pending but pre-deposit is partial — because this question directly determines whether the property survives.

3. LIM-2: Whether the HC's liberty orders extend limitation — because if limitation is not saved, the appeal dies and the writ has no foundation.

4. OPP-3: How to counter the Bank's argument that the pre-deposit is only 25% of what Section 21 requires — because this is the Bank's strongest argument and the petitioner's biggest numerical weakness.

5. J-1: Whether the Whirlpool exception applies when DRAT is non-functional due to Chairperson vacancy — because if maintainability fails, nothing else matters.


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

BIGGEST VULNERABILITY

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

The petitioner has deposited Rs. 13.32 lakhs against a statutory requirement of approximately Rs. 26.64 lakhs — roughly 25% instead of 50%. The petition frames this as "financial hardship" but provides no affidavit of means, no income proof, no balance sheet to substantiate the claim that more cannot be paid. The Bank will argue this is not hardship but unwillingness. The judge will not grant interim relief unless satisfied that the petitioner has done his genuine best on the pre-deposit — and "half of the required amount" is a hard sell without financial documentation.


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

SENIOR ADVOCATE'S NOTE

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

This case has a genuine equitable core — a borrower whose statutory appeal is being rendered meaningless by institutional failure — but the pleading has three serious gaps that must be fixed before hearing. First, the 159-day delay is explained in one paragraph (¶53) when it needs a standalone application with a day-by-day affidavit. Second, the pre-deposit of 25% against a 50% requirement needs financial documentation (balance sheet, income tax returns, bank statements) to prove inability, not just assertion. Third, the territorial jurisdiction question — challenging a DRAT Kolkata order before the Rajasthan High Court — needs to be addressed head-on with authority, not left for the Bank to raise. If these three gaps are plugged before the hearing and STAT-2 (Registrar's jurisdiction) yields a favourable answer, this case is winnable. Without plugging them, the petition is vulnerable to dismissal at the preliminary stage.


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

TOTAL: 83 questions across 14 categories + 3 gate questions + 9 anticipatory arguments

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
