# ╔══════════════════════════════════════════════════════════════════╗
# ║        JUDGMENT GENOME PROJECT™ — EXTRACTION REPORT            ║
# ║                                                                ║
# ║  Md. Ibrahim & Ors vs State of Bihar & Anr                    ║
# ║  (2009) 8 SCC 751 | Criminal Appeal No. 1695 of 2009          ║
# ║  Supreme Court of India | 04 September 2009                   ║
# ╚══════════════════════════════════════════════════════════════════╝

---

# ═══════════════════════════════════════════════════════
# DIMENSION 1: THE VISIBLE
# (What the judgment says — Enhanced classical extraction)
# ═══════════════════════════════════════════════════════

---

## 1.1 CASE IDENTITY CARD

```
Case Name              : Md. Ibrahim & Ors vs State of Bihar & Anr
Court                  : Supreme Court of India
Bench                  : 2-Judge Bench
                         Justice R.V. Raveendran (Author)
                         Justice R.M. Lodha (Concurring)
                         NOT a Constitution Bench.
Date                   : 04 September 2009
Case Number            : Criminal Appeal No. 1695 of 2009
                         [Arising out of SLP (Crl.) No. 6211 of 2007]
Domain                 : Criminal — Quashing of criminal charges arising from
                         property dispute; Interpretation of forgery, cheating,
                         and insult provisions of Indian Penal Code.
Judgment Author        : Justice R.V. Raveendran
Concurring Judges      : Justice R.M. Lodha (silent concurrence — no separate opinion)
Dissenting Judges      : None — Unanimous decision.
Case Origin            : Special Leave Petition (Criminal) under Article 136
                         of the Constitution, against order of the Patna High Court
                         dismissing a petition under Section 482 CrPC, which had
                         challenged the Sub-Divisional Magistrate's refusal to
                         discharge the accused.
```

---

## 1.2 THE STORY

### THE STORY IN PLAIN LANGUAGE:

In a small town called Madhubani in Bihar, two cousins — Ibrahim and the complainant — had a fight over a piece of family land. Their grandfathers were brothers and had owned the land together. Ibrahim believed that through a family arrangement decades ago, part of the land came to his mother's side, and after his parents died, it became his. So he did what any owner would do — he sold a portion of it to a buyer, went to the government registration office, signed the sale deeds in his own name, got them properly witnessed and registered. The complainant was furious. He said the land was entirely his and Ibrahim had no right to sell even an inch of it. But instead of going to a civil court and saying "This land is mine, cancel those sale deeds," the complainant went to the police and said Ibrahim was a forger and a cheat — that he had created "fake" documents. The police investigated and filed criminal charges. Ibrahim tried to get the charges dropped, but the local Magistrate said no, and the High Court also said no. Finally, the Supreme Court stepped in and asked the most basic question: If a man signs a sale deed in his own name, selling land he claims is his — even if it actually belongs to someone else — is that forgery? The Supreme Court said: No. Forgery means pretending to be someone else. Ibrahim didn't pretend to be the complainant. He signed as himself. He may have been wrong about who owned the land, but being wrong about ownership is something you settle in a civil court, not a criminal court.

### THE STORY IN LEGAL LANGUAGE:

The second respondent-complainant filed a complaint before the CJM, Madhubani, alleging that the first appellant had no title to certain agricultural land (Katha No. 715, Khasra Nos. 1971 and 1973) but had nonetheless executed two registered sale deeds dated 02.06.2003 in favour of the second appellant, purporting to convey 8 Khatas and 13 Dhurs therefrom. Appellants 3-5 (witness, scribe, and stamp vendor) were alleged to have conspired in the execution. Cognizance was taken under Sections 323, 341, 420, 467, 471, and 504 IPC, and the matter was referred for investigation under Section 156(3) CrPC. The first appellant's defence was one of bona fide title: he claimed inheritance through his mother Girja, who received her share in a family partition from her father Mithu Mian (brother of the complainant's grandfather Badri Mian). The SDM rejected the discharge application; the Patna High Court dismissed the Section 482 petition. The Supreme Court, exercising appellate jurisdiction under Article 136, examined whether the complaint averments — even assumed to be true in their entirety — disclosed the statutory ingredients of the charged offences. It held they did not, except for Sections 323 and 341.

---

## 1.3 PROCEDURAL JOURNEY

| # | Stage | Forum | Date | Outcome | What Was Decided |
|---|-------|-------|------|---------|-----------------|
| 1 | Private complaint filed | Chief Judicial Magistrate, Madhubani | — | Complaint received | Complainant alleged forgery, cheating, hurt, restraint, insult |
| 2 | Cognizance taken | CJM, Madhubani | 19.07.2003 | Cognizance under Ss. 323, 341, 420, 467, 471, 504 IPC | Prima facie case found; referred for investigation u/s 156(3) CrPC |
| 3 | FIR registered | Pandaul Police Station | 10.10.2003 | Investigation commenced | FIR registered based on Magistrate's order |
| 4 | Charge-sheet filed | Before SDM, Madhubani | 04.09.2004 | Charges against accused 1-5 | Investigating Officer recommended prosecution |
| 5 | Discharge application | Sub-Divisional Magistrate, Madhubani | 14.12.2005 | **Rejected** | SDM held sufficient material existed for framing charges |
| 6 | Charges framed | SDM, Madhubani | During pendency of s.482 petition | Charges framed under all sections | Accused put to trial |
| 7 | S.482 CrPC quashing petition | Patna High Court | Not specified | **Dismissed** | HC observed Magistrate had found sufficient material showing complicity |
| 8 | SLP filed | Supreme Court of India | 2007 | Leave granted | — |
| 9 | Criminal Appeal heard | Supreme Court of India | 04.09.2009 | **Allowed in part** | Ss. 420, 467, 471, 504 quashed; Ss. 323, 341 left undisturbed |

**Key Procedural Observation:** The complaint-to-Supreme Court journey took approximately 6 years (2003-2009). During this period, the accused remained under the shadow of charges carrying imprisonment for life (S.467). The procedural oppression is itself part of the judgment's subtext — the Supreme Court's intervention was to prevent exactly this kind of prolonged criminal harassment in what was essentially a civil dispute.

---

## 1.4 LEGAL PROVISIONS ENGAGED

**PROVISION 1: Section 464 IPC — Making a False Document**
```
Provision              : Section 464, Indian Penal Code, 1860
Exact Text             : [Extracted in full at ¶9 of judgment — defines three 
                          categories: Firstly (impersonation/false authority), 
                          Secondly (unauthorized alteration), Thirdly (deception 
                          of incapacitated person)]
Role                   : PRIMARY INTERPRETATION TARGET — The definitional nucleus
                          of the entire judgment. Every other conclusion flows from
                          whether the sale deeds meet this definition.
What the Court Did     : INTERPRETED — Held that execution of a sale deed by a 
                          person in his own name, claiming property as his own, does
                          not fall under ANY of the three categories. Therefore, no
                          "false document" was made.
```

**PROVISION 2: Section 463 IPC — Forgery**
```
Provision              : Section 463, Indian Penal Code, 1860
Exact Text             : "Whoever makes any false documents with intent to cause 
                          damage or injury to the public or to any person, or to 
                          support any claim or title... commits forgery."
Role                   : SUPPORTING DEFINITION — Defines "forgery" as requiring a 
                          "false document" (the output of S.464). Functions as the 
                          conceptual bridge between S.464 and Ss. 467/471.
What the Court Did     : INTERPRETED — Since no false document under S.464, no 
                          forgery under S.463.
```

**PROVISION 3: Section 467 IPC — Forgery of Valuable Security**
```
Provision              : Section 467, Indian Penal Code, 1860
Exact Text             : "Whoever forges a document which purports to be a valuable 
                          security... shall be punished with imprisonment for life, 
                          or with imprisonment of either description for a term which
                          may extend to ten years, and shall also be liable to fine."
Role                   : CHARGED PROVISION — The most serious charge, carrying life 
                          imprisonment. Its applicability is the central dispute.
What the Court Did     : QUASHED — No forgery → S.467 not attracted.
```

**PROVISION 4: Section 471 IPC — Using Forged Document as Genuine**
```
Provision              : Section 471, Indian Penal Code, 1860
Exact Text             : "Whoever fraudulently or dishonestly uses as genuine any 
                          document which he knows or has reason to believe to be a 
                          forged document, shall be punished in the same manner as 
                          if he had forged such document."
Role                   : CHARGED PROVISION — Dependent on existence of a "forged 
                          document."
What the Court Did     : QUASHED — No forged document exists → S.471 not attracted.
```

**PROVISION 5: Sections 415 & 420 IPC — Cheating**
```
Provision              : Sections 415 (definition) and 420 (punishment) IPC
Exact Text             : S.415: "Whoever, by deceiving any person, fraudulently or 
                          dishonestly induces the person so deceived to deliver any 
                          property..."
                          S.420: Enhanced punishment when cheating involves inducement 
                          to deliver property or alter/destroy valuable security.
Role                   : CHARGED PROVISION — Court examines whether the complainant 
                          (who is NOT the purchaser) has locus to allege cheating.
What the Court Did     : INTERPRETED & QUASHED — The complainant was not the person 
                          "deceived" or "induced" — the purchaser was. Since the 
                          purchaser is a co-accused (not a complainant), no cheating 
                          is established vis-à-vis the complainant.
```

**PROVISION 6: Section 470 IPC — Forged Document**
```
Provision              : Section 470, Indian Penal Code, 1860
Exact Text             : "A false document made wholly or in part by forgery is 
                          designated 'a forged document'."
Role                   : SUPPORTING DEFINITION — Connects the "false document" 
                          (S.464) to the "forged document" (used in Ss. 467, 471).
What the Court Did     : INTERPRETED — Since no false document, no forged document.
```

**PROVISION 7: Section 504 IPC — Intentional Insult**
```
Provision              : Section 504, Indian Penal Code, 1860
Exact Text             : "Whoever intentionally insults, and thereby gives 
                          provocation to any person, intending or knowing it to be 
                          likely that such provocation will cause him to break the 
                          public peace..."
Role                   : CHARGED PROVISION.
What the Court Did     : QUASHED — The statement attributed to the accused ("we will 
                          get possession, do what you want") is assertion of a legal 
                          position, not intentional insult. (¶17)
```

**PROVISIONS 8 & 9: Sections 323 & 341 IPC — Causing Hurt & Wrongful Restraint**
```
Provision              : Sections 323 and 341, Indian Penal Code, 1860
Role                   : CHARGED PROVISIONS — Only provisions whose ingredients are 
                          technically made out on the complaint averments ("abused 
                          him and hit him with fists").
What the Court Did     : LEFT UNDISTURBED — Charges sustained.
```

**PROVISION 10: Section 156(3) CrPC — Magistrate's Power to Order Investigation**
```
Provision              : Section 156(3), Code of Criminal Procedure, 1973
Role                   : PROCEDURAL VEHICLE — Basis on which the CJM referred the 
                          complaint for police investigation.
What the Court Did     : Not directly interpreted — procedural backdrop.
```

**PROVISION 11: Section 482 CrPC — Inherent Powers of High Court**
```
Provision              : Section 482, Code of Criminal Procedure, 1973
Role                   : PROCEDURAL VEHICLE — Basis for the High Court petition 
                          that was dismissed.
What the Court Did     : The High Court's exercise of s.482 power was set aside 
                          by the Supreme Court.
```

**PROVISION 12: Section 25 IPC — "Fraudulently"**
```
Provision              : Section 25, Indian Penal Code, 1860
Exact Text             : "A person is said to do a thing 'fraudulently' if he does 
                          that thing with intent to defraud but not otherwise."
Role                   : SUPPORTING DEFINITION — Used in the ¶15-16 clarification 
                          on fraud vs. criminal offence.
What the Court Did     : INTERPRETED — Established that acting "fraudulently" is 
                          not per se an offence; only specific fraudulent acts 
                          enumerated in the Code are offences.
```

**PROVISION 13: Section 24 IPC — "Dishonestly"**
```
Provision              : Section 24, Indian Penal Code, 1860
Exact Text             : "Whoever does anything with the intention of causing 
                          wrongful gain to one person or wrongful loss to another 
                          person is said to do that thing 'dishonestly'."
Role                   : SUPPORTING DEFINITION — Paired with S.25 in the fraud 
                          analysis.
What the Court Did     : REFERRED — Quoted for definitional completeness.
```

**PROVISION 14: Section 17, Indian Contract Act, 1872 — "Fraud"**
```
Provision              : Section 17, Indian Contract Act, 1872
Role                   : CROSS-REFERENCE — The court notes that the IPC does not 
                          define "fraud" but the Contract Act does (¶15).
What the Court Did     : REFERRED — For comparative definitional context.
```

---

## 1.5 PRECEDENT REGISTRY

**PRECEDENT 1:**
```
Case Cited             : G. Sagar Suri v. State of U.P.
Citation               : 2000 (2) SCC 636
What That Case Held    : Courts must be vigilant against the growing tendency of 
                          complainants attempting to give a criminal cloak to matters 
                          that are essentially civil in nature — done either to apply 
                          pressure on the accused, out of enmity, or to subject the 
                          accused to harassment. Criminal courts must not be used for 
                          settling scores or pressurizing parties to settle civil disputes.
Why This Court Cited It: To establish the foundational GATEKEEPING PRINCIPLE that 
                          frames the entire analysis — the court examines the complaint 
                          through this lens of filtering genuine criminal conduct from 
                          disguised civil disputes.
Treatment              : FOLLOWED — Adopted as a framing principle.
Paragraph Referenced   : ¶7
```

**PRECEDENT 2:**
```
Case Cited             : Indian Oil Corporation vs. NEPC India Ltd.
Citation               : 2006 (6) SCC 736
What That Case Held    : While courts must guard against misuse of criminal process 
                          for civil disputes, they must equally recognize that several 
                          civil disputes may also contain ingredients of criminal 
                          offences. If criminal ingredients exist, the dispute must be 
                          tried as a criminal case even if it also constitutes a civil 
                          dispute.
Why This Court Cited It: To provide the BALANCING COUNTER-PRINCIPLE — civil nature 
                          alone does not immunize conduct from criminal prosecution. 
                          The court cites both G. Sagar Suri AND IOC v. NEPC together 
                          to construct a two-sided framework: protect against misuse, 
                          but don't over-protect genuine criminal conduct.
Treatment              : FOLLOWED — Adopted as a balancing principle.
Paragraph Referenced   : ¶7
```

**PRECEDENT 3:**
```
Case Cited             : Dr. Vimla vs. Delhi Administration
Citation               : AIR 1963 SC 1572
What That Case Held    : The expression "defraud" involves two elements: (a) deceit, 
                          and (b) injury to the person deceived. "Injury" is broader 
                          than economic loss — it includes any harm to body, mind, 
                          reputation, or other interests. A benefit to the deceiver 
                          will almost always cause loss to the deceived, and even 
                          where there is no corresponding loss, the condition of 
                          "injury" is still satisfied if there was deceit.
Why This Court Cited It: Used in the CLARIFICATION section (¶15) to define the 
                          conceptual boundaries of "defraud" — establishing that 
                          while selling another's property CAN constitute fraud, the 
                          person defrauded is the PURCHASER, not the true owner as 
                          a third party.
Treatment              : FOLLOWED — Definition adopted and applied.
Paragraph Referenced   : ¶15
```

**PRECEDENT 4:**
```
Case Cited             : State of UP vs. Ranjit Singh
Citation               : 1999 (2) SCC 617
What That Case Held    : Reiterated the definition of "defraud" from Dr. Vimla vs. 
                          Delhi Administration in substance.
Why This Court Cited It: To confirm that the Dr. Vimla definition is settled and 
                          undisturbed law — adding a reaffirmation layer.
Treatment              : REAFFIRMED — Cited for continuity.
Paragraph Referenced   : ¶15
```

---

## 1.6 RATIO DECIDENDI (The Binding Principle)

**RATIO 1 — On "False Document" / Forgery (Primary Ratio):**

The execution of a document (such as a sale deed) by a person in his own name, claiming a property as his own — even if the property does not belong to him — does not constitute making a "false document" within the meaning of Section 464 of the Indian Penal Code. A "false document" under Section 464 requires: (a) that the maker intended it to be believed that the document was made by or by the authority of some OTHER person; or (b) that the document was materially altered without lawful authority; or (c) that the signature was obtained by deceiving an incapacitated person. A false claim of ownership is fundamentally different from impersonation or false claim of authority. Without a "false document," there is no forgery under Section 463, and consequently neither Section 467 (forgery of valuable security) nor Section 471 (using forged document as genuine) is attracted.

**RATIO 2 — On Cheating / Locus of Complainant:**

In a sale transaction where the seller's title is disputed, only the purchaser — the person actually deceived and induced to part with consideration — has locus standi to allege cheating under Sections 415-420 IPC. A third party claiming to be the true owner of the property sold, upon whom no deception was practised and to whom no inducement was offered, cannot maintain a complaint of cheating.

**RATIO 3 — On Criminal-Civil Demarcation at Discharge/Charge Stage:**

Where complaint averments, even if assumed to be true in their entirety, do not disclose the statutory ingredients of the criminal offences charged, the proceedings in respect of those charges must be quashed — irrespective of whether the underlying conduct may give rise to civil remedies.

---

## 1.7 OBITER DICTA

**OBITER 1 — Fraud Per Se Is Not An Offence (¶15-16):**
Merely alleging or showing that a person acted "fraudulently" does not establish a criminal offence under the Indian Penal Code. The Penal Code does not make fraud per se an offence — it enumerates thirteen specific categories of fraudulent acts that are made offences (listed at ¶16: fraudulent removal of property, fraudulent claim to property, fraudulent acts relating to coins, stamps, weights, cheating, fraudulent execution of deeds, forgery, etc.). A fraudulent act is punishable only if it falls within one of these enumerated categories.

**Why this matters for future cases:** This obiter provides a complete taxonomy of criminal fraud under the IPC. It forces prosecutors to identify WHICH SPECIFIC fraudulent act provision applies, rather than making vague allegations of "fraud." It is also a checklist for defence counsel to argue: "My client's act, even if fraudulent, does not fall under any of the thirteen enumerated categories."

**OBITER 2 — The Purchaser's Preserved Remedy (¶14-15):**
If a person sells property knowing it does not belong to him, and thereby defrauds the person who purchased the property, the person defrauded (i.e., the purchaser) may file a complaint that the vendor committed cheating. This remedy is expressly preserved even as the third-party owner's criminal remedy is denied.

**Why this matters:** This is an escape valve — the court ensures its judgment cannot be read as making property fraud completely non-criminal. The purchaser's remedy survives. This obiter will be the basis of future prosecutions where the purchaser (not the owner) is the complainant.

**OBITER 3 — Civil-Criminal Overlap Not Blanket Bar (¶7):**
Several disputes of a civil nature may also contain ingredients of criminal offences, and if so, will have to be tried as criminal offences even if they simultaneously constitute civil disputes.

**Why this matters:** Prevents this judgment from being cited as a blanket bar against all criminal proceedings in property disputes. The gatekeeping principle is a filter, not a wall.

---

## 1.8 OPERATIVE ORDER

```
The appeal is allowed in part.

1. The order of the Patna High Court is SET ASIDE.

2. The order dated 14.12.2005 of the Sub-Divisional Magistrate, Madhubani 
   is QUASHED insofar as offences under Sections 420, 467, 471 and 504 IPC.

3. Consequently, the charges framed under Sections 420, 467, 471 and 504 IPC 
   are QUASHED.

4. The order dated 14.12.2005 and the charges insofar as offences under 
   Sections 323 and 341 IPC are LEFT UNDISTURBED.
```

---

# ═══════════════════════════════════════════════════════
# DIMENSION 2: THE STRUCTURAL
# (How the reasoning is architecturally built)
# ═══════════════════════════════════════════════════════

---

## 2.1 THE LOGICAL SYLLOGISMS (The Judgment's DNA)

### SYLLOGISM 1 — The Definitional Gate: Is There a "False Document"? (¶8-12)

```
MAJOR PREMISE (Rule):
  A "false document" under Section 464 IPC exists ONLY when:
  Category (a): The maker dishonestly/fraudulently makes a document with 
                the INTENTION of causing it to be believed that the document 
                was made or executed BY ANOTHER PERSON or BY THE AUTHORITY 
                OF another person, by whom or by whose authority the maker 
                knows it was not made; OR
  Category (b): A document is altered in any material part without lawful 
                authority after execution; OR
  Category (c): A person's signature is obtained through deception or from 
                a person of unsound mind/intoxicated.

MINOR PREMISE (Fact):
  The first accused executed the sale deeds:
  - In his OWN name (not in the complainant's name)
  - As HIMSELF (not impersonating the complainant)
  - Not claiming authorization from the complainant
  - Not altering any pre-existing document
  - Not obtaining any incapacitated person's signature
  → None of the three categories are met.

CONCLUSION:
  The sale deeds are NOT "false documents" under Section 464 IPC.
```

### SYLLOGISM 2 — The Forgery Chain: No False Document → No Forgery (¶8-9, 12)

```
MAJOR PREMISE (Rule):
  "Forgery" under Section 463 requires the "making of a false document."
  Section 470 defines a "forged document" as "a false document made wholly 
  or in part by forgery."
  Sections 467 and 471 require a "forged document" to be attracted.

MINOR PREMISE (Fact):
  CONCLUSION OF SYLLOGISM 1: The sale deeds are NOT false documents.
  → Therefore, no false document has been made.

CONCLUSION:
  No false document → No forgery (S.463) → No forged document (S.470)
  → Section 467 NOT ATTRACTED → Section 471 NOT ATTRACTED.
```

### SYLLOGISM 3 — The Cheating Chain: Who Was Deceived? (¶13-14)

```
MAJOR PREMISE (Rule):
  "Cheating" under Section 415 requires:
  (a) Deception of A PERSON
  (b) Fraudulent/dishonest inducement of THAT PERSON to deliver property 
      or act/omit in a way they wouldn't otherwise
  (c) Resulting damage/harm to THAT PERSON
  Section 420 additionally requires: dishonest inducement to deliver 
  property or alter/destroy a valuable security.
  CRITICAL: The person deceived, the person induced, and the person 
  suffering damage must be THE SAME PERSON (or at least the deception must 
  be directed at the complainant).

MINOR PREMISE (Fact):
  (a) The complainant was NOT the purchaser under the sale deeds.
      The purchaser (second accused) is a CO-ACCUSED, not a victim.
  (b) No deception was practised UPON the complainant by any accused.
  (c) No inducement was offered TO the complainant to deliver property.
  (d) The first accused did NOT impersonate the complainant.
  → The complainant is NOT the "person deceived" within S.415.

CONCLUSION:
  Ingredients of cheating absent vis-à-vis the complainant.
  → Sections 415, 417, 418, 419, 420 IPC ALL NOT ATTRACTED.
```

### SYLLOGISM 4 — The Insult Chain: Legal Assertion ≠ Insult (¶17)

```
MAJOR PREMISE (Rule):
  Section 504 requires "intentional insult" with "intent to provoke breach 
  of the public peace."

MINOR PREMISE (Fact):
  The statement attributed to accused 1 and 2 — "they will obtain 
  possession of land under the sale deeds and he can do whatever he wants" 
  — is an assertion of a perceived legal consequence of the transaction. 
  It is a statement about what the accused believe the sale deeds entitle 
  them to. It is not an "insult."

CONCLUSION:
  S.504 NOT ATTRACTED.
```

### SYLLOGISM 5 — The Surviving Charges: Physical Acts Survive (¶18)

```
MAJOR PREMISE (Rule):
  Section 323 requires "voluntarily causing hurt."
  Section 341 requires "wrongful restraint."
  Both require physical acts directed at the complainant.

MINOR PREMISE (Fact):
  The complaint alleges the accused "abused him and hit him with fists."
  This allegation, if assumed true, technically satisfies the ingredients 
  of hurt (S.323) and may satisfy wrongful restraint (S.341).

CONCLUSION:
  Sections 323 and 341 ATTRACTED — charges undisturbed.
```

### SYLLOGISM 6 — The Meta-Syllogism: Quashing Standard (¶6-7, 18-19)

```
MAJOR PREMISE (Rule):
  When examining whether charges should be quashed (under S.482 CrPC or 
  appellate jurisdiction), the court must ask: Do the complaint averments, 
  even if assumed to be true in their entirety, disclose the ingredients of 
  the offences charged? If not, the charges must be quashed.
  (Per G. Sagar Suri and IOC v. NEPC India Ltd.)

MINOR PREMISE (Fact):
  CONCLUSIONS OF SYLLOGISMS 1-5:
  - Ss. 467, 471: Not attracted (no false document/forgery)
  - S. 420: Not attracted (no deception of complainant)
  - S. 504: Not attracted (no insult)
  - Ss. 323, 341: Attracted (physical assault alleged)

CONCLUSION:
  Charges under Ss. 420, 467, 471, 504 QUASHED.
  Charges under Ss. 323, 341 LEFT UNDISTURBED.
```

### CHAIN LOGIC MAP:

```
SYLLOGISM 1 (No false document)
      │
      └──→ feeds into SYLLOGISM 2 (No forgery → Ss.467/471 quashed)
      
SYLLOGISM 3 (No deception of complainant → S.420 quashed) ← INDEPENDENT

SYLLOGISM 4 (No insult → S.504 quashed) ← INDEPENDENT

SYLLOGISM 5 (Physical assault alleged → Ss.323/341 sustained) ← INDEPENDENT

SYLLOGISMS 2 + 3 + 4 + 5 ──→ feed into SYLLOGISM 6 (Meta: partial quashing)
```

**Architectural Note:** The four substantive syllogisms (1-2, 3, 4, 5) are COMPLETELY INDEPENDENT of each other. Each stands or falls on its own logic. The failure of any one syllogism would not affect any other. This is an architecturally clean, modular judgment — each offence analysed in isolation, each conclusion self-contained.

---

## 2.2 THE DEPENDENCY TREE

```
ROOT: OPERATIVE ORDER (Partial Quashing)
│
├── BRANCH A: Quashing of Ss. 467/471 (Forgery-related)
│   │
│   ├── DEPENDS ON: Sale deeds are NOT "false documents" under S.464 (¶12)
│   │   │
│   │   ├── DEPENDS ON [FACT]: First accused signed in his OWN name
│   │   │
│   │   ├── DEPENDS ON [FACT]: No allegation of impersonation of complainant
│   │   │
│   │   ├── DEPENDS ON [FACT]: No claim of acting on complainant's authority
│   │   │
│   │   ├── DEPENDS ON [LAW]: S.464 "Firstly" requires intent that document
│   │   │   be believed to be made BY or BY AUTHORITY OF another person
│   │   │   │
│   │   │   └── HIDDEN DEPENDENCY [INTERPRETATION]: The word "person" here
│   │   │       means a SPECIFIC IDENTIFIABLE INDIVIDUAL, not "the true owner" 
│   │   │       as an abstract legal concept
│   │   │       │
│   │   │       └── HIDDEN DEPENDENCY [DOCTRINE]: Strict construction of penal 
│   │   │           statutes — "person" is read narrowly as personal identity, 
│   │   │           not legal capacity
│   │   │
│   │   ├── DEPENDS ON [LAW]: S.464 "Secondly" requires material alteration —
│   │   │   no existing document was altered
│   │   │
│   │   └── DEPENDS ON [LAW]: S.464 "Thirdly" requires deception of 
│   │       incapacitated person — not applicable
│   │
│   └── DEPENDS ON: No false document → no forgery (S.463) → 
│       no forged document (S.470) → Ss. 467, 471 not attracted
│
├── BRANCH B: Quashing of S. 420 (Cheating)
│   │
│   ├── DEPENDS ON [FACT]: Complainant is NOT the purchaser (¶14)
│   │
│   ├── DEPENDS ON [FACT]: Purchaser is a CO-ACCUSED (¶14)
│   │
│   ├── DEPENDS ON [FACT]: No deception practised on complainant (¶14)
│   │
│   ├── DEPENDS ON [FACT]: No allegation of impersonation (¶14)
│   │
│   └── DEPENDS ON [LAW]: S.415 requires deception of "a person" + 
│       inducement of "that person" → both must be the complainant
│       │
│       └── HIDDEN DEPENDENCY [INTERPRETATION]: "Deception" in S.415 
│           means DIRECT, face-to-face deception of a specific person, 
│           not INDIRECT harm caused by a fraudulent transaction to 
│           an absent party
│
├── BRANCH C: Quashing of S. 504 (Insult)
│   │
│   └── DEPENDS ON [FACT-CHARACTERIZATION]: The statement "we will get 
│       possession, do what you want" is characterized as LEGAL ASSERTION, 
│       not INSULT (¶17)
│       │
│       └── NOTE: This is a factual characterization, not a legal 
│           interpretation. A different characterization of the same 
│           words (e.g., reading them as provocative/threatening in 
│           their tone and context) could yield a different result.
│
└── BRANCH D: Sustaining Ss. 323/341 (Hurt/Restraint)
    │
    └── DEPENDS ON [FACT]: Complaint alleges "hit him with fists" (¶18)
        │
        └── NOTE: This is the ONLY factual allegation that survived the 
            ingredient analysis. The entire criminal case, after quashing, 
            reduces to a simple hurt case.
```

---

## 2.3 THE JUDGE'S INTERPRETIVE METHOD FINGERPRINT

```
PRIMARY METHOD USED    : STRICT LITERAL / TEXTUAL INTERPRETATION
                         
                         The court parses Section 464 word by word. It identifies 
                         three categories of "false documents," places them side by 
                         side with the facts, and asks: do the facts fit within the 
                         words? The answer is no — not because the spirit of the law 
                         doesn't cover this, but because the WORDS don't.
                         
                         This is textbook literalism applied to a penal statute.

WHY THIS METHOD        : IMPLICIT — The court never explicitly states it is applying 
                         strict construction. It never says "penal statutes must be 
                         strictly construed." It never says "we adopt the literal 
                         meaning." The interpretive choice is MADE but never DECLARED.
                         
                         This is itself significant: by not declaring the method, the 
                         court avoids inviting debate about whether a different method 
                         should apply. It presents the literal reading as if it were 
                         the ONLY reading, making the conclusion feel inevitable rather 
                         than chosen.

WHAT WOULD CHANGE IF A DIFFERENT METHOD WERE USED:

  (A) PURPOSIVE INTERPRETATION:
      Question would become: What is the PURPOSE of Ss. 463-471?
      Answer: To prevent and punish document-based deception intended to 
      cause injury or support false claims.
      Application: A sale deed executed by a non-owner, intended to support 
      a false claim of title and to defraud the true owner of his property, 
      falls squarely within this purpose.
      LIKELY OUTCOME: Forgery charges SUSTAINED.
      
  (B) MISCHIEF RULE:
      Question would become: What MISCHIEF was S.464 enacted to suppress?
      Answer: The mischief of creating documents that mislead others about 
      their origin, authority, or authenticity.
      Application: A sale deed by a non-owner misleads the purchaser and the 
      Sub-Registrar about the seller's authority to convey. This IS the mischief.
      LIKELY OUTCOME: Forgery charges SUSTAINED (arguable).
      
  (C) HARMONIOUS CONSTRUCTION:
      Question would become: How should S.464 be read with S.463 (which 
      includes "intent to support any claim or title")?
      Application: S.463 explicitly covers documents made to "support any 
      claim or title." A sale deed by a non-owner is EXACTLY a document 
      made to support a false claim of title. Reading S.464 so narrowly 
      that it excludes this category creates disharmony with S.463.
      LIKELY OUTCOME: Forgery charges SUSTAINED (strong argument).

JUDGE'S INTERPRETIVE TENDENCY:
  Justice Raveendran, in this judgment, is a STRICT TEXTUALIST with respect 
  to penal provisions. He reads the statute as it is written, not as it 
  might be wished. He does not invoke the mischief rule, the purposive 
  method, or harmonious construction. His approach is: "If the words don't 
  cover it, it's not an offence. The remedy lies elsewhere (civil law)."
  
  This is consistent with the orthodox doctrine that penal statutes creating 
  offences must be strictly construed in favour of the accused — but 
  notably, the judgment never CITES this doctrine explicitly.
```

---

## 2.4 RHETORICAL ARCHITECTURE

```
OPENING MOVE:
  The judgment opens with PROCEDURAL FACTS (¶1-5): who filed what, where, 
  when, and what happened at each stage. This is a "setting the stage" 
  opening — it gives the reader the full history before posing the question.
  
  The FRAMING QUESTION appears at ¶6: "whether the material on record 
  prima facie constitutes any offences against the accused."
  
  Then ¶7 announces the GOVERNING PRINCIPLES (G. Sagar Suri + IOC v. NEPC) 
  before applying them. This is a PRINCIPLE-FIRST structure.

PERSUASION TECHNIQUE:
  ELIMINATIVE / CASCADING NEGATION — The court takes each charged offence 
  and eliminates it one by one:
  ¶8-12: Forgery → eliminated
  ¶13-14: Cheating → eliminated
  ¶15-16: Clarification on fraud (preemptive defence of its own reasoning)
  ¶17: Insult → eliminated
  ¶18: Hurt/restraint → survived
  
  This creates a RHETORICAL INEVITABILITY — by the time the reader reaches 
  ¶18, the conclusion feels inevitable. Each offence was tested, and each 
  failed. The cumulative effect is powerful.
  
  The CLARIFICATION section (¶15-16) is particularly notable — it is a 
  preemptive defence. The judge anticipates the objection ("are you saying 
  selling someone else's property is never criminal?") and answers it 
  BEFORE it is raised.

USE OF METAPHOR/ANALOGY:
  The court uses a STRUCTURAL DISTINCTION (¶12) rather than a metaphor:
  
  "There is a fundamental difference between a person executing a sale deed 
  CLAIMING THAT THE PROPERTY CONVEYED IS HIS PROPERTY, and a person 
  executing a sale deed by IMPERSONATING THE OWNER or FALSELY CLAIMING TO 
  BE AUTHORISED by the owner."
  
  This is the judgment's intellectual centerpiece — a conceptual dichotomy 
  that draws a bright line between civil wrong (false ownership claim) and 
  criminal offence (identity fraud). The power of this distinction lies in 
  its intuitive clarity: even a non-lawyer can grasp the difference between 
  "I'm selling MY land" and "I'm selling HIS land pretending to be him."

TONE:
  MEASURED, INSTRUCTIVE, AND CORRECTIVE — The judge is not angry at the 
  lower courts. He is not reprimanding. He is TEACHING. The judgment reads 
  like a law lecture — methodical, sequential, clause-by-clause. The 
  clarification section (¶15) is explicitly pedagogical: the judge steps 
  outside the case to explain a broader principle about fraud under the IPC.

STRATEGIC AMBIGUITY:
  YES — at two critical points:
  
  (1) ¶15: "When we say that execution of a sale deed by a person, 
  purporting to convey a property which is not his, as his property, is 
  not making a false document and therefore not forgery, WE SHOULD NOT BE 
  UNDERSTOOD AS HOLDING THAT SUCH AN ACT CAN NEVER BE A CRIMINAL OFFENCE."
  
  This is DELIBERATE ambiguity. The court quashes the forgery and cheating 
  charges but refuses to say the conduct is entirely non-criminal. It leaves 
  the door open for other provisions (S.423? S.421?) without naming them. 
  The court is PROTECTING ITS FLANK — ensuring this judgment cannot be 
  over-cited as a blanket immunity for property fraud.
  
  (2) ¶16: The court lists thirteen categories of specific fraudulent acts 
  made punishable under the IPC. This list is presented as a general 
  catalogue, not applied to the facts. The strategic implication: "We've 
  shown that forgery and cheating don't apply, but look at all these other 
  provisions that MIGHT apply in appropriate cases." This is a breadcrumb 
  trail for future prosecutors.
```

---

# ═══════════════════════════════════════════════════════
# DIMENSION 3: THE INVISIBLE
# (What the judgment hides — Sub-atomic extraction)
# ═══════════════════════════════════════════════════════

---

## 3.1 THE UNSTATED MAJOR PREMISES (Hidden Assumptions)

### HIDDEN ASSUMPTION 1: "Person" in S.464 Means Personal Identity, Not Legal Capacity

```
What the court assumes without stating:
  That when Section 464 says "intention of causing it to be believed that 
  such document was made by or by the authority of a PERSON by whom or by 
  whose authority he knows that it was not made," the word "person" refers 
  to a SPECIFIC NAMED INDIVIDUAL — not to a legal capacity, class, or 
  functional identity.

Where in the judgment this operates:
  ¶12 — "He is not claiming that he is someone else nor is he claiming 
  that he is authorised by someone else."

Why this matters:
  In property conveyancing, the seller's identity is INSEPARABLE from his 
  ownership status. When Ibrahim signs a sale deed, the document doesn't 
  just say "Ibrahim signed this." The deed says, in substance: "I, Ibrahim, 
  AS THE OWNER, hereby convey this property." The document represents 
  Ibrahim as having a LEGAL CAPACITY (ownership) that he does not possess.
  
  An alternative reading: when Ibrahim signs the sale deed "as owner," 
  the document is effectively made "by" a person (the owner) who didn't 
  actually make it. Ibrahim signed it, but the document purports to be the 
  act of "the owner" — and Ibrahim is not the owner. In this reading, 
  the "person" in S.464 is "the owner" — a legally identifiable entity 
  whose identity Ibrahim has functionally assumed.

How it could be challenged:
  Argue before a larger bench that "person" in S.464 Firstly should be 
  read to include "the person in the legal capacity claimed by the maker 
  of the document." A sale deed by a non-owner is functionally a document 
  made "by the authority of the owner" — an authority the maker doesn't 
  possess. This interpretation is textually defensible: "by whose authority 
  he knows it was not made" can encompass the authority of ownership.
```

### HIDDEN ASSUMPTION 2: The "Two Possibilities" Framing Exhausts the Universe

```
What the court assumes without stating:
  At ¶12, the court frames the situation as having exactly two possibilities 
  when a person executes a sale deed for property that isn't his:
  (a) He bonafide believes the property belongs to him; OR
  (b) He dishonestly claims it as his even though he knows it's not his.
  
  The court then says that NEITHER possibility constitutes a "false document."
  
  But this framing silently EXCLUDES a third possibility:
  (c) He knows the property belongs to someone else AND executes the deed 
  with the SPECIFIC INTENT to dispossess that person — not merely claiming 
  ownership, but actively weaponizing the registered document to create a 
  false legal record that can be used against the true owner.

Where in the judgment this operates:
  ¶12 — "When a person executes a document conveying a property describing 
  it as his, there are two possibilities..."

Why this matters:
  Possibility (c) is qualitatively different from (a) and (b). In (c), the 
  document is not merely a "false claim of ownership" — it is a TOOL OF 
  DISPOSSESSION. The intent is not just to sell, but to create a paper 
  trail that will be used in future litigation or revenue proceedings to 
  oust the true owner. This is arguably closer to "forgery" in its mischief 
  than a simple ownership dispute.

How it could be challenged:
  Present facts showing that the accused created the sale deed as part of 
  a SCHEME to dispossess the true owner — e.g., followed by mutation 
  applications, revenue record changes, and eviction proceedings. Argue that 
  this transforms the act from "false ownership claim" to "systematic 
  document-based fraud" that falls within the mischief of the forgery 
  provisions even under a strict reading.
```

### HIDDEN ASSUMPTION 3: Strict Construction Applies (Unstated Doctrine)

```
What the court assumes without stating:
  That penal statutes creating offences must be strictly construed in favour 
  of the accused. The court APPLIES this doctrine throughout its analysis 
  (giving S.464 its narrowest possible reading) but NEVER STATES it.

Where in the judgment this operates:
  Every interpretive choice point in ¶8-17. At each juncture where a broader 
  reading was available, the court chose the narrower reading — consistently 
  and without exception. This pattern is the fingerprint of strict construction.

Why this matters:
  By not stating the doctrine, the court:
  (a) Avoids inviting counter-arguments about exceptions to strict construction
  (b) Avoids engaging with the purposive interpretation doctrine
  (c) Presents its conclusions as textually inevitable rather than doctrinally chosen
  
  If the court had said "we apply strict construction," an opponent could 
  have responded: "But strict construction yields to the mischief rule when 
  the literal reading produces an absurd result" — and argued that leaving 
  the true owner without ANY criminal remedy when his property is 
  fraudulently sold IS an absurd result.

How it could be challenged:
  In a future case, explicitly invoke the mischief rule or purposive 
  interpretation and argue that Md. Ibrahim's narrow reading of S.464 was 
  the product of unstated strict construction doctrine which should not 
  apply when it produces manifestly unjust results.
```

### HIDDEN ASSUMPTION 4: The Complainant is a "Third Party" Stranger to the Transaction

```
What the court assumes without stating:
  That the complainant (the true owner) has the same legal relationship 
  to the sale transaction as any random bystander — i.e., no direct 
  connection. The court frames the cheating analysis as: "was the 
  complainant deceived?" and answers "no, because no deception was 
  directed at him."

Where in the judgment this operates:
  ¶14 — "It is not the case of the complainant that any of the accused 
  tried to deceive him either by making a false or misleading representation 
  or by any other action or omission."

Why this matters:
  The complainant is NOT a random bystander. He is the DIRECT VICTIM of 
  the transaction — the person whose property rights are being undermined 
  by the creation of a competing title document. The registered sale deed, 
  once in existence, can be used:
  (a) To seek mutation in revenue records (dispossessing the true owner)
  (b) To file a civil suit for possession (forcing the true owner to defend)
  (c) To resist the true owner's civil suit (creating a cloud on title)
  (d) As evidence in any future proceeding
  
  The true owner is not merely "not deceived" — he is ACTIVELY INJURED 
  by the transaction. The court's framing of him as a third party with 
  no standing to allege cheating ignores the reality of property fraud in 
  India, where registered documents create presumptions of title.

How it could be challenged:
  Argue that "deception" under S.415 should be read to include the 
  creation of a false legal record that operates as a CONTINUING DECEPTION 
  upon all persons whose rights are affected — including the true owner. 
  The registered deed deceives not just the purchaser, but the revenue 
  authorities, courts, and all future persons who rely on the register.
```

### HIDDEN ASSUMPTION 5: The Registration System is Neutral (Sub-Registrar as Passive Recorder)

```
What the court assumes without stating:
  That the Sub-Registrar merely registers what is presented to him, without 
  being "deceived" in any legally relevant sense. The court never considers 
  the Sub-Registrar as a potential victim of the fraudulent representation.

Where in the judgment this operates:
  Absent — the Sub-Registrar is never mentioned in the analysis.

Why this matters:
  Under the Registration Act, 1908, the Sub-Registrar registers a deed 
  upon the executant's representation that he is entitled to execute it. 
  If this representation is false, the Sub-Registrar (a public servant 
  of the State) has been DECEIVED into performing an official act 
  (registration) that he would not have performed had he known the truth.
  
  This opens an entirely unexplored avenue: S.420 IPC with the STATE 
  (through the Sub-Registrar) as the person deceived.

How it could be challenged / exploited:
  A prosecution could frame the complaint with the Sub-Registrar as the 
  victim: "The accused deceived the Sub-Registrar into registering a sale 
  deed by falsely representing himself as the owner of the property." This 
  completely sidesteps the locus problem identified in Md. Ibrahim.
```

---

## 3.2 THE SILENT ARGUMENTS (Never Argued But Should Have Been)

### SILENT ARGUMENT 1: Section 423 IPC — The Provision That Should Have Been Charged

```
The argument:
  Section 423 IPC provides: "Whoever dishonestly or fraudulently signs, 
  executes or becomes a party to any deed or instrument which purports to 
  transfer or subject to any charge any property, or any interest therein, 
  and which contains any false statement relating to the consideration for 
  such transfer or charge, or relating to the person or persons for whose 
  use or benefit it is really intended to operate, shall be punished..."
  
  The key phrase is: "false statement relating to the PERSON for whose use 
  or benefit it is really intended to operate." If the first accused was 
  not the true owner, then the sale deed contains a false statement about 
  the person for whose benefit it operates — it purports to benefit the 
  first accused (as seller receiving consideration) when he has no right 
  to receive that benefit.
  
  Furthermore: was the consideration accurately stated? If the sale was 
  a sham (colluded between accused 1 and 2), the stated consideration may 
  be false — directly attracting S.423.

Who should have made it:
  The Prosecution / Complainant's counsel — either at the complaint stage 
  or before the Magistrate.

Why it matters:
  The court ITSELF hints at this possibility. At ¶16, the court lists 
  S.423 among the thirteen specific fraudulent acts made punishable under 
  the IPC: "Fraudulent execution of deed of transfer containing false 
  statement of consideration (sec. 423)." This is a breadcrumb the court 
  dropped that the prosecution never picked up.
  
  Had S.423 been charged, the court would have had to analyze it 
  independently — and the textual analysis would be COMPLETELY DIFFERENT 
  from the forgery analysis, because S.423 doesn't require a "false 
  document" or "forgery" — it requires only a "false statement" in a 
  deed of transfer.

The provision: Section 423 IPC.
```

### SILENT ARGUMENT 2: The Sub-Registrar as Victim of S.420 Cheating

```
The argument:
  The first accused presented himself at the Sub-Registrar's office and 
  represented himself as the owner of the property. Based on this 
  representation, the Sub-Registrar — a public servant — registered the 
  deed. If the representation of ownership was false, the Sub-Registrar 
  was DECEIVED (element 1 of S.415) into performing an official act 
  (registration) that he would not have performed otherwise (element 2). 
  The registration creates a legal record that injures the true owner 
  (element 3).
  
  With the Sub-Registrar as the "person deceived," ALL ingredients of 
  S.415/420 are satisfied — and the locus problem disappears because the 
  complaint need not come from the Sub-Registrar personally.

Who should have made it:
  The Prosecution, or the Court suo motu during the quashing analysis.

Why it matters:
  This argument COMPLETELY NEUTRALIZES the court's locus finding on 
  cheating. The court held that the complainant (true owner) cannot allege 
  cheating because he was not the person deceived. But the Sub-Registrar 
  WAS deceived — and anyone can bring this to the notice of the court 
  or police.
  
  This argument also has implications far beyond this case: in EVERY 
  property fraud case where a sale deed is registered based on a false 
  representation of ownership, the Sub-Registrar is a potential victim 
  of cheating.

The provision: Sections 415/420 IPC, with the Sub-Registrar as the 
person deceived. Potentially S.420 read with S.466 (forgery by public 
servant, if the Sub-Registrar's involvement was induced by fraud).
```

### SILENT ARGUMENT 3: Alternative Prosecution Theory — Purchaser as Victim, Not Co-Accused

```
The argument:
  The prosecution made a critical strategic ERROR by making the purchaser 
  (second accused) a CO-ACCUSED. By doing so, they foreclosed the most 
  natural cheating argument: that the purchaser was the person deceived.
  
  An alternative framing was available: treat the purchaser as a GENUINE 
  INNOCENT BUYER who was defrauded by the first accused into paying for 
  property that didn't belong to the seller. Under this framing:
  - The purchaser is the "person deceived" (S.415)
  - The consideration paid is the "property delivered" (S.420)
  - The first accused's knowledge of non-ownership is the "dishonest 
    intention"
  - All ingredients of S.420 are met.
  
  The court itself ACKNOWLEDGES this at ¶14-15: "When a sale deed is 
  executed conveying a property claiming ownership thereto, it may be 
  possible for the purchaser under such sale deed, to allege that the 
  vendor has cheated him."

Who should have made it:
  The prosecution should have considered this at the FIR/charge-sheet stage. 
  It's a strategic decision: is the purchaser a co-conspirator or an 
  innocent victim? The prosecution chose "co-conspirator" without apparently 
  considering the consequences for the cheating charge.

Why it matters:
  This is a lesson in PROSECUTION STRATEGY. The same facts can support 
  two completely different theories — (a) all accused conspired together, 
  or (b) the first accused defrauded both the true owner (civilly) and 
  the purchaser (criminally). The prosecution chose theory (a), which 
  destroyed the only viable criminal cheating theory.
  
  For CourtCraft: This is the kind of strategic insight that should be 
  embedded in a document generation system — when drafting a complaint, 
  the system should flag: "Making the purchaser a co-accused will 
  foreclose S.420 cheating charges per Md. Ibrahim."

The provision: S.420 IPC, with the purchaser as the person deceived.
```

### SILENT ARGUMENT 4: Sections 464 "Firstly" Read Harmoniously with Section 463

```
The argument:
  Section 463 (forgery) includes within its definition: making a false 
  document with intent "to support any claim or title." This phrase — 
  "to support any claim or title" — is EXACTLY what the first accused 
  did: he made a document (sale deed) to support his claim of title to 
  the property.
  
  Now, the court reads S.464 (which defines "false document") so narrowly 
  that it EXCLUDES documents made to support false claims of title — 
  even though S.463 EXPRESSLY includes such intent.
  
  This creates an internal disharmony: S.463 says "intent to support any 
  claim or title" IS forgery, but S.464 says the document isn't "false" 
  unless there's impersonation. How can there be forgery (S.463) when 
  there's no false document (S.464)?
  
  The answer is that S.463 and S.464 are meant to be READ TOGETHER. The 
  intent listed in S.463 (supporting a claim or title) should INFORM the 
  interpretation of what constitutes a "false document" in S.464. Under 
  a harmonious reading, a document made to support a false claim of title 
  SHOULD qualify as a false document — because that's what the forgery 
  provision was designed to cover.

Who should have made it:
  The prosecution, at any stage. Alternatively, the Court suo motu under 
  the harmonious construction doctrine.

Why it matters:
  This is the strongest potential argument against the Md. Ibrahim ratio. 
  It doesn't require overruling the judgment — it requires REINTERPRETING 
  the relationship between S.463 and S.464. If accepted, it would mean 
  that S.464 Firstly should be read expansively to include documents that 
  falsely represent the maker's entitlement to execute them — when made 
  with the intent specified in S.463.

The provision: Section 463 read harmoniously with Section 464 IPC.
```

### SILENT ARGUMENT 5: Criminal Conspiracy (S.120B) as an Independent Offence

```
The argument:
  Even if the substantive offence of forgery is not made out, the 
  AGREEMENT between the accused to create and register a false sale deed 
  could independently constitute criminal conspiracy under S.120B IPC. 
  The crime of conspiracy lies in the AGREEMENT to do an illegal act — 
  the illegal act need not actually be completed. If the accused agreed 
  to create a sale deed for property they knew didn't belong to the first 
  accused, that agreement itself (to fraudulently transfer another's 
  property) could constitute a conspiracy to commit an offence under 
  S.421 (fraudulent removal of property) or S.423 (fraudulent execution 
  of deed), even if forgery (S.467) doesn't apply.

Who should have made it:
  The prosecution — either at the charge-sheet stage or before the court 
  during arguments.

Why it matters:
  S.120B is a catch-all that survives even when specific substantive 
  offences fail. The court never analyzed whether the agreement between 
  the accused (to create and register the sale deeds) independently 
  constituted conspiracy to commit S.421 or S.423.

The provision: S.120B IPC read with Ss. 421/423 IPC.
```

---

## 3.3 THE FACT-SENSITIVITY MATRIX

### LOAD-BEARING FACTS (Remove any one → outcome changes)

| # | Fact | Source ¶ | Load-Bearing Because |
|---|------|---------|---------------------|
| 1 | First accused executed sale deeds **in his own name, as himself** | ¶3, 12 | If he had signed as the complainant or as "authorized by the complainant" → Syllogism 1 collapses → S.464 Firstly directly attracted → forgery made out |
| 2 | The complainant is **not the purchaser** under the sale deeds | ¶14 | If the complainant were the purchaser → Syllogism 3 collapses → S.420 cheating directly applicable |
| 3 | The purchaser is **a co-accused** (alleged colluder) | ¶14 | If the purchaser were an independent innocent party → the prosecution could have framed the cheating complaint from the purchaser's perspective |
| 4 | **No allegation** that the first accused pretended to be the complainant | ¶12, 14 | If the complaint had alleged impersonation at the Sub-Registrar's office → both forgery and cheating would survive |
| 5 | The verbal statement was: "we will get possession, do what you want" | ¶17 | If the statement had been explicitly threatening, abusive, or containing slurs → S.504 charges might survive |

### DECORATIVE FACTS (Present but irrelevant to ratio)

| # | Fact | Source ¶ | Why Decorative |
|---|------|---------|---------------|
| 1 | Family arrangement between grandfathers Badri Mian and Mithu Mian | ¶3 | The court ASSUMES the complaint to be true (that the property belonged to the complainant). The actual ownership history is irrelevant to whether the charged offences are made out on the complaint averments |
| 2 | Specific land measurements (1 bigha, 5 Katha, 18 Dhurs / 8 Khatas, 13 Dhurs) | ¶2-3 | No impact on the legal analysis of whether S.464 is attracted |
| 3 | Third accused was witness, fourth was scribe, fifth was stamp vendor | ¶2 | Their specific roles are accessories to the principal act. If the principal act (execution by first accused) doesn't constitute forgery, their roles are irrelevant |
| 4 | First accused's name was entered in revenue records; he was paying land revenue | ¶3 | Irrelevant to the legal question (court assumes complaint to be true, meaning it assumes the property belonged to the complainant regardless of revenue records) |
| 5 | The two sale deeds were dated 02.06.2003 | ¶2 | The date has no bearing on the legal analysis |
| 6 | The accused were cousins (family relationship) | ¶3 | No impact on ingredient analysis. Same legal conclusion would follow even if they were complete strangers |

### AMBIGUOUS FACTS (Could be load-bearing or decorative — unclear)

| # | Fact | Source ¶ | Why Ambiguous |
|---|------|---------|--------------|
| 1 | Whether the first accused **knew** the property didn't belong to him versus bonafide believed it was his | ¶12 | The court explicitly creates a "two possibilities" framework (bonafide belief vs. dishonest claim) and says NEITHER constitutes forgery. But KNOWLEDGE + DISHONEST INTENT may push a court toward purposive interpretation. The court avoids deciding this factual question. |
| 2 | Whether the sale deeds were at market rate or at nominal consideration | Not addressed | If the consideration was nominal or sham, it strengthens the "fraudulent scheme" characterization and may attract S.423 (false statement of consideration). The judgment never examines this. |
| 3 | Whether the purchaser (second accused) knew the property didn't belong to the seller | ¶3 | This determines whether the purchaser was a genuine buyer (potential victim of cheating) or a colluding party (co-conspirator). The complaint alleges collusion, but the court never examines this distinction's impact on the cheating analysis. |

---

## 3.4 COUNTER-FACTUAL ANALYSIS (The "What If" Machine)

### COUNTER-FACTUAL 1: Impersonation

```
ORIGINAL FACT         : First accused signed sale deeds in his own name as himself.
ALTERED FACT          : First accused impersonated the complainant at the Sub-
                        Registrar's office — signed as the complainant, or used a 
                        forged power of attorney from the complainant.
IMPACT ON REASONING   : Syllogism 1 collapses completely. The document IS made 
                        "with the intention of causing it to be believed that such 
                        document was made by a person by whom he knows that it was 
                        not made." S.464 Firstly directly attracted.
LIKELY NEW OUTCOME    : Charges under Ss. 463, 464, 467, 468, 471 ALL SUSTAINED.
                        Case proceeds to trial.
APPLICABLE PROVISION  : Ss. 463, 464, 467, 468 (forgery for purpose of cheating), 
                        471 IPC — all attracted. S.420 also attracted because the 
                        complainant himself is now the person whose identity was 
                        misused.
PRACTITIONER VALUE    : This is the BRIGHT LINE. Any advocate facing forgery charges 
                        must first ask: "Did my client sign as himself or as 
                        someone else?" If as himself → Md. Ibrahim applies. If as 
                        someone else → Md. Ibrahim does NOT apply.
```

### COUNTER-FACTUAL 2: Complainant is the Purchaser

```
ORIGINAL FACT         : Complainant is the true owner (third party to the sale).
ALTERED FACT          : Complainant is the PURCHASER who bought the property and 
                        later discovered the seller had no title.
IMPACT ON REASONING   : Syllogism 3 collapses. The purchaser IS the person 
                        deceived, IS the person induced to part with consideration, 
                        IS the person suffering loss. All ingredients of S.415/420 
                        are satisfied.
LIKELY NEW OUTCOME    : S.420 charges SUSTAINED. The court itself explicitly 
                        preserves this possibility at ¶14-15.
APPLICABLE PROVISION  : Ss. 415, 417, 420 IPC — all attracted.
PRACTITIONER VALUE    : When advising a defrauded purchaser, ALWAYS file the 
                        complaint in the purchaser's name — not a third party's.
```

### COUNTER-FACTUAL 3: Complete Stranger (No Colourable Claim)

```
ORIGINAL FACT         : First accused claimed inheritance through family arrangement 
                        (at least a plausible counter-narrative of ownership).
ALTERED FACT          : First accused is a complete stranger to the land — a land 
                        grabber with zero connection, no family relationship, no 
                        colourable claim whatsoever.
IMPACT ON REASONING   : LEGALLY, the court's textual analysis of S.464 SHOULD NOT 
                        CHANGE — the statutory definition doesn't distinguish 
                        between "plausible false claims" and "brazen false claims."
                        
                        PRACTICALLY, judicial temperament shifts. When faced with a 
                        brazen land grabber, a court may be more inclined to:
                        (a) Adopt purposive interpretation of S.464
                        (b) Find that the "two possibilities" framework is inadequate
                        (c) Invoke S.423 or S.421 suo motu
                        (d) Hold that systematic land fraud engages additional 
                            provisions not considered in Md. Ibrahim
LIKELY NEW OUTCOME    : Uncertain but tilted toward sustaining some charges.
APPLICABLE PROVISION  : S.423 IPC becomes compelling; S.421 IPC (fraudulent removal 
                        of property) arguably applicable.
PRACTITIONER VALUE    : When defending against Md. Ibrahim being cited against your 
                        client, argue: "In Md. Ibrahim, the accused had at least a 
                        colourable claim through family arrangement. Here, the 
                        accused is a rank outsider with no claim whatsoever — the 
                        mischief is qualitatively different."
```

### COUNTER-FACTUAL 4: Supporting Fabricated Documents

```
ORIGINAL FACT         : First accused executed sale deeds only. No allegation of 
                        fabricating other supporting documents.
ALTERED FACT          : First accused also fabricated supporting documents — forged 
                        mutation entries, fabricated inheritance documents, fake 
                        revenue receipts — to build a paper trail of false ownership 
                        BEFORE executing the sale deeds.
IMPACT ON REASONING   : The sale deeds themselves may still not be "false documents" 
                        per Md. Ibrahim. BUT the fabricated mutation entries, 
                        inheritance certificates, and revenue receipts ARE false 
                        documents — because they purport to be made by or by the 
                        authority of government officials who didn't make them.
                        
                        This creates a SPLIT: the sale deeds don't attract Ss. 467/471, 
                        but the supporting fabricated documents DO. And if the 
                        supporting documents attract forgery, the sale deeds can be 
                        seen as part of the same conspiracy (S.120B).
LIKELY NEW OUTCOME    : Forgery charges sustained for the fabricated documents. 
                        Sale deeds remain non-forgery per Md. Ibrahim, but the overall 
                        prosecution survives.
APPLICABLE PROVISION  : Ss. 463, 464, 467, 468, 471, 120B IPC for the fabricated 
                        supporting documents.
PRACTITIONER VALUE    : When opposing Md. Ibrahim, investigate whether the accused 
                        created ANY other documents besides the sale deed — mutation 
                        applications, inheritance claims, revenue receipts. Each 
                        additional fabricated document is an independent forgery that 
                        Md. Ibrahim doesn't protect.
```

### COUNTER-FACTUAL 5: Explicit Threat Instead of Legal Assertion

```
ORIGINAL FACT         : Accused said "we will get possession, do what you want."
ALTERED FACT          : Accused said "we will break your legs if you come near the 
                        land" or used casteist/communal slurs.
IMPACT ON REASONING   : Syllogism 4 collapses. Explicit threats of violence satisfy 
                        S.504 (insult provoking breach of peace) and may also 
                        attract S.506 (criminal intimidation).
LIKELY NEW OUTCOME    : S.504 charges sustained; S.506 potentially added.
APPLICABLE PROVISION  : Ss. 504, 506 IPC.
PRACTITIONER VALUE    : Defence counsel should advise clients: in property disputes, 
                        NEVER make threats or provocative statements. Assert your 
                        position CALMLY. The Md. Ibrahim court drew a sharp line 
                        between "legal assertion" (non-criminal) and "provocation" 
                        (criminal).
```

### COUNTER-FACTUAL 6: BNS Instead of IPC (Forward-Looking)

```
ORIGINAL FACT         : Case decided under Indian Penal Code, 1860.
ALTERED FACT          : Same facts arise after 01.07.2024, governed by Bharatiya 
                        Nyaya Sanhita, 2023 (BNS).
IMPACT ON REASONING   : The BNS replaces IPC with new section numbers and 
                        potentially revised language:
                        - IPC S.464 → BNS S.336 (Making a false document)
                        - IPC S.463 → BNS S.335 (Forgery)
                        - IPC S.467 → BNS S.338 (Forgery of valuable security)
                        - IPC S.420 → BNS S.318 (Cheating)
                        
                        CRITICAL QUESTION: Does BNS S.336 use identical language 
                        to IPC S.464, or has the definition of "false document" 
                        been broadened? If the language is identical, Md. Ibrahim 
                        remains applicable. If broadened, the ratio may not apply.
LIKELY NEW OUTCOME    : [REQUIRES SEPARATE BNS STATUTORY ANALYSIS]
APPLICABLE PROVISION  : BNS Ss. 335, 336, 338, 318.
PRACTITIONER VALUE    : Before citing Md. Ibrahim in any post-01.07.2024 case, 
                        ALWAYS compare IPC S.464 with BNS S.336 word-for-word.
```

---

## 3.5 THE INTERPRETATION THAT WASN'T CHOSEN

### ALTERNATIVE INTERPRETATION 1: "Person" Includes Legal Capacity

```
What it would have been:
  Section 464 Firstly should be read to include documents that falsely 
  represent the maker's LEGAL CAPACITY — not just their personal identity. 
  A sale deed executed by a non-owner creates a false belief about WHO 
  made the document in the legally relevant sense: the document purports 
  to be the act of "the owner," and the maker is not the owner. The 
  "person by whom it was not made" is "the owner" — a legally identifiable 
  entity whose capacity the maker falsely assumed.

Why the court didn't adopt it:
  Never argued by counsel. The court confined its analysis to personal 
  identity (name) vs. legal capacity (ownership). The distinction between 
  these two was never raised, so it was never addressed.

Is it defensible?:
  YES — reasonably defensible. The word "person" in S.464 is not qualified 
  by "named person" or "identified individual." It can include "the person 
  entitled to execute the document." A conveyancing deed by its very nature 
  purports to be the act of the owner — and if the actual maker is not the 
  owner, the document IS a document "made by" a person who didn't make it.

What would change:
  Forgery charges sustained for all sale deeds executed by non-owners who 
  KNEW they were not owners. This would be a dramatic expansion of forgery 
  law in property disputes — effectively criminalizing all knowing sale of 
  another's property.
```

### ALTERNATIVE INTERPRETATION 2: S.463's "Support Any Claim or Title" Governs S.464

```
What it would have been:
  Section 463 defines forgery as making a false document with intent "to 
  support any claim or title." This specific intent — supporting a claim 
  or title — should INFORM what constitutes a "false document" in S.464. 
  If the legislature included "support any claim or title" as a forgery 
  intent, then documents made to support FALSE claims of title must be 
  capable of being "false documents" — otherwise S.463's "claim or title" 
  language becomes surplusage.

Why the court didn't adopt it:
  The court treated S.464 as a self-contained definition and never read 
  it harmoniously with S.463. The relationship between the two sections 
  was not analyzed.

Is it defensible?:
  HIGHLY DEFENSIBLE. The harmonious construction principle requires that 
  every word of a statute be given meaning. If S.464 is read so narrowly 
  that no document made to "support a claim or title" can be a false 
  document (unless there's impersonation), then the phrase "to support 
  any claim or title" in S.463 becomes meaningless. This is a strong 
  argument against the narrow reading.

What would change:
  S.464 would be interpreted to include documents containing false 
  representations of entitlement when made with the intent to support a 
  claim or title. The Md. Ibrahim ratio would be significantly narrowed 
  or overruled.
```

### ALTERNATIVE INTERPRETATION 3: "Indirect Deception" Under S.415

```
What it would have been:
  "Deception" under S.415 need not be face-to-face or directed at a 
  specific individual. The execution and registration of a false sale deed 
  operates as a SYSTEMIC DECEPTION — it creates a false public record that 
  deceives the revenue authorities, the registration system, any future 
  purchaser, any court that relies on the registered deed, AND the true 
  owner whose title is clouded.

Why the court didn't adopt it:
  The court read S.415 as requiring deception of "a person" — singular, 
  specific, directly addressed. The broader "systemic deception" reading 
  was not argued.

Is it defensible?:
  PARTIALLY — it stretches S.415's text, which does contemplate a specific 
  person being deceived. But in an era of registered documents operating 
  erga omnes, the narrow reading leaves a significant gap in criminal law.

What would change:
  True owners could maintain cheating complaints. The "locus gap" 
  identified in Md. Ibrahim would be closed. This would significantly 
  expand criminal liability in property fraud.
```

---

## 3.6 THE DOCTRINAL UNDERCURRENT

```
UNDERLYING DOCTRINE 1: STRICT CONSTRUCTION OF PENAL STATUTES
  How it manifests: The court gives S.464 its narrowest possible reading 
  at every choice point. Between "impersonation only" and "impersonation 
  OR false capacity," the court chooses the former. Between "direct 
  deception only" and "direct OR indirect deception," the court chooses 
  the former. Every interpretive fork is resolved in favour of the accused.

UNDERLYING DOCTRINE 2: SEPARATION OF CIVIL AND CRIMINAL REMEDIES
  How it manifests: The entire judgment operates on the implicit premise 
  that when a civil remedy exists (suit for declaration, injunction, 
  cancellation), criminal law should not be stretched to cover the same 
  ground unless the statutory ingredients are clearly met. The court never 
  SAYS this, but the judgment's entire thrust is: "Go to civil court."

UNDERLYING DOCTRINE 3: INGREDIENT-BASED ANALYSIS (vs. Spirit-Based)
  How it manifests: The court checks each statutory ingredient against the 
  facts with clinical precision. It never asks: "Is what the accused did 
  wrong/harmful/fraudulent?" It asks only: "Do the specific statutory 
  ingredients match the specific alleged facts?" This is pure textualism — 
  the spirit of the law is never invoked.

TENSION WITH OTHER DOCTRINES:
  (a) PURPOSIVE INTERPRETATION — which would ask WHY the forgery provisions 
      exist and whether this conduct falls within their purpose.
  (b) VICTIM-CENTRIC JURISPRUDENCE — which would ask whether leaving the 
      true owner without a criminal remedy is just when his property is 
      being fraudulently sold.
  (c) HARMONIOUS CONSTRUCTION — which would require S.464 to be read 
      harmoniously with S.463's "support any claim or title" language.
  (d) THE MISCHIEF RULE — which would ask what mischief the forgery 
      provisions were enacted to suppress and whether this conduct falls 
      within that mischief.
  (e) THE EXPANDING SCOPE OF FRAUD JURISPRUDENCE — Indian courts have 
      generally trended toward broader interpretation of fraud-related 
      provisions, making Md. Ibrahim's narrow reading somewhat counter-
      trend.
```

---

# ═══════════════════════════════════════════════════════
# DIMENSION 4: THE WEAPONIZABLE
# (How to USE this judgment and how to ATTACK it)
# ═══════════════════════════════════════════════════════

---

## 4.1 THE JUDGMENT AS A SWORD (Offensive Uses)

### USE CASE 1: Discharge Application for Forgery Charges in Property Disputes

```
Scenario:
  Your client has been charged under Ss. 467/471 IPC for executing a sale 
  deed, gift deed, lease deed, mortgage deed, or any conveyancing document 
  in his own name for property whose ownership is disputed. The complainant 
  is the alleged true owner.

How to cite:
  ¶12 — "There is a fundamental difference between a person executing a 
  sale deed claiming that the property conveyed is his property, and a 
  person executing a sale deed by impersonating the owner or falsely 
  claiming to be authorised or empowered by the owner."

The argument (ready-to-use draft):
  "My Lord, the Hon'ble Supreme Court in Md. Ibrahim & Ors vs. State of 
  Bihar, (2009) 8 SCC 751, has held at paragraph 12 that the execution of 
  a sale deed by a person in his own name, claiming property as his own, 
  does not constitute making a 'false document' within the meaning of 
  Section 464 IPC, as it involves neither impersonation nor claim of 
  authority from another person. Without a false document, there can be no 
  forgery, and Sections 467 and 471 are not attracted. In the present case, 
  the accused signed the impugned deed in his own name, as himself. He did 
  not impersonate the complainant or claim authorization from him. The 
  complaint averments, even if assumed to be entirely true, do not disclose 
  the ingredients of forgery. The charge under Sections 467/471 is liable 
  to be quashed."

Stage of proceedings:
  Most effective at: (1) DISCHARGE APPLICATION under S.227/239 CrPC
  Also effective at: (2) QUASHING PETITION under S.482 CrPC before the HC
  Can also be used at: (3) BAIL APPLICATION (to argue non-applicability of 
  non-bailable S.467), (4) CHARGE stage under S.228/240 CrPC
```

### USE CASE 2: Quashing Cheating Charges Filed by Non-Purchaser

```
Scenario:
  Your client has been charged under S.420 IPC in a property sale dispute. 
  The complainant is NOT the purchaser but a third party claiming to be the 
  true owner of the property sold.

How to cite:
  ¶14 — "It is not the case of the complainant that any of the accused 
  tried to deceive him either by making a false or misleading representation 
  or by any other action or omission..."

The argument (ready-to-use draft):
  "My Lord, the Hon'ble Supreme Court in Md. Ibrahim (supra) has 
  established at paragraph 14 that in a sale transaction, the person 
  who can allege cheating is the purchaser — the person actually deceived 
  and induced to part with consideration. A third party claiming to be 
  the true owner, upon whom no deception was practised and to whom no 
  inducement was offered, does not have locus to maintain a complaint under 
  Section 420. The complainant here is not the purchaser. No deception was 
  directed at him. The charge under S.420 is liable to be quashed."

Stage of proceedings:
  Discharge / Quashing / Charge.
```

### USE CASE 3: Collapsing Conspiracy Charges Against Accessories

```
Scenario:
  Your client is the witness, scribe, stamp vendor, or Sub-Registrar in 
  a property sale deed that is alleged to be forged. The principal accused 
  is the seller. Your client is charged with conspiracy (S.120B) or 
  abetment (S.109).

How to cite:
  ¶18-19 — Charges quashed for all accused (including witness, scribe, 
  and stamp vendor) once the substantive forgery charge fails.

The argument:
  "My Lord, if the substantive offence of forgery is not made out against 
  the principal accused (the seller) as per the ratio of Md. Ibrahim, 
  the charge of conspiracy or abetment against accessory parties must 
  also fall. There cannot be conspiracy to commit a non-existent offence."

Stage: Discharge / Quashing.
```

### USE CASE 4: Reducing Severity to Achieve Settlement

```
Scenario:
  Your client faces a full spectrum of charges: Ss. 323, 341, 420, 467, 
  471, 504 IPC. S.467 carries life imprisonment and makes the offence 
  non-bailable. You want to strip the serious charges and leave only 
  compoundable minor charges.

How to cite:
  The entire operative order — Ss. 420, 467, 471, 504 quashed; Ss. 323, 
  341 undisturbed.

The argument:
  After quashing Ss. 420, 467, 471, 504 using Md. Ibrahim, only Ss. 323 
  and 341 remain. S.323 is compoundable under S.320 CrPC. Once the serious 
  charges fall, the case becomes easily settleable through compromise. This 
  is the STRATEGIC value: Md. Ibrahim is a severity-reduction tool that 
  enables out-of-court settlement.

Stage: Discharge / Quashing → followed by compromise under S.320 CrPC.
```

### USE CASE 5: Bail Application

```
Scenario:
  Your client is in custody under S.467 IPC (non-bailable, up to life 
  imprisonment) in a property dispute case. Bail has been refused because 
  of the severity of the charges.

How to cite:
  ¶12 — argue that S.467 is prima facie not attracted on the complaint 
  averments per Md. Ibrahim.

The argument:
  "My Lord, the very foundation of the non-bailable charge — S.467 — 
  is not attracted on the complaint averments per Md. Ibrahim (supra). 
  The accused signed in his own name. There is no impersonation. The 
  condition precedent for S.467, i.e., forgery, does not exist. The 
  accused is effectively being held under a non-bailable charge that is 
  prima facie not made out. Bail should be granted."

Stage: BAIL APPLICATION before Sessions Court / High Court.
```

---

## 4.2 THE JUDGMENT AS A SHIELD (Defensive Uses)

### DEFENCE SCENARIO 1: All Conveyancing Documents, Not Just Sale Deeds

```
Attack being faced:
  Forgery charges for executing a GIFT DEED, LEASE DEED, MORTGAGE DEED, 
  PARTITION DEED, or RELEASE DEED for property where the executant's title 
  is disputed — but the executant signed in their own name.

How this judgment helps:
  The principle of Md. Ibrahim is not limited to sale deeds. It applies to 
  ALL documents where the maker executes in his own name. The key test is: 
  did the maker sign as himself, or did he impersonate someone else?

Key distinction to maintain:
  The executant MUST have signed IN THEIR OWN NAME and IN THEIR OWN 
  CAPACITY. If they signed as "Attorney of X" without actual authorization, 
  or as "Legal Heir of Y" with fabricated proof, this judgment does NOT 
  protect them — those are claims of authority from another person, falling 
  within S.464 Firstly.
```

### DEFENCE SCENARIO 2: Pre-arrest Bail Application

```
Attack being faced:
  Police seeking arrest under S.467 IPC (non-bailable) in a property 
  dispute. The accused apprehends arrest.

How this judgment helps:
  Use Md. Ibrahim in a pre-arrest bail (anticipatory bail) application 
  under S.438 CrPC to argue that S.467 is prima facie not attracted. 
  If the most serious charge is not made out, the justification for arrest 
  weakens significantly.

Key distinction:
  Works only when the FIR/complaint clearly shows the accused signed in 
  their own name. If the FIR alleges impersonation or forgery of supporting 
  documents, this shield is unavailable.
```

### DEFENCE SCENARIO 3: Against Supplementary Charge-Sheet

```
Attack being faced:
  After investigation, police file a supplementary charge-sheet adding 
  S.467/471 based on the execution of registered documents in a property 
  dispute.

How this judgment helps:
  Challenge the supplementary charge-sheet at the charge stage by arguing 
  that the additional investigation has not produced any material showing 
  impersonation or false authority — the sine qua non for S.464.

Key distinction:
  If the supplementary charge-sheet alleges ADDITIONAL fabricated documents 
  (fake mutation entries, forged revenue receipts, etc.) beyond the 
  conveyancing deed, Md. Ibrahim protects only the conveyancing deed, 
  not the fabricated supporting documents.
```

---

## 4.3 THE VULNERABILITY MAP (How to Attack This Judgment)

### VULNERABILITY 1: Purposive Interpretation Was Never Attempted

```
The Weak Point:
  The court's entire analysis is textual/literal. It never considers the 
  PURPOSE of the forgery provisions (Ss. 463-471) — which is to prevent 
  and punish document-based deception intended to cause injury. A sale deed 
  by a known non-owner is PRECISELY the kind of document-based deception 
  these provisions were designed to prevent.

Attack Vector:
  Argue before a larger bench that S.464 should be interpreted purposively. 
  The provision exists to prevent document-based fraud. A sale deed for 
  property the seller KNOWS he doesn't own is created with the intent to 
  deceive — the purchaser, the Sub-Registrar, and anyone who relies on the 
  registered document. This IS document-based fraud.

Likelihood of Success: MEDIUM
  The textualist reading is strong for penal statutes, but the purposive 
  argument has real force — especially in an era of escalating property 
  fraud and land-grabbing in India.

What Would Be Needed:
  A 3-judge bench willing to reconsider. Ideally, a case with egregious 
  facts (organized land mafia, systematic sale of others' properties) where 
  the narrow reading produces a manifestly unjust result.
```

### VULNERABILITY 2: S.463-S.464 Disharmony Unexplored

```
The Weak Point:
  Section 463 includes forgery with intent "to support any claim or title." 
  But the court's narrow reading of S.464 effectively excludes documents 
  made to support false claims of title from being "false documents" — 
  rendering S.463's "claim or title" language meaningless.

Attack Vector:
  Invoke the harmonious construction principle. Argue that S.464 must be 
  read to accommodate S.463's "support any claim or title" intent — 
  otherwise a portion of S.463 becomes surplusage, violating the principle 
  that every word of a statute must be given meaning.

Likelihood of Success: MEDIUM-HIGH
  This is the strongest structural argument against Md. Ibrahim. It doesn't 
  require overruling the judgment — it requires reading it alongside S.463 
  in a way the court never considered.

What Would Be Needed:
  A well-argued case where counsel specifically raises the S.463-S.464 
  harmonious reading before a bench of 2 or more judges.
```

### VULNERABILITY 3: Two-Judge Bench Status

```
The Weak Point:
  The judgment is by a 2-judge bench. It can be overruled or departed from 
  by ANY bench of 3 or more judges.

Attack Vector:
  Seek reference to a 3-judge bench arguing that the question of whether 
  S.464 covers false ownership claims in conveyancing documents requires 
  authoritative settlement — particularly given the epidemic of property 
  fraud in India.

Likelihood of Success: LOW
  The judgment has been widely followed for 15+ years without serious 
  challenge. Courts have found it convenient — it provides a clear, bright-
  line rule. Disturbing settled law requires strong motivation.

What Would Be Needed:
  A High Court creating a conflicting precedent, or a case reaching the 
  Supreme Court with facts so egregious that the court is compelled to 
  revisit.
```

### VULNERABILITY 4: BNS Replacement of IPC

```
The Weak Point:
  The Indian Penal Code has been replaced by the Bharatiya Nyaya Sanhita 
  (BNS), 2023, effective 01.07.2024. The corresponding BNS provisions may 
  have different or broader language.

Attack Vector:
  In a post-BNS case, argue that the Md. Ibrahim ratio was an 
  interpretation of IPC S.464, not BNS S.336. If the BNS language is 
  broader, the ratio does not apply to new offences.

Likelihood of Success: DEPENDS ON BNS LANGUAGE COMPARISON
  If BNS S.336 is verbatim identical to IPC S.464, this attack fails.
  If there is any broadening of language, this attack has strong potential.

What Would Be Needed:
  Word-by-word comparison of IPC S.464 and BNS S.336 (this analysis was 
  not possible from the judgment text alone).
```

### VULNERABILITY 5: The "Locus Gap" Creates Constitutional Tension

```
The Weak Point:
  The combined effect of Md. Ibrahim's holdings is that the true owner has 
  NO criminal remedy when his property is fraudulently sold:
  - Can't allege forgery (no false document per Md. Ibrahim)
  - Can't allege cheating (not the person deceived per Md. Ibrahim)
  - Only remedy is civil suit (which takes 15-20 years in Indian courts)
  
  This "locus gap" creates potential constitutional tension with Article 21 
  (right to livelihood — property as a facet of livelihood) and Article 14 
  (equality — why should a property fraud victim have NO criminal remedy 
  when victims of other frauds do?).

Attack Vector:
  A constitutional challenge arguing that the interpretive framework of 
  Md. Ibrahim, when combined with India's systemic civil court delays, 
  effectively denies the true owner any meaningful remedy — violating the 
  right to effective access to justice.

Likelihood of Success: LOW-MEDIUM
  This is a sophisticated constitutional argument. It doesn't attack the 
  judgment directly but argues that its CONSEQUENCES are constitutionally 
  inadequate.

What Would Be Needed:
  A PIL or a constitutional challenge by an affected true owner, ideally 
  with data on civil court delays and examples of property fraud victims 
  left without remedy.
```

```
═══════════════════════════════════════════════════════

OVERALL DURABILITY SCORE: 7/10

REASONING:
  Strengths (+): 
  • Clear, bright-line rule — easy to apply, hard to misinterpret
  • 15+ years of widespread acceptance and citation
  • Textually sound — the literal reading of S.464 does support the 
    conclusion
  • Consistent with the orthodox strict construction doctrine for penal 
    statutes
  
  Weaknesses (-):
  • 2-judge bench (technically overrulable by 3+ judges)
  • Never engaged with purposive interpretation or harmonious construction
  • Creates a "locus gap" that may become politically/constitutionally 
    untenable as property fraud escalates
  • BNS replacement creates statutory uncertainty for new cases
  • The S.463-S.464 disharmony argument has never been tested — and it 
    is genuinely strong

═══════════════════════════════════════════════════════
```

---

## 4.4 THE DISTINGUISHING PLAYBOOK

### DISTINGUISHING STRATEGY 1: Impersonation

```
Factual Difference:
  In your case, the accused did not just sign in his own name — he 
  IMPERSONATED the true owner at the Sub-Registrar's office, or used 
  a fabricated power of attorney, or forged the owner's signatures.

The Argument:
  "Md. Ibrahim is squarely distinguishable. In that case, the accused 
  signed the sale deed in his own name, claiming to be the owner. Here, 
  the accused impersonated the actual owner [OR used a fabricated power 
  of attorney from the actual owner] — falling directly within S.464 
  Firstly. The Hon'ble Supreme Court in Md. Ibrahim itself drew this 
  distinction at paragraph 12."
```

### DISTINGUISHING STRATEGY 2: Fabricated Supporting Documents

```
Factual Difference:
  In your case, the accused didn't just execute a sale deed — he also 
  fabricated mutation entries, forged inheritance certificates, created 
  fake revenue receipts, or produced fabricated court orders to build 
  a false chain of title.

The Argument:
  "Md. Ibrahim addressed only the sale deed executed by the accused in 
  his own name. Here, the accused created an entire ecosystem of fabricated 
  documents — each of which is independently a 'false document' under 
  S.464, as these fabricated revenue/mutation records purport to be issued 
  by government officials who never issued them."
```

### DISTINGUISHING STRATEGY 3: Complainant is the Purchaser

```
Factual Difference:
  In your case, the complainant IS the purchaser who was defrauded — 
  not a third-party owner.

The Argument:
  "The ratio of Md. Ibrahim on cheating was based on the finding that the 
  complainant was NOT the purchaser. Here, the complainant is the very 
  purchaser who was induced to part with consideration based on a false 
  representation of ownership. The court in Md. Ibrahim expressly preserved 
  this remedy at paragraph 15: 'the person defrauded, that is the 
  purchaser, may complain.' My client is that purchaser."
```

### DISTINGUISHING STRATEGY 4: Systematic/Organized Fraud

```
Factual Difference:
  In your case, the accused is part of an organized land fraud network — 
  systematically selling properties belonging to multiple owners, using 
  registered deeds as tools of dispossession.

The Argument:
  "Md. Ibrahim involved a bona fide family dispute between cousins with 
  competing claims of inheritance. The present case involves a systematic 
  land fraud operation with no colourable claim to any of the properties 
  sold. The mischief here is qualitatively different and engages additional 
  provisions — S.420 (cheating the purchasers), S.421 (fraudulent removal 
  of property), S.423 (fraudulent execution of deed), and S.120B (criminal 
  conspiracy) — none of which were analyzed in Md. Ibrahim."
```

### DISTINGUISHING STRATEGY 5: Post-BNS Case

```
Factual Difference:
  Your case arises after 01.07.2024 under the Bharatiya Nyaya Sanhita.

The Argument:
  "Md. Ibrahim interpreted Section 464 of the Indian Penal Code, 1860, 
  which has been repealed and replaced by Section 336 of the Bharatiya 
  Nyaya Sanhita, 2023. The interpretation of the repealed provision is not 
  automatically applicable to the new provision unless the language is 
  identical. The court must independently interpret S.336 BNS."
```

---

## 4.5 CROSS-DOMAIN TRANSPLANTATION MAP

### TRANSPLANT 1: Corporate Law — Director Selling Company Property

```
Original Domain        : Criminal (IPC) — Forgery in property disputes
Target Domain          : Corporate Law — Director transferring company assets
Analogous Principle    : If a company director executes a sale/transfer deed for 
                          company property IN HIS OWN NAME (not as director), is 
                          that forgery? Applying Md. Ibrahim: the director signed as 
                          himself, not impersonating the company. But a director 
                          selling company property in his personal name is not 
                          "claiming it as his own" in the same sense — he's 
                          misappropriating, not "owning."
Viability              : MEDIUM — The analogy is imperfect. A company director has 
                          a fiduciary relationship that changes the analysis. But the 
                          textual argument under S.464 would be similar.
```

### TRANSPLANT 2: IP Law — Claiming Authorship of Others' Work

```
Original Domain        : Criminal (IPC) — False ownership claim in sale deed
Target Domain          : Intellectual Property — Publishing another's work as your own
Analogous Principle    : If an author publishes a book under his own name but the 
                          content is plagiarized from another author, is the book 
                          a "false document"? Applying Md. Ibrahim's logic: the 
                          publisher signed in his own name (not impersonating the 
                          original author). But the document makes a false 
                          representation of authorship/ownership.
Viability              : LOW-MEDIUM — IP has its own statutory framework (Copyright 
                          Act), and the analogy between "property ownership" and 
                          "authorship" is imperfect.
```

### TRANSPLANT 3: Negotiable Instruments — Cheque for Disputed Debt

```
Original Domain        : Criminal — "False claim of ownership ≠ false document"
Target Domain          : Negotiable Instruments Act — S.138 cheque bounce defence
Analogous Principle    : If someone issues a cheque from their own account for a 
                          debt they dispute owing, the cheque is NOT a "false 
                          document" — it's signed by the actual account holder 
                          (no impersonation) for a genuinely disputed obligation. 
                          The dispute about whether the debt is owed is "civil" — 
                          just as the dispute about ownership in Md. Ibrahim was civil.
Viability              : HIGH — Directly applicable in S.138 NI Act cases where 
                          the defence is "disputed liability" or "no legally 
                          enforceable debt."
```

### TRANSPLANT 4: Revenue Law — False Declaration in Tax Returns

```
Original Domain        : Criminal — Person claiming ownership of property that isn't his
Target Domain          : Revenue Law — Person claiming deductions they're not entitled to
Analogous Principle    : Md. Ibrahim says: "A false claim of ownership is not a 
                          false document." Can this extend to: "A false claim of 
                          entitlement to a tax deduction is not a false document"? 
                          If a taxpayer files a return claiming deductions they 
                          KNOW they're not entitled to, is the return a "false 
                          document" under S.464?
Viability              : LOW — Tax returns involve declarations to the STATE 
                          (effectively a representation to a public authority), 
                          which brings in additional provisions (S.199 IPC — false 
                          statement in declaration). The Md. Ibrahim principle likely 
                          doesn't extend to formal declarations to public authorities.
```

### TRANSPLANT 5: Family Law — False Claim in Adoption/Guardianship Documents

```
Original Domain        : Criminal — Non-owner claiming ownership in sale deed
Target Domain          : Family Law — Person claiming parental rights in custody 
                          proceedings without biological or adoptive parentage
Analogous Principle    : If a person files a custody petition claiming to be the 
                          biological parent of a child when they're not — is the 
                          petition a "false document"? Under Md. Ibrahim: the person 
                          signed in their own name, making a false claim of parentage 
                          (analogous to false claim of ownership). But here the stakes 
                          (child's welfare) may push courts away from strict textualism.
Viability              : LOW — The child welfare dimension makes courts more 
                          interventionist. Md. Ibrahim's "civil remedy sufficient" 
                          logic is unlikely to be transplanted where a child's 
                          safety is at stake.
```

---

## 4.6 THE TEMPORAL VULNERABILITY ANALYSIS

```
CURRENT BENCH STRENGTH    : 2-Judge Bench (Justice R.V. Raveendran + Justice R.M. Lodha)

CAN IT BE OVERRULED BY    : Any bench of 2 or more judges of the Supreme Court 
                            (though convention suggests 3+ judges for departing from 
                            a settled 2-judge bench ratio). Any Constitution Bench 
                            (5 judges) would authoritatively settle the matter.

LEGISLATIVE OVERRIDE RISK : HIGH
  The BNS (2023) replaces IPC. If BNS S.336 uses broader language than IPC 
  S.464 — even slightly broader — this interpretation may not apply to new 
  cases. Parliament could also specifically amend the definition of "false 
  document" to include documents with false ownership claims.
  
  Additionally, some state legislatures have enacted property-specific fraud 
  provisions that may independently criminalize the conduct Md. Ibrahim 
  de-criminalized under the IPC.

SOCIETAL SHIFT RISK       : MEDIUM-HIGH
  India faces an escalating crisis of land fraud, encroachment, and land-
  grabbing — particularly affecting rural landowners, women, tribals, and 
  absentee owners. The political pressure to criminalize property fraud is 
  increasing. Courts may face mounting pressure to adopt broader 
  interpretations.

CONFLICTING TRENDS        : 
  (a) Some High Courts have taken broader views of forgery in property 
      fraud contexts (though specific citations require external research).
  (b) The general trend in Indian criminal jurisprudence is toward BROADER 
      interpretation of fraud-related provisions — making Md. Ibrahim's 
      narrow reading somewhat counter-trend.
  (c) However, the counter-trend of protecting against misuse of criminal 
      process (G. Sagar Suri doctrine) remains strong and supports the 
      Md. Ibrahim approach.

SURVIVAL PROBABILITY:
  For IPC-era cases (pre-01.07.2024)       : HIGH (10+ years)
  For BNS-era cases (post-01.07.2024)      : UNCERTAIN (depends on BNS language)
  For the underlying PRINCIPLE              : MEDIUM-HIGH (the bright-line 
                                              distinction between "false claim" 
                                              and "false document" is intuitively 
                                              sound and likely to survive in 
                                              some form, even if refined)
```

---

# ═══════════════════════════════════════════════════════
# DIMENSION 5: THE SYNTHESIS
# (Pulling everything together)
# ═══════════════════════════════════════════════════════

---

## 5.1 THE INTERPRETIVE LINEAGE MAP

### PROVISION: Section 464 IPC — "Making a False Document"

| Year | Case | Interpretive Layer Added | Method Used | Status Post Md. Ibrahim | Durability |
|------|------|------------------------|-------------|------------------------|-----------|
| 1860 | IPC Enacted by Legislature | Three categories of "false document" defined: (1) impersonation/false authority, (2) unauthorized alteration, (3) deception of incapacitated person | Legislative intent | FOUNDATIONAL — still the operative text | Permanent (within IPC era) |
| 1963 | Dr. Vimla vs. Delhi Administration, AIR 1963 SC 1572 | Defined "defraud" as requiring deceit + injury (including non-pecuniary). Expanded concept of "injury" beyond economic loss. | Literal + Expansive | GOOD LAW — RELIED UPON in ¶15 | HIGH |
| 1999 | State of UP vs. Ranjit Singh, (1999) 2 SCC 617 | Reaffirmed Dr. Vimla definition without modification | Reaffirmation | GOOD LAW — REAFFIRMED in ¶15 | HIGH |
| 2000 | G. Sagar Suri vs. State of UP, (2000) 2 SCC 636 | Gatekeeping principle: courts must filter out criminal complaints that are disguised civil disputes | Purposive / Policy | GOOD LAW — RELIED UPON as framing principle in ¶7 | HIGH |
| 2006 | IOC vs. NEPC India Ltd., (2006) 6 SCC 736 | Balancing principle: civil nature of dispute does not immunize genuine criminal ingredients | Purposive / Policy | GOOD LAW — RELIED UPON as balancing principle in ¶7 | HIGH |
| **2009** | **Md. Ibrahim & Ors vs. State of Bihar & Anr, (2009) 8 SCC 751 [CURRENT JUDGMENT]** | **BRIGHT-LINE DISTINCTION: False ownership claim ≠ false document. A document executed by a person in his own name claiming property as his own is NOT a false document under S.464, even if the property doesn't belong to him. Impersonation or false authority is REQUIRED. Third-party owner cannot allege cheating (S.420) in a sale transaction — only the purchaser can. Fraud per se is not an offence — only enumerated fraudulent acts are.** | **Strict Literal / Textual** | **CURRENT POSITION** | **7/10** |

### PROVISION: Sections 415-420 IPC — Cheating

| Year | Case | Layer Added | Status | Durability |
|------|------|------------|--------|-----------|
| **2009** | **Md. Ibrahim (CURRENT)** | **Locus to allege cheating in a sale transaction lies with the purchaser (person deceived), not a third-party claiming true ownership** | **CURRENT POSITION** | **7/10** |

### PROVISION: Section 25 IPC — "Fraudulently"

| Year | Case | Layer Added | Status | Durability |
|------|------|------------|--------|-----------|
| **2009** | **Md. Ibrahim (CURRENT — OBITER)** | **Acting "fraudulently" is not per se an offence. Only 13 specific categories of fraudulent acts enumerated in the IPC constitute offences. Catalogue provided at ¶16.** | **PERSUASIVE (Obiter)** | **HIGH** |

---

## 5.2 THE ONE-PARAGRAPH GENOME SUMMARY

This judgment draws a deceptively simple but profoundly consequential bright line within the Indian Penal Code's forgery architecture: when a person executes a sale deed in his own name claiming property as his own, he does not create a "false document" under Section 464 IPC — because the statute requires the maker to either impersonate another person or falsely claim authority from another person, and a false claim of ownership is neither impersonation nor false authority. The judgment's entire edifice rests on an unstated assumption that "identity" in Section 464 means personal identity (who signed the document), not legal capacity (whether the signer was entitled to execute it) — an assumption that was never tested against a purposive reading, a harmonious reading with Section 463's "support any claim or title" language, or a mischief rule analysis, any of which could yield a different result. The judgment simultaneously creates a "locus gap" in cheating law: the true owner cannot allege cheating (because no deception was practised upon him) and the purchaser cannot allege cheating if made a co-accused (because the prosecution's framing foreclosed it) — leaving the true owner's only remedy in civil courts that take decades to deliver. The court's own clarification at ¶15 ("we should not be understood as holding that such an act can never be a criminal offence") and its catalogue of thirteen enumerated fraudulent acts at ¶16 are deliberate breadcrumbs pointing toward uncharged provisions (particularly Section 423 IPC) and the unexplored theory of the Sub-Registrar as a victim of cheating. As a 2-judge bench decision interpreting a repealed statute (IPC, now replaced by BNS), its long-term survival depends on whether the BNS adopts identical language and whether the escalating crisis of property fraud in India creates judicial appetite for broader interpretations — but within its domain, its bright-line clarity has made it one of the most cited property-crime judgments in Indian criminal law.

---

## 5.3 THE PRACTITIONER'S CHEAT SHEET

```
════════════════════════════════════════════════════
CITE THIS JUDGMENT WHEN:
════════════════════════════════════════════════════

1. Client executed ANY conveyancing document (sale deed, gift deed, lease, 
   mortgage, partition deed) in OWN NAME for property whose ownership is 
   disputed → QUASH forgery charges (Ss. 467/471).

2. Criminal complaint of cheating (S.420) filed by someone OTHER THAN the 
   purchaser in a property sale dispute → QUASH cheating charges.

3. Client is a witness/scribe/stamp vendor in such a deed → if principal 
   offence (forgery) fails, accessory/conspiracy charges also fail.

4. Client facing non-bailable arrest under S.467 in a property dispute → 
   argue prima facie non-applicability at BAIL stage.

5. Vague allegations of "fraud" without specifying which IPC provision → 
   use ¶16 catalogue to show no specific offence is made out.

════════════════════════════════════════════════════
DO NOT CITE THIS JUDGMENT WHEN:
════════════════════════════════════════════════════

1. The accused IMPERSONATED the actual owner or forged the owner's 
   signature → S.464 Firstly directly attracted.

2. The complainant IS the purchaser alleging deception → the court 
   expressly preserves this remedy at ¶14-15.

3. The accused fabricated SUPPORTING documents (fake mutation entries, 
   forged inheritance certificates, fabricated revenue receipts) in 
   addition to the sale deed → those fabricated documents ARE false 
   documents that Md. Ibrahim doesn't protect.

4. Post-01.07.2024 BNS cases → FIRST compare IPC S.464 with BNS S.336 
   word-for-word before citing.

5. Cases where S.423 IPC (fraudulent execution of deed with false 
   statement of consideration) is charged → Md. Ibrahim addressed only 
   Ss. 467/471/420, NOT S.423.

════════════════════════════════════════════════════
THE KILLER PARAGRAPH: ¶12
════════════════════════════════════════════════════

"There is a fundamental difference between a person executing a sale deed 
claiming that the property conveyed is his property, and a person executing 
a sale deed by impersonating the owner or falsely claiming to be authorised 
or empowered by the owner, to execute the deed on owner's behalf. When a 
person executes a document conveying a property describing it as his, there 
are two possibilities. The first is that he bonafide believes that the 
property actually belongs to him. The second is that he may be dishonestly 
or fraudulently claiming it to be his even though he knows that it is not 
his property. But to fall under first category of 'false documents', it is 
not sufficient that a document has been made or executed dishonestly or 
fraudulently."

→ This is the paragraph that will be quoted in every future discharge 
  application and quashing petition in property-forgery cases.

════════════════════════════════════════════════════
THE HIDDEN GEM: ¶16
════════════════════════════════════════════════════

The catalogue of THIRTEEN specific fraudulent acts made punishable under 
the IPC. Most practitioners will never read this paragraph carefully. But 
it contains:

(a) A complete taxonomy of criminal fraud under the IPC — invaluable for 
    both prosecution and defence in any fraud case.

(b) An implicit suggestion that S.423 (fraudulent execution of deed with 
    false statement of consideration) COULD have been charged but wasn't — 
    a breadcrumb for future prosecutors.

(c) The foundational principle that "fraud ≠ offence" — acting fraudulently 
    is not per se criminal. Only the enumerated acts are. This principle 
    has applications far beyond property disputes — it applies to corporate 
    fraud, financial fraud, and any case where vague "fraud" allegations 
    are thrown around without specifying the operative IPC provision.
```

---

## 5.4 QUESTIONS THIS JUDGMENT CREATES

### NEW QUESTION 1:

```
The Question:
  If a non-owner sells property to a GENUINE (non-colluding) purchaser, 
  and the purchaser later discovers the fraud, can the purchaser file a 
  complaint under S.420 even if the true owner's complaint has already 
  been quashed under Md. Ibrahim?

Why It Didn't Exist Before This Judgment:
  Before Md. Ibrahim, both true owners and purchasers filed combined 
  complaints. This judgment SPLITS their remedies — creating the question 
  of sequential complaints.

Who Will Raise It First:
  A cheated purchaser whose initial complaint was clubbed with the true 
  owner's complaint and quashed together.

Likely Forum:
  Criminal Revision or s.482 CrPC petition before High Court.
```

### NEW QUESTION 2:

```
The Question:
  Can the Sub-Registrar (or the State on his behalf) file a complaint of 
  cheating against a person who presented a sale deed for registration 
  while falsely representing himself as the owner?

Why It Didn't Exist Before This Judgment:
  Nobody had previously identified the Sub-Registrar as an independent 
  victim of deception. This question emerges directly from Md. Ibrahim's 
  locus analysis — if the true owner can't complain and the purchaser is 
  a co-accused, who CAN complain? The Sub-Registrar is the unexplored 
  answer.

Who Will Raise It First:
  An aggressive prosecution or a State government seeking to combat 
  organized property fraud.

Likely Forum:
  Magistrate's Court, escalating to High Court for the jurisdictional 
  question.
```

### NEW QUESTION 3:

```
The Question:
  Does the Bharatiya Nyaya Sanhita's definition of "false document" 
  (S.336 BNS) differ from IPC S.464 in any way that makes the 
  Md. Ibrahim ratio inapplicable to post-01.07.2024 offences?

Why It Didn't Exist Before This Judgment:
  The BNS didn't exist in 2009. This question arises because the ratio 
  interprets a specific statutory text — if that text changes, the ratio 
  may not transfer.

Who Will Raise It First:
  Any prosecution opposing a quashing petition in a post-BNS property 
  fraud case.

Likely Forum:
  High Courts across India, eventually the Supreme Court.
```

### NEW QUESTION 4:

```
The Question:
  Is the "locus gap" created by Md. Ibrahim — where the true owner has 
  NO criminal remedy for fraudulent sale of his property — constitutionally 
  adequate? Does the absence of a criminal remedy, combined with decades-
  long civil court delays, violate Article 21 (right to property as a 
  facet of livelihood/dignity)?

Why It Didn't Exist Before This Judgment:
  Before Md. Ibrahim, the true owner could at least attempt criminal 
  remedies (however weak). After Md. Ibrahim, those avenues are formally 
  closed. This creates a gap that didn't previously exist in this explicit 
  form.

Who Will Raise It First:
  A PIL litigant, legal aid organization, or an affected true owner with 
  access to constitutional counsel.

Likely Forum:
  High Court (PIL) → Supreme Court.
```

### NEW QUESTION 5:

```
The Question:
  Should Section 463's phrase "to support any claim or title" be read 
  harmoniously with Section 464's definition of "false document" — such 
  that a document made to support a false claim of title qualifies as 
  a "false document" even without impersonation?

Why It Didn't Exist Before This Judgment:
  Before Md. Ibrahim's narrow reading of S.464, the S.463-S.464 
  relationship had not been tested. Md. Ibrahim's interpretation creates 
  a textual tension between the two sections that invites harmonious 
  construction.

Who Will Raise It First:
  An appellate counsel arguing against Md. Ibrahim before a larger bench.

Likely Forum:
  Supreme Court (3-judge bench or larger).
```

---

## 5.5 EXTRACTION CONFIDENCE & METADATA

```
OVERALL CONFIDENCE     : HIGH

SECTIONS WITH HIGHEST 
UNCERTAINTY            : 
  • 3.1 (Hidden Assumptions) — These involve analytical inference beyond 
    the judgment text. The assumptions identified are logically sound but 
    require validation through external legal scholarship.
  • 3.2 (Silent Arguments) — These are the extractor's analytical 
    contributions, not findings from the judgment. Their quality depends 
    on the depth of the extractor's legal knowledge.
  • 3.5 (Alternative Interpretations) — The viability assessments are 
    judgment calls, not certainties.
  • 4.6 (Temporal Vulnerability) — The BNS analysis could not be completed 
    from the judgment text alone. Requires separate statutory comparison.
  • 4.5 (Cross-Domain Transplants) — Viability assessments are speculative 
    and depend on how future courts receive analogical reasoning.

JUDGMENT CLARITY GRADE : A
  Exceptionally well-written judgment. Clear logical structure, explicit 
  reasoning, sequential analysis of each offence, minimal ambiguity. 
  Justice Raveendran writes with the clarity of a law professor. The 
  judgment is structured as a teachable text — it can be used in a 
  classroom to demonstrate eliminative legal reasoning.

EXTRACTION LIMITATIONS :
  (1) The BNS S.336 comparison could not be performed from the judgment 
      text alone — requires access to the Bharatiya Nyaya Sanhita, 2023.
  (2) Post-2009 judicial treatment (whether followed, distinguished, 
      doubted, or overruled) requires external research through legal 
      databases (SCC Online, Manupatra, Indian Kanoon).
  (3) The "silent arguments" are analytical contributions of the 
      extractor and have not been judicially tested.
  (4) The counter-factual outcomes are probabilistic assessments, not 
      certainties — actual outcomes depend on bench composition, 
      judicial temperament, and quality of advocacy.
  (5) The cross-domain transplantation viability depends on jurisdictional 
      and contextual factors beyond what this single judgment can predict.
```

---

# ═══════════════════════════════════════════════════════
# END OF GENOME EXTRACTION
# ═══════════════════════════════════════════════════════

```
Extracted using     : Judgment Genome Project™ Framework v2.0
Judgment            : Md. Ibrahim & Ors vs State of Bihar & Anr
Citation            : (2009) 8 SCC 751
Court               : Supreme Court of India
Date                : 04 September 2009
Source              : Indian Kanoon (http://indiankanoon.org/doc/409057/)
Extraction Date     : 28 February 2026
```

---
*Judgment Genome Project™ — Extracting the DNA of Legal Reasoning*
