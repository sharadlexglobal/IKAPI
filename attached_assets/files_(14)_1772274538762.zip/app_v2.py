"""
Judgment Genome Project™ v3.0 — Flask Application

Production-grade backend with:
  - Singleton Anthropic client
  - Proper error handling with custom exceptions
  - Request validation & size limits
  - Structured logging with request IDs
  - Health check endpoint
  - Response caching headers
"""
from __future__ import annotations

import json
import logging
import re
import time
import uuid
from datetime import date, datetime
from typing import Any

from flask import Flask, Response, g, jsonify, render_template, request

from config import (
    APIConfig,
    build_master_prompt,
    get_schema_summary,
    load_schema,
    strip_markdown_fences,
)

# ── Logging ────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s — %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger("genome")

# ── App ────────────────────────────────────────────────────
app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = APIConfig.MAX_REQUEST_MB * 1024 * 1024

# ── Anthropic Client (singleton, lazy-init) ────────────────
_anthropic_client = None

def _get_client():
    """Return a cached Anthropic client. Created once, reused."""
    global _anthropic_client
    if _anthropic_client is None:
        try:
            import anthropic
            _anthropic_client = anthropic.Anthropic(api_key=APIConfig.api_key())
            logger.info("Anthropic client initialized (model=%s)", APIConfig.model())
        except ImportError:
            raise RuntimeError(
                "anthropic package not installed. Run: pip install anthropic"
            )
        except Exception as exc:
            raise RuntimeError(f"Failed to init Anthropic client: {exc}") from exc
    return _anthropic_client


# ── Custom Errors ──────────────────────────────────────────
class ExtractionError(Exception):
    """Raised when the extraction pipeline fails."""
    def __init__(self, message: str, status_code: int = 500, detail: str = ""):
        super().__init__(message)
        self.message = message
        self.status_code = status_code
        self.detail = detail


@app.errorhandler(ExtractionError)
def handle_extraction_error(exc: ExtractionError):
    resp = {"error": exc.message}
    if exc.detail:
        resp["detail"] = exc.detail
    return jsonify(resp), exc.status_code


@app.errorhandler(413)
def handle_too_large(_):
    return jsonify({"error": f"Request body exceeds {APIConfig.MAX_REQUEST_MB}MB limit"}), 413


@app.errorhandler(Exception)
def handle_generic_error(exc: Exception):
    logger.exception("Unhandled error: %s", exc)
    return jsonify({"error": "Internal server error"}), 500


# ── Request Lifecycle ──────────────────────────────────────
@app.before_request
def before_request():
    g.request_id = str(uuid.uuid4())[:8]
    g.start_time = time.time()


@app.after_request
def after_request(response: Response) -> Response:
    duration = time.time() - getattr(g, "start_time", time.time())
    rid = getattr(g, "request_id", "?")
    logger.info(
        "[%s] %s %s → %s (%.2fs)",
        rid, request.method, request.path, response.status_code, duration,
    )
    response.headers["X-Request-ID"] = rid
    return response


# ── Routes ─────────────────────────────────────────────────

@app.route("/")
def index():
    """Serve the frontend."""
    return render_template("index.html")


@app.route("/health")
def health():
    """Health check for infrastructure monitoring."""
    return jsonify({
        "status": "ok",
        "api_configured": APIConfig.is_configured(),
        "schema_loaded": bool(load_schema()),
        "timestamp": datetime.utcnow().isoformat() + "Z",
    })


@app.route("/api/schema", methods=["GET"])
def get_schema():
    """Return the full JSON schema with cache headers."""
    schema = load_schema()
    resp = jsonify(schema)
    resp.headers["Cache-Control"] = "public, max-age=86400"
    return resp


@app.route("/api/extract", methods=["POST"])
def extract():
    """
    Extract structured judgment genome from raw judgment text.

    Request:  { "judgment_text": str, "citation": str (optional), "source_url": str (optional) }
    Response: Full genome JSON conforming to schema v3.1
    """
    # ── Parse & Validate ───────────────────────────────────
    content_type = request.content_type or ""
    if "json" not in content_type and "text" not in content_type:
        # Accept both application/json and text/plain
        try:
            data = request.get_json(force=True)
        except Exception:
            raise ExtractionError("Request body must be valid JSON", 400)
    else:
        data = request.get_json(silent=True)
        if data is None:
            raise ExtractionError("Request body must be valid JSON", 400)

    if not isinstance(data, dict):
        raise ExtractionError("Request body must be a JSON object", 400)

    judgment_text = (data.get("judgment_text") or "").strip()
    citation = (data.get("citation") or "").strip() or "Unknown Citation"
    source_url = (data.get("source_url") or "").strip() or None

    if not judgment_text:
        raise ExtractionError("No judgment text provided", 400)

    if len(judgment_text) < APIConfig.MIN_JUDGMENT_LENGTH:
        raise ExtractionError(
            f"Judgment text too short ({len(judgment_text)} chars). "
            f"Minimum {APIConfig.MIN_JUDGMENT_LENGTH} characters required.",
            400,
        )

    if len(judgment_text) > APIConfig.MAX_JUDGMENT_LENGTH:
        raise ExtractionError(
            f"Judgment text too long ({len(judgment_text):,} chars). "
            f"Maximum {APIConfig.MAX_JUDGMENT_LENGTH:,} characters.",
            400,
        )

    # ── Check API Readiness ────────────────────────────────
    if not APIConfig.is_configured():
        raise ExtractionError(
            "API not configured. Set ANTHROPIC_API_KEY environment variable.",
            503,
        )

    # ── Build Prompt ───────────────────────────────────────
    system_prompt = build_master_prompt()
    schema_description = get_schema_summary()

    user_message = (
        "Extract the complete Judgment Genome from the following judgment text.\n\n"
        "Output ONLY valid JSON conforming exactly to the schema below. "
        "No markdown fences, no explanation — ONLY the JSON object.\n\n"
        f"## SCHEMA:\n{schema_description}\n\n"
        f"## JUDGMENT TEXT:\n{judgment_text}"
    )

    rid = getattr(g, "request_id", "?")
    logger.info("[%s] Extraction starting — %d chars, citation=%s", rid, len(judgment_text), citation)

    # ── Call Anthropic API ─────────────────────────────────
    raw_text = ""
    try:
        client = _get_client()

        response = client.messages.create(
            model=APIConfig.model(),
            max_tokens=APIConfig.max_tokens(),
            system=system_prompt,
            messages=[{"role": "user", "content": user_message}],
            timeout=APIConfig.timeout(),
        )

        # Extract text from response
        if not response.content:
            raise ExtractionError("Empty response from AI model", 502)

        raw_text = response.content[0].text.strip()
        logger.info("[%s] API response received — %d chars, stop=%s",
                     rid, len(raw_text), response.stop_reason)

    except ExtractionError:
        raise
    except RuntimeError as exc:
        # From _get_client() when anthropic not installed
        raise ExtractionError(str(exc), 503)
    except Exception as exc:
        exc_name = type(exc).__name__
        # Check for known Anthropic exception types by name
        # (avoids import dependency in except clause)
        if "TimeoutError" in exc_name or "Timeout" in exc_name:
            raise ExtractionError(
                "AI model timed out. Complex judgments may need longer processing. Try again.",
                504,
            )
        elif "RateLimitError" in exc_name or "RateLimit" in exc_name:
            raise ExtractionError("Rate limit exceeded. Please wait and try again.", 429)
        elif "APIError" in exc_name:
            raise ExtractionError(f"AI API error: {exc}", 502, detail=str(exc))
        else:
            logger.exception("[%s] Unexpected API error", rid)
            raise ExtractionError(f"Unexpected error: {exc_name} — {exc}", 500)

    # ── Parse Response JSON ────────────────────────────────
    cleaned = strip_markdown_fences(raw_text)

    try:
        genome: dict[str, Any] = json.loads(cleaned)
    except json.JSONDecodeError as exc:
        logger.error("[%s] JSON parse failed: %s | First 500 chars: %s",
                      rid, exc, cleaned[:500])
        raise ExtractionError(
            "AI response was not valid JSON. This can happen with very complex judgments. Try again.",
            422,
            detail=f"Parse error at position {exc.pos}: {exc.msg}",
        )

    if not isinstance(genome, dict):
        raise ExtractionError("AI response was not a JSON object", 422)

    # ── Ensure Required Metadata ───────────────────────────
    genome.setdefault("document_id", str(uuid.uuid4()))
    genome.setdefault("schema_version", "3.1.0")
    meta = genome.setdefault("extraction_metadata", {})
    meta["extraction_date"] = date.today().isoformat()
    meta["judgment_citation"] = citation
    meta["source_url"] = source_url
    meta["framework_version"] = "Judgment Genome Project v3.0"
    meta["extractor"] = APIConfig.model()

    logger.info("[%s] Extraction complete — document_id=%s", rid, genome["document_id"])

    return jsonify(genome)


# ── Main ───────────────────────────────────────────────────
if __name__ == "__main__":
    banner = """
╔══════════════════════════════════════════════════════════╗
║          JUDGMENT GENOME PROJECT™ v3.0                   ║
║          Sub-Atomic Legal Extraction Engine               ║
╠══════════════════════════════════════════════════════════╣
║  API Key:  {api:<44s} ║
║  Model:    {model:<44s} ║
║  Timeout:  {timeout:<44s} ║
║  Server:   http://127.0.0.1:5000                         ║
╚══════════════════════════════════════════════════════════╝
""".format(
        api="✓ Configured" if APIConfig.is_configured() else "✗ NOT SET",
        model=APIConfig.model(),
        timeout=f"{APIConfig.timeout()}s",
    )
    print(banner)
    app.run(debug=True, host="0.0.0.0", port=5000)
