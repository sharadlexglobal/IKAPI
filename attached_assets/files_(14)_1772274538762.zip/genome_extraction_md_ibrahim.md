# JUDGMENT GENOME EXTRACTION
# Md. Ibrahim & Ors vs State of Bihar & Anr (2009)

---

# ═══════════════════════════════════════════════════════
# DIMENSION 1: THE VISIBLE
# ═══════════════════════════════════════════════════════

---

## 1.1 CASE IDENTITY CARD

```
Case Name              : Md. Ibrahim & Ors vs State of Bihar & Anr
Court                  : Supreme Court of India
Bench                  : 2-Judge Bench — Justice R.V. Raveendran & Justice R.M. Lodha
                         (NOT a Constitution Bench)
Date                   : 04-09-2009
Case Number            : Criminal Appeal No. 1695 of 2009
                         [Arising out of SLP (Crl.) No. 6211 of 2007]
Domain                 : Criminal — Interpretation of Forgery/Cheating provisions
                         in context of property disputes
Judgment Author        : Justice R.V. Raveendran
Concurring Judges      : Justice R.M. Lodha
Dissenting Judges      : None
Case Origin            : SLP against High Court order dismissing s.482 CrPC petition
```

---

## 1.2 THE STORY

**THE STORY IN PLAIN LANGUAGE:**

Two cousins in Madhubani, Bihar — Ibrahim and the complainant — both claimed the same piece of family land. Their grandfathers were brothers who owned the land jointly. Ibrahim believed the land had come to his mother through a family arrangement, and after his parents' deaths, he inherited it. He sold a portion to another person, executing proper registered sale deeds before a Sub-Registrar, with a witness, a scribe, and a stamp vendor present. The complainant said the land was entirely his and that Ibrahim had no right to sell it. Instead of filing a civil suit to settle the ownership dispute, the complainant went to the police and filed a criminal complaint saying Ibrahim had committed forgery and cheating by creating "fake" sale deeds. The police investigated and filed charges. When Ibrahim tried to get the charges dropped, both the Magistrate and the High Court refused. Ibrahim then went to the Supreme Court, which asked a simple but profound question: If a man sells land claiming it is his own — even if it actually isn't — has he committed forgery? The Supreme Court said no. Forgery means pretending to be someone else or forging someone else's signature. Ibrahim signed his own name, as himself. He may have been wrong about ownership, but being wrong about ownership is a civil matter, not a criminal one.

**THE STORY IN LEGAL LANGUAGE:**

The appellants were charged under Sections 323, 341, 420, 467, 471, and 504 IPC based on a complaint that the first appellant executed two registered sale deeds dated 02.06.2003 in favour of the second appellant, purporting to convey land allegedly belonging to the complainant. The first appellant claimed title through inheritance via family arrangement. The Sub-Divisional Magistrate rejected the discharge application; the Patna High Court dismissed the s.482 CrPC petition. The Supreme Court, exercising appellate jurisdiction, examined whether the complaint averments, even if assumed true, disclosed the ingredients of the charged offences. The Court held that execution of a sale deed by a person in his own name claiming property as his own — even if the property does not belong to him — does not constitute making a "false document" under Section 464 IPC, and therefore does not amount to forgery under Sections 463/467/471 IPC. Charges under Sections 420, 467, 471, and 504 were quashed; Sections 323 and 341 left undisturbed.

---

## 1.3 PROCEDURAL JOURNEY

| Stage | Forum | Date | Outcome | What Was Decided |
|-------|-------|------|---------|-----------------|
| Complaint filed | CJM, Madhubani | 19.07.2003 | Cognizance taken; referred for investigation u/s 156(3) CrPC | Offences under Ss. 323, 341, 420, 467, 471, 504 IPC prima facie disclosed |
| FIR registered | Pandaul Police Station | 10.10.2003 | Investigation commenced | — |
| Charge-sheet filed | SDM, Madhubani | 04.09.2004 | — | Charges against all accused |
| Discharge application | SDM, Madhubani | 14.12.2005 | Rejected | Sufficient material for framing charges |
| Charges framed | SDM, Madhubani | During pendency of 482 petition | Charges framed | — |
| s.482 CrPC petition | Patna High Court | [Date not specified] | Dismissed | Magistrate's finding of complicity upheld |
| SLP → Criminal Appeal | Supreme Court of India | 04.09.2009 | **Allowed in part** | Ss. 420, 467, 471, 504 quashed; Ss. 323, 341 undisturbed |

---

## 1.4 LEGAL PROVISIONS ENGAGED

**Provision 1:**
```
Provision              : Section 464 IPC — Making a False Document
Exact Text             : [Extracted in full at ¶9 of the judgment — three categories
                          of false documents defined in Firstly/Secondly/Thirdly]
Role                   : PRIMARY INTERPRETATION TARGET — The definitional nucleus.
                          The entire judgment pivots on whether the sale deeds meet
                          the definition of "false document" in this section.
What the Court Did     : INTERPRETED — Held that selling property as one's own
                          (even without title) does NOT fall under any of the
                          three categories of "false document."
```

**Provision 2:**
```
Provision              : Section 463 IPC — Forgery
Exact Text             : "Whoever makes any false documents with intent to cause
                          damage or injury... commits forgery"
Role                   : SUPPORTING DEFINITION — Forgery requires a "false document";
                          since no false document exists, forgery cannot exist.
What the Court Did     : INTERPRETED — Held not attracted on the facts.
```

**Provision 3:**
```
Provision              : Section 467 IPC — Forgery of Valuable Security
Role                   : CHARGED PROVISION — Life imprisonment / up to 10 years.
What the Court Did     : QUASHED — No forgery → Section 467 not attracted.
```

**Provision 4:**
```
Provision              : Section 471 IPC — Using Forged Document as Genuine
Role                   : CHARGED PROVISION — Dependent on forgery.
What the Court Did     : QUASHED — No forged document → Section 471 not attracted.
```

**Provision 5:**
```
Provision              : Sections 415 & 420 IPC — Cheating
Role                   : CHARGED PROVISION — Court examines locus of complainant.
What the Court Did     : INTERPRETED & QUASHED — Third-party (non-purchaser)
                          cannot allege cheating in a sale transaction.
```

**Provision 6:**
```
Provision              : Section 504 IPC — Intentional Insult
Role                   : CHARGED PROVISION.
What the Court Did     : QUASHED — Statement asserting legal position ≠ insult
                          with intent to provoke breach of peace.
```

**Provisions 7 & 8:**
```
Provision              : Sections 323 & 341 IPC — Hurt & Wrongful Restraint
Role                   : CHARGED PROVISIONS — Only provisions whose ingredients
                          were technically made out on the complaint averments.
What the Court Did     : LEFT UNDISTURBED.
```

**Provision 9:**
```
Provision              : Section 482 CrPC — Inherent Powers of High Court
Role                   : PROCEDURAL VEHICLE — Basis for the High Court petition.
What the Court Did     : High Court order under this section was set aside.
```

---

## 1.5 PRECEDENT REGISTRY

| # | Case Cited | What It Held | Why Cited Here | Treatment | ¶ |
|---|-----------|-------------|---------------|-----------|---|
| 1 | G. Sagar Suri v. State of U.P. [2000 (2) SCC 636] | Courts must guard against complainants giving criminal colour to essentially civil disputes to harass or pressure opponents | To establish the gatekeeping principle — courts must filter out disguised civil disputes | **FOLLOWED** | ¶7 |
| 2 | Indian Oil Corporation vs. NEPC India Ltd. [2006 (6) SCC 736] | Civil disputes may contain genuine criminal ingredients and must be tried as criminal cases if they do | To balance the G. Sagar Suri principle — not all civil disputes are immune from criminal prosecution | **FOLLOWED** | ¶7 |
| 3 | Dr. Vimla vs. Delhi Administration [AIR 1963 SC 1572] | "Defraud" requires two elements: deceit AND injury (including non-pecuniary harm) to the person deceived | To define the contours of "fraud" while explaining that the purchaser (not third party) is the person defrauded | **FOLLOWED** | ¶15 |
| 4 | State of UP vs. Ranjit Singh [1999 (2) SCC 617] | Reiterated the Dr. Vimla definition of "defraud" | To confirm the definition is settled law | **REAFFIRMED** | ¶15 |

---

## 1.6 RATIO DECIDENDI

**RATIO 1 (PRIMARY — On Forgery):**
When a person executes a document (such as a sale deed) in his own name, claiming a property as his own, even if the property does not in fact belong to him, he does not make a "false document" within the meaning of Section 464 IPC — because he is neither claiming to be another person nor claiming to act under the authority of another person. A false claim of ownership is distinct from a false document. Without a false document, there is no forgery, and without forgery, Sections 467 and 471 IPC are not attracted.

**RATIO 2 (On Cheating — Locus):**
In a sale transaction executed with a false claim of ownership, only the purchaser (who was induced to part with consideration through deception) has locus to allege cheating under Sections 415-420 IPC — not a third party claiming to be the true owner, upon whom no deception was practised and to whom no inducement was offered.

**RATIO 3 (On Criminal-Civil Demarcation):**
Where complaint averments, even if assumed true in their entirety, do not disclose the statutory ingredients of the charged criminal offences, the criminal proceedings to that extent must be quashed — regardless of the fact that the underlying conduct may give rise to civil remedies.

---

## 1.7 OBITER DICTA

**OBITER 1:** Fraud is not per se an offence under the Penal Code. Only specific fraudulent acts enumerated in the Code (listed in ¶16 as thirteen categories) constitute offences. Merely showing that a person acted "fraudulently" does not establish a criminal offence. [¶15-16] — *Matters because it provides a checklist for filtering out vague "fraud" allegations.*

**OBITER 2:** If a person sells property knowing it doesn't belong to him and thereby defrauds the purchaser, the purchaser may have a criminal complaint of cheating. [¶15] — *Matters because it preserves the purchaser's criminal remedy while closing it for third parties.*

**OBITER 3:** Several disputes of a civil nature may also contain ingredients of criminal offences and must be tried as such. [¶7] — *Matters because it prevents this judgment from becoming a blanket shield against criminal proceedings in all property disputes.*

---

## 1.8 OPERATIVE ORDER

Appeal allowed in part. Order of the Patna High Court set aside. Order dated 14.12.2005 of the Sub-Divisional Magistrate quashed insofar as offences under Sections 420, 467, 471, and 504 IPC. Charges framed under those sections quashed. Order and charges under Sections 323 and 341 IPC left undisturbed.

---

# ═══════════════════════════════════════════════════════
# DIMENSION 2: THE STRUCTURAL
# (How the reasoning is architecturally built)
# ═══════════════════════════════════════════════════════

---

## 2.1 THE LOGICAL SYLLOGISMS (The Judgment's DNA)

**SYLLOGISM 1 — The Forgery Chain (¶8-12):**
```
Major Premise : Sections 467/471 require "forgery" as a condition precedent.
                Forgery (S.463) requires "making a false document."
                A "false document" (S.464) requires one of three things:
                (a) the document was made with intent that it be believed
                    to be made BY or BY AUTHORITY of another person; OR
                (b) unauthorized material alteration; OR
                (c) obtaining signature by deception of an incapacitated person.
Minor Premise : The first accused executed the sale deeds IN HIS OWN NAME,
                AS HIMSELF. He did not impersonate the complainant.
                He did not claim to act on the complainant's authority.
                He did not alter any existing document.
                He did not deceive an incapacitated person.
Conclusion    : The sale deeds are NOT "false documents" under S.464.
                → Therefore, no "forgery" under S.463.
                → Therefore, S.467 and S.471 are not attracted.
```

**SYLLOGISM 2 — The Cheating Chain (¶13-14):**
```
Major Premise : Cheating (S.415) requires: (a) deception of A PERSON;
                (b) fraudulent inducement of THAT PERSON to deliver property
                or act/omit; (c) resulting damage to THAT PERSON.
                S.420 additionally requires dishonest inducement to deliver
                property or alter/destroy a valuable security.
Minor Premise : The complainant is NOT the purchaser. The purchaser is a
                co-accused. No deception was practised upon the complainant.
                No inducement was offered to the complainant. The complainant
                was not induced to deliver any property.
Conclusion    : The ingredients of cheating are absent vis-à-vis the
                complainant. Ss. 415-420 not attracted.
```

**SYLLOGISM 3 — The Insult Chain (¶17):**
```
Major Premise : S.504 requires "intentional insult with intent to provoke
                breach of peace."
Minor Premise : The statement attributed to the accused — "we will get
                possession, do what you want" — is an assertion of legal
                position, not an insult.
Conclusion    : S.504 not attracted.
```

**SYLLOGISM 4 — The Surviving Charges (¶18):**
```
Major Premise : S.323 (causing hurt) and S.341 (wrongful restraint)
                require physical acts of violence/restraint.
Minor Premise : The complaint alleges the accused "abused him and hit him
                with fists" — this technically satisfies the ingredients.
Conclusion    : Ss. 323 and 341 charges sustained.
```

**CHAIN LOGIC:**
```
Syllogism 1 (No false document → No forgery → Ss.467/471 quashed)
     ↓ [Independent]
Syllogism 2 (No deception of complainant → No cheating → S.420 quashed)
     ↓ [Independent]
Syllogism 3 (No insult → S.504 quashed)
     ↓ [Independent]
Syllogism 4 (Physical assault alleged → Ss.323/341 sustained)
     ↓
OPERATIVE ORDER: Partial quashing
```

Note: Syllogisms 1-4 are **independent chains** — each stands or falls on its own. The failure of Syllogism 1 would not affect Syllogism 2, and vice versa. This is an architecturally clean judgment.

---

## 2.2 THE DEPENDENCY TREE

```
ROOT: Partial Quashing of Charges
│
├── BRANCH A: Quashing of Ss.467/471 (Forgery)
│   ├── DEPENDS ON: Sale deeds are NOT "false documents" (¶12)
│   │   ├── DEPENDS ON: First accused signed in his own name (FACT)
│   │   ├── DEPENDS ON: No impersonation alleged (FACT)
│   │   ├── DEPENDS ON: No claim of acting on complainant's authority (FACT)
│   │   └── DEPENDS ON: S.464 "Firstly" requires intent that document
│   │       be believed to be made BY or BY AUTHORITY of another
│   │       person (LAW — textual reading)
│   │       └── HIDDEN DEPENDENCY: The word "another person" in S.464
│   │           means a SPECIFIC identifiable person, not just "a person
│   │           who is the true owner" in the abstract [UNSTATED ASSUMPTION]
│   │
│   └── DEPENDS ON: No alteration or deception of incapacitated person (FACT)
│
├── BRANCH B: Quashing of S.420 (Cheating)
│   ├── DEPENDS ON: Complainant was not the purchaser (FACT)
│   ├── DEPENDS ON: No deception practised on complainant (FACT)
│   └── DEPENDS ON: Cheating requires deception of "a person" and that
│       "person" must be the one induced to deliver property (LAW)
│       └── HIDDEN DEPENDENCY: A sale deed that deprives a true owner of
│           property rights does not constitute "deception" of the true
│           owner within the meaning of S.415 [UNSTATED ASSUMPTION]
│
├── BRANCH C: Quashing of S.504 (Insult)
│   └── DEPENDS ON: Asserting legal position ≠ insult (FACTUAL CHARACTERIZATION)
│
└── BRANCH D: Sustaining Ss.323/341 (Hurt/Restraint)
    └── DEPENDS ON: Complaint alleges physical hitting (FACT)
```

---

## 2.3 THE JUDGE'S INTERPRETIVE METHOD FINGERPRINT

```
Primary Method Used    : STRICT LITERAL / TEXTUAL INTERPRETATION of Section 464.
                         The court parsed each word — "by whom or by whose authority
                         he knows that it was not made" — and applied it to the facts
                         with clinical precision.

Why This Method        : Implicit. The court does not explain why it chose literal
                         interpretation over purposive interpretation. This is itself
                         significant — see Dimension 3 (Hidden Assumptions).

What Would Change      : If PURPOSIVE interpretation were used, the outcome could
                         flip. The PURPOSE of Sections 463-471 is to punish creation
                         of documents intended to deceive. A sale deed for property
                         you don't own, executed to fraudulently transfer title, is
                         PRECISELY the kind of document-based deception the forgery
                         provisions were designed to prevent. A purposive court could
                         argue that "false document" should include documents containing
                         materially false claims of entitlement.

Judge's Interpretive
Tendency               : Justice Raveendran in this judgment is a STRICT TEXTUALIST
                         with respect to penal provisions — consistent with the
                         established doctrine that penal statutes must be strictly
                         construed. However, the judgment does not explicitly invoke
                         this doctrine, which is a structural weakness.
```

---

## 2.4 RHETORICAL ARCHITECTURE

```
Opening Move           : The judge begins with procedural history (¶1-6), then
                         frames the key question (¶6), then announces the
                         PRINCIPLE before applying it (¶7). This is a
                         "principle-first" judgment structure.

Persuasion Technique   : ELIMINATIVE REASONING — The judge eliminates each
                         offence one by one (forgery → cheating → insult),
                         showing why each fails on ingredients. This creates
                         a cumulative sense of inevitability.

Use of Metaphor/Analogy: The court uses a powerful STRUCTURAL ANALOGY (¶12):
                         the distinction between "claiming property is mine" vs
                         "claiming I am the owner" (impersonation). This is the
                         judgment's intellectual centerpiece.

Tone                   : MEASURED AND INSTRUCTIVE. The judge is not reprimanding
                         the lower courts but teaching. The "clarification" section
                         (¶15) is essentially a mini-lecture on fraud under the IPC.

Strategic Ambiguity    : YES — at ¶15, the court says "we should not be understood
                         as holding that such an act can NEVER be a criminal offence."
                         This is deliberate ambiguity — it quashes these charges
                         while leaving the door open for other provisions (S.423?)
                         to apply in similar facts. The court is protecting its
                         flank against being over-cited.
```

---

# ═══════════════════════════════════════════════════════
# DIMENSION 3: THE INVISIBLE
# (What the judgment hides — Sub-atomic extraction)
# ═══════════════════════════════════════════════════════

---

## 3.1 THE UNSTATED MAJOR PREMISES (Hidden Assumptions)

**HIDDEN ASSUMPTION 1:**
```
What the court assumes  : That the word "person" in S.464 Firstly — "intention
                          of causing it to be believed that such document was made
                          by or by the authority of A PERSON" — requires a SPECIFIC
                          IDENTIFIABLE person. The court reads this as requiring
                          impersonation of a named individual or claim of authority
                          from a named individual.

Where it operates       : ¶12 — the entire forgery analysis rests on this.

Why this matters        : An alternative reading is possible — that when Ibrahim
                          executed a sale deed for land he didn't own, the Sub-Registrar
                          and the purchaser were led to believe that this document was
                          executed by "the owner" — an identifiable class even if not
                          named. Ibrahim's act of executing the deed as "owner" could
                          be seen as impersonating "the owner" in a functional sense.

How to challenge        : Argue that S.464 Firstly doesn't require impersonation of
                          a NAMED person — it requires creating a false belief about
                          WHO made the document. "I am the owner and I sell this land"
                          creates a false belief about the identity of the maker in
                          a legally relevant sense (the maker as "owner").
```

**HIDDEN ASSUMPTION 2:**
```
What the court assumes  : That the "identity" of a document-maker is limited to their
                          NAME and PERSONAL identity — not their LEGAL CAPACITY.
                          The court treats "made by a person" as purely about personal
                          identity (who signed it), not about legal capacity
                          (in what capacity they signed it).

Where it operates       : ¶12 — "He is not claiming that he is someone else."

Why this matters        : In property law, the identity of a seller IS their ownership.
                          When Ibrahim signs a sale deed, the document doesn't just say
                          "Ibrahim signed this" — it says "Ibrahim, AS OWNER, conveys
                          this property." The document represents Ibrahim as having a
                          legal capacity (ownership) that he doesn't possess. This could
                          be characterized as the document being made "by the authority
                          of" the actual owner, which it wasn't.

How to challenge        : Argue that in conveyancing documents, the maker's identity
                          INCLUDES their legal capacity as owner. A sale deed by a
                          non-owner falsely represents the maker's identity in the only
                          way that matters for that class of documents.
```

**HIDDEN ASSUMPTION 3:**
```
What the court assumes  : That the doctrine of strict construction of penal statutes
                          applies, although this is never explicitly stated.

Where it operates       : Throughout — the court gives S.464 its narrowest possible
                          reading at every interpretive choice point.

Why this matters        : If the court had stated this doctrine explicitly, opponents
                          could have argued for exceptions (e.g., the mischief rule,
                          or that S.464 should be read in light of S.463's broader
                          purpose of preventing document-based deception).

How to challenge        : Invoke the purposive interpretation doctrine. The IPC's
                          forgery chapter exists to punish creation of documents
                          intended to deceive about material facts. A sale deed
                          with a false ownership claim is deceptive about the most
                          material fact possible in a conveyance.
```

**HIDDEN ASSUMPTION 4:**
```
What the court assumes  : That the complainant (true owner) is genuinely a "third party"
                          with no direct relationship to the transaction — like a
                          bystander. The court treats the cheating analysis as if the
                          true owner is irrelevant to the sale transaction.

Where it operates       : ¶14 — "It is not the case of the complainant that any of
                          the accused tried to deceive him."

Why this matters        : The true owner IS harmed by the transaction — his property
                          is being sold. The sale deed, once registered, creates a
                          presumption of title in the purchaser. The complainant is not
                          a random bystander — he is the DIRECT VICTIM of the
                          fraudulent conveyance. The court's framing of him as an
                          unaffected third party is a characterization choice, not a
                          factual necessity.

How to challenge        : Argue that "deception" under S.415 need not be face-to-face.
                          The execution and registration of a sale deed for another's
                          property is an act that operates as a continuing deception
                          upon ALL persons, including the true owner, because the
                          registered deed creates a false legal record that can be
                          used against the true owner in future proceedings.
```

---

## 3.2 THE SILENT ARGUMENTS (Never Argued But Should Have Been)

**SILENT ARGUMENT 1:**
```
The argument           : Section 423 IPC — Dishonest or fraudulent execution of
                         deed of transfer containing FALSE STATEMENT OF CONSIDERATION.
                         The first accused executed a deed transferring property that
                         (as alleged) did not belong to him. While S.423 specifically
                         targets "false statement of consideration," the prosecution
                         could have argued that the entire deed is fraudulent because
                         the very premise (that the seller owns the property) is false.
                         More importantly — was the consideration stated accurately?
                         This was never examined.

Who should have argued : The Prosecution / Complainant's counsel.

Why it matters         : The court itself HINTS at this in ¶16 by listing S.423 as
                         one of the specific fraudulent acts made punishable under
                         the Code. This was a breadcrumb the court dropped that nobody
                         picked up.

The provision          : Section 423 IPC.
```

**SILENT ARGUMENT 2:**
```
The argument           : Section 421 IPC — Dishonest or fraudulent removal or
                         concealment of property to prevent distribution among
                         creditors. While not directly about sale, the argument
                         could have been: by executing a sale deed and creating
                         a paper trail of ownership transfer, the first accused was
                         effectively "removing" the complainant's property from his
                         reach — making it harder for the complainant to exercise
                         his rights as the true owner.

Who should have argued : The Prosecution.

Why it matters         : Would have forced the court to analyze the ACT of creating
                         a competing title document as a form of property-related fraud
                         beyond just forgery and cheating.

The provision          : Section 421 IPC.
```

**SILENT ARGUMENT 3:**
```
The argument           : Criminal conspiracy (S.120B IPC) read with S.420 with the
                         PURCHASER as the victim. The prosecution made the purchaser
                         a co-accused (alleging collusion). But an alternative framing
                         was available: if the purchaser was a genuine purchaser (not
                         colluding), then the first accused DID cheat the purchaser
                         by selling land that wasn't his. The prosecution never
                         separated the purchaser from the conspiracy — this foreclosed
                         the most natural cheating argument.

Who should have argued : The Prosecution (alternative framing).

Why it matters         : The court explicitly says at ¶14 that the complaint is "not
                         by the purchaser" and the "purchaser is made a co-accused."
                         This framing CREATED the locus problem. A smarter prosecution
                         strategy would have treated the purchaser as a victim of the
                         first accused, not a co-conspirator.

The provision          : S.420 read with S.120B IPC (alternative prosecution theory).
```

**SILENT ARGUMENT 4:**
```
The argument           : The Registration Act angle. A sale deed is presented before
                         a Sub-Registrar who registers it based on the REPRESENTATION
                         of the executant that he is entitled to execute the deed. If
                         this representation is false, the Sub-Registrar (a public
                         servant) has been deceived. This could attract S.420 (cheating
                         a public servant) or S.417 (cheating) — with the SUB-REGISTRAR
                         as the victim, not the complainant.

Who should have argued : The Prosecution or the Court suo motu.

Why it matters         : Completely sidesteps the locus problem. The victim of deception
                         is no longer the third-party complainant but the State
                         (through its Sub-Registrar).

The provision          : S.417/420 IPC with the Sub-Registrar as the person deceived.
```

---

## 3.3 THE FACT-SENSITIVITY MATRIX

**LOAD-BEARING FACTS (Remove any one → outcome changes):**

| # | Fact | Load-Bearing Because |
|---|------|---------------------|
| 1 | The first accused executed the sale deeds **in his own name** | If he had signed as "authorized by complainant" or impersonated the complainant → Syllogism 1 collapses → forgery IS made out |
| 2 | The complainant is **not the purchaser** | If the complainant were the purchaser → Syllogism 2 collapses → cheating IS made out (the very person deceived is complaining) |
| 3 | The purchaser is **a co-accused** (alleged colluder) | If the purchaser were an innocent third party → alternative prosecution theory of cheating the purchaser becomes available |
| 4 | No allegation of impersonation | If the complaint alleged that the first accused pretended to be the complainant at the Sub-Registrar's office → forgery directly applicable |

**DECORATIVE FACTS (Present but irrelevant to ratio):**

| # | Fact | Why Decorative |
|---|------|---------------|
| 1 | The cousins' family arrangement and inheritance history | The court assumes the complaint to be true (no ownership determination). The actual ownership dispute is irrelevant to the legal analysis of whether ingredients of forgery/cheating are met. |
| 2 | The specific land measurements (1 bigha, 5 Katha, etc.) | No impact on the legal analysis. |
| 3 | That the third accused was a witness, fourth was scribe, fifth was stamp vendor | Their specific roles don't affect the forgery/cheating analysis. If there's no forgery by the first accused, there's no conspiracy with the others. |
| 4 | That the first accused's name was entered in revenue records | Irrelevant to the legal question of whether S.464 is attracted. |

**AMBIGUOUS FACTS:**

| # | Fact | Why Ambiguous |
|---|------|--------------|
| 1 | Whether the first accused **knew** the property didn't belong to him | The court says "even if it is assumed" the property didn't belong to him (¶9). But KNOWLEDGE of non-ownership vs BELIEF of ownership matters. If the court had found proven knowledge + dishonest intent, would it still have reached the same conclusion on S.464? Logically yes (the textual argument still holds), but practically, a court's interpretive appetite can shift when faced with clear dishonesty. |

---

## 3.4 COUNTER-FACTUAL ANALYSIS (The "What If" Machine)

**COUNTER-FACTUAL 1:**
```
Original Fact          : The first accused signed the sale deeds in his own name.
Altered Fact           : The first accused signed AS the complainant (impersonation)
                         or as "authorized agent of the complainant."
Impact on Reasoning    : Syllogism 1 collapses completely. The document IS made
                         "with the intention of causing it to be believed that such
                         document was made by... a person by whom... he knows that
                         it was not made." S.464 Firstly is directly attracted.
Likely New Outcome     : Charges under Ss. 467, 471 sustained. Case proceeds to trial.
Applicable Provision   : Ss. 463, 464 (Firstly), 467, 471 IPC — all attracted.
```

**COUNTER-FACTUAL 2:**
```
Original Fact          : The complainant (true owner) filed the criminal complaint.
Altered Fact           : The PURCHASER filed the complaint, alleging he was cheated
                         into buying property that didn't belong to the seller.
Impact on Reasoning    : Syllogism 2 collapses. The purchaser IS the person deceived,
                         IS the person induced to part with consideration, IS the
                         person suffering loss. All ingredients of S.415/420 met.
Likely New Outcome     : S.420 charges sustained. The court itself acknowledges this
                         possibility at ¶14-15.
Applicable Provision   : Ss. 415, 417, 418, 419, 420 IPC — potentially all attracted.
```

**COUNTER-FACTUAL 3:**
```
Original Fact          : The first accused claimed ownership based on inheritance
                         through family arrangement (plausible counter-narrative).
Altered Fact           : The first accused was a complete stranger to the land
                         with no colorable claim whatsoever.
Impact on Reasoning    : Legally, the court's analysis SHOULD NOT change (the textual
                         reading of S.464 doesn't depend on the strength of the
                         seller's claim). But practically, a court facing a brazen
                         fraudster with zero connection to the land might be more
                         inclined to adopt a PURPOSIVE interpretation of S.464.
Likely New Outcome     : Uncertain — depends on the court's interpretive appetite.
                         The textual argument still holds, but judicial temperament
                         matters.
Applicable Provision   : Same provisions — but S.423 IPC becomes much more compelling.
```

**COUNTER-FACTUAL 4:**
```
Original Fact          : The accused verbally said "do what you want, we will get
                         possession" when confronted.
Altered Fact           : The accused made explicit threats of violence or used
                         casteist/communal slurs.
Impact on Reasoning    : Syllogism 3 collapses. Explicit threats or slurs would
                         satisfy "intentional insult with intent to provoke breach
                         of peace" under S.504.
Likely New Outcome     : S.504 charges sustained.
Applicable Provision   : S.504 IPC, possibly S.506 (criminal intimidation).
```

**COUNTER-FACTUAL 5 (The Most Interesting One):**
```
Original Fact          : The sale deeds were registered before a Sub-Registrar.
Altered Fact           : The sale deeds were UNREGISTERED private documents.
Impact on Reasoning    : The entire analysis remains the same (S.464 doesn't
                         distinguish between registered and unregistered documents).
                         BUT — the registration creates an additional dimension:
                         a representation to a public servant (the Sub-Registrar)
                         that the executant is entitled to execute the deed. This
                         opens up S.420 with the Sub-Registrar as victim — an
                         argument nobody made (see Silent Argument 4).
Likely New Outcome     : Same on forgery. But if the "registration = deception of
                         Sub-Registrar" argument had been raised, a parallel S.420
                         charge might survive.
Applicable Provision   : S.420 IPC (with Sub-Registrar as person deceived).
```

---

## 3.5 THE INTERPRETATION THAT WASN'T CHOSEN

**ALTERNATIVE INTERPRETATION 1:**
```
What it would have been    : "False document" in S.464 Firstly should be read to include
                             documents that contain materially false representations about
                             the maker's LEGAL CAPACITY — not just their personal identity.
                             A sale deed executed by a non-owner contains a materially false
                             representation (that the executant is the owner) which is
                             DESIGNED to be believed by the purchaser and the Sub-Registrar.

Why the court didn't adopt : The court focused on the phrase "by whom or by whose authority"
                             and read it as requiring impersonation of personal identity.
                             The alternative reading was never argued by counsel and the
                             court didn't consider it suo motu.

Is it defensible?          : YES — reasonably defensible. The word "person" in S.464 can be
                             read as "the person who is entitled to execute the document"
                             rather than "the person whose name appears on the document."
                             When a non-owner signs a sale deed, the document IS misleading
                             about who made it — because the document purports to be made by
                             "the owner," which is a person other than the one who signed it.

What would change          : Forgery charges would be sustained. S.467 and S.471 attracted.
                             This would be a dramatic expansion of forgery law in property
                             disputes.
```

**ALTERNATIVE INTERPRETATION 2:**
```
What it would have been    : Cheating (S.415) should be interpreted to include "indirect
                             deception" — where the act of creating a registered document
                             operates as a continuing deception upon ALL persons whose
                             rights are affected, including the true owner. The registration
                             of a false sale deed creates a public record that can be used
                             to dispossess the true owner — this is deception by operation
                             of law, not face-to-face deception.

Why the court didn't adopt : The court read "deception of a person" in S.415 as requiring
                             DIRECT, face-to-face deception — a representation made TO the
                             complainant. The broader reading was not argued.

Is it defensible?          : PARTIALLY — it stretches the text of S.415, which does
                             contemplate a specific person being deceived. But the argument
                             has force in the context of registered documents, which operate
                             erga omnes (against all the world).

What would change          : True owners could maintain cheating complaints even without
                             being purchasers. This would significantly expand criminal
                             liability in property fraud.
```

---

## 3.6 THE DOCTRINAL UNDERCURRENT

```
Underlying Doctrine(s)  : 1. STRICT CONSTRUCTION OF PENAL STATUTES — The court gives
                              S.464 its narrowest possible reading, consistent with the
                              principle that penal provisions creating offences must be
                              interpreted in favour of the accused.
                           2. SEPARATION OF CIVIL AND CRIMINAL REMEDIES — The court
                              operates on the implicit principle that when a civil remedy
                              is adequate, criminal law should not be stretched to cover
                              the same ground.
                           3. INGREDIENT-BASED ANALYSIS — The court checks each statutory
                              ingredient against the facts, refusing to consider "spirit"
                              or "mischief" of the provision.

How It Manifests         : The entire judgment is an exercise in ingredient-checking.
                           At no point does the court ask: "Was what the accused did
                           harmful/fraudulent/wrong?" Instead, it asks only: "Do the
                           specific statutory ingredients match the specific alleged facts?"
                           This is pure textualism.

Tension With Other
Doctrines               : This approach is in tension with:
                           (a) PURPOSIVE INTERPRETATION — which would ask WHY the forgery
                               provisions exist and whether this conduct falls within
                               the mischief they were designed to prevent.
                           (b) VICTIM-CENTRIC JURISPRUDENCE — which might ask whether
                               the true owner is left without an adequate criminal
                               remedy when their property is fraudulently sold.
                           (c) The EXPANDING SCOPE of fraud-related jurisprudence in
                               India, which has generally trended toward broader
                               interpretation of criminal fraud provisions.
```

---

# ═══════════════════════════════════════════════════════
# DIMENSION 4: THE WEAPONIZABLE
# (How to USE this judgment and how to ATTACK it)
# ═══════════════════════════════════════════════════════

---

## 4.1 THE JUDGMENT AS A SWORD (Offensive Uses)

**USE CASE 1:**
```
Scenario              : Client accused of forgery (S.467/471) for executing a sale
                         deed, gift deed, or lease deed for property where ownership
                         is disputed — but client signed in his own name.
How to cite           : ¶12 — "There is a fundamental difference between a person
                         executing a sale deed claiming that the property conveyed is
                         his property, and a person executing a sale deed by
                         impersonating the owner."
The argument          : "As held in Md. Ibrahim (2009) 8 SCC 751, the execution of
                         a conveyance deed by a person in his own name, claiming
                         property as his own, does not constitute a 'false document'
                         under Section 464 IPC. No forgery is made out. Sections 467
                         and 471 are not attracted. The charge is liable to be quashed."
Stage                 : Most effective at DISCHARGE stage (S.227/239 CrPC) or
                         QUASHING stage (S.482 CrPC). Can also be argued at CHARGE
                         stage (S.228/240 CrPC).
```

**USE CASE 2:**
```
Scenario              : Client is the true owner of property. An adversary has sold
                         client's property to a third party. Client has filed a
                         criminal complaint of cheating. Defence cites this judgment.
How to COUNTER-USE    : Use ¶15 (obiter) — "If a person sells a property knowing
                         that it does not belong to him, and thereby defrauds the
                         person who purchased the property, the person defrauded,
                         that is the purchaser, may complain." Argue that the
                         purchaser should be the complainant and re-file with
                         purchaser's complaint, or argue S.423 IPC instead.
Stage                 : At COMPLAINT stage — restructure the prosecution theory.
```

**USE CASE 3:**
```
Scenario              : Client accused of criminal conspiracy (S.120B) for being
                         the witness/scribe/stamp vendor in a sale deed where the
                         seller's ownership is disputed.
How to cite           : ¶18-19 — If the principal offence (forgery) is not made out,
                         the conspiracy to commit that offence cannot survive.
The argument          : "The substantive offence of forgery being not made out as
                         per Md. Ibrahim (supra), the charge of conspiracy to commit
                         forgery against the witness/scribe/stamp vendor must also fall."
Stage                 : DISCHARGE or QUASHING.
```

---

## 4.2 THE JUDGMENT AS A SHIELD (Defensive Uses)

**DEFENCE SCENARIO 1:**
```
Attack being faced    : Forgery charges for executing a power of attorney, will,
                         or partition deed where the executant's right is disputed.
How this judgment helps: The principle applies to ALL documents, not just sale deeds.
                         If the executant signs in their own name and doesn't
                         impersonate anyone, S.464 is not attracted.
Key distinction       : The executant must have signed IN THEIR OWN NAME. If they
                         signed as "attorney of X" without actually being authorized
                         by X, this judgment does NOT protect them.
```

**DEFENCE SCENARIO 2:**
```
Attack being faced    : Multiple IPC charges including forgery + cheating + other
                         sections, creating an intimidating charge-sheet.
How this judgment helps: Strip away the forgery and cheating charges using this
                         judgment, leaving only minor charges (like S.323/341).
                         This dramatically reduces the severity of the case and
                         may make the remaining charges compoundable.
Key distinction       : The remaining charges (S.323/341) are compoundable under
                         S.320 CrPC — once the serious charges are quashed, the
                         case becomes easily settleable.
```

---

## 4.3 THE VULNERABILITY MAP (How to Attack This Judgment)

**VULNERABILITY 1:**
```
The Weak Point        : The court never addresses the PURPOSIVE interpretation of
                         S.464. The entire analysis is textual. A purposive reading
                         — asking what mischief S.464 was designed to prevent — could
                         yield a different result.
Attack Vector         : Argue before a larger bench that S.464 should be interpreted
                         purposively: the provision exists to prevent document-based
                         fraud, and a sale deed containing a knowingly false ownership
                         claim IS a form of document-based fraud.
Likelihood of Success : MEDIUM — the textualist reading is strong for penal statutes,
                         but the purposive argument has real force, especially in an
                         era of increasing property fraud.
What Would Be Needed  : A 3-judge bench willing to reconsider the narrow reading.
```

**VULNERABILITY 2:**
```
The Weak Point        : The court's treatment of the complainant (true owner) as
                         a mere "third party" with no standing to allege cheating.
                         This leaves the true owner with NO criminal remedy (only
                         civil remedies), which seems unjust when property fraud
                         is intentional.
Attack Vector         : Argue that S.415 should be read to include "indirect
                         deception" — the registered sale deed operates as a
                         continuing deception upon the true owner by creating a
                         false public record.
Likelihood of Success : LOW-MEDIUM — the text of S.415 is quite clear about
                         requiring direct deception of "a person," but an expansive
                         reading is not impossible.
What Would Be Needed  : A case with egregious facts (e.g., organized land mafia
                         systematically selling others' properties) where the court
                         feels compelled to expand the reading.
```

**VULNERABILITY 3:**
```
The Weak Point        : The judgment is by a 2-judge bench. It can be overruled by
                         ANY bench of 3 or more judges.
Attack Vector         : Seek reference to a 3-judge bench arguing that the question
                         of whether S.464 covers false ownership claims in
                         conveyancing documents requires authoritative settlement.
Likelihood of Success : LOW — the judgment is well-reasoned and has been widely
                         followed. But the 2-judge bench strength makes it
                         technically vulnerable.
What Would Be Needed  : A High Court creating a conflicting precedent, leading to
                         a reference to a larger SC bench.
```

**VULNERABILITY 4:**
```
The Weak Point        : The judgment doesn't address the impact of the NEW BNS
                         (Bharatiya Nyaya Sanhita, 2023) provisions replacing IPC.
                         The corresponding BNS sections may have different language
                         that changes the analysis.
Attack Vector         : Argue that the BNS provisions (which replaced Ss.463-471 IPC)
                         have broader language that covers this factual scenario, making
                         the Md. Ibrahim ratio inapplicable to post-BNS cases.
Likelihood of Success : REQUIRES ANALYSIS of the specific BNS language — this is a
                         forward-looking vulnerability.
What Would Be Needed  : Detailed comparison of IPC S.464 with corresponding BNS
                         provision.
```

```
OVERALL DURABILITY SCORE: 7/10

REASONING: The judgment is textually sound and has been followed for 15+ years.
Its 2-judge bench status is a structural weakness but practically unlikely to be
exploited given its wide acceptance. The BNS replacement of IPC is the biggest
threat — if the BNS provisions use broader language, this ratio may become
historically interesting but practically obsolete for new cases. Within the IPC
framework, it remains robust.
```

---

## 4.4 THE DISTINGUISHING PLAYBOOK

**DISTINGUISHING STRATEGY 1:**
```
Factual Difference    : In your case, the accused did not just sell the property
                         in his own name — he FORGED or FABRICATED documents
                         showing his ownership (e.g., forged mutation entries,
                         fabricated inheritance documents).
The Argument          : "Md. Ibrahim is distinguishable because in that case, the
                         accused signed in his own name with a bona fide claim.
                         Here, the accused not only sold the property but fabricated
                         supporting title documents — which ARE false documents
                         under S.464."
```

**DISTINGUISHING STRATEGY 2:**
```
Factual Difference    : The accused used a fake identity or assumed the identity
                         of the actual owner at the Sub-Registrar's office.
The Argument          : "In Md. Ibrahim, the court specifically distinguished between
                         selling property 'as one's own' versus 'impersonating the
                         owner.' Here, the accused impersonated the true owner —
                         which falls squarely within S.464 Firstly."
```

**DISTINGUISHING STRATEGY 3:**
```
Factual Difference    : The purchaser is the complainant (the person who bought
                         the property and then discovered the seller had no title).
The Argument          : "Md. Ibrahim denied locus to a third-party complainant. Here,
                         the complainant is the purchaser himself — the very person
                         deceived and induced to part with consideration. The court
                         in Md. Ibrahim expressly preserved this remedy at ¶15."
```

---

## 4.5 CROSS-DOMAIN TRANSPLANTATION MAP

**TRANSPLANT 1:**
```
Original Domain       : Criminal (IPC) — Forgery in property sale disputes
Target Domain         : Intellectual Property — Trademark/Copyright disputes
Analogous Principle   : If someone sells goods under their own brand name but the
                         product design is copied from another brand, is that
                         "forgery" of the product? Applying Md. Ibrahim's logic:
                         if the seller sells under his OWN name/brand (not
                         counterfeiting the original brand), it may not constitute
                         forgery — but may still be passing off or design infringement.
Viability             : MEDIUM — the analogy holds structurally (own-name vs.
                         impersonation) but IP law has its own statutory framework.
```

**TRANSPLANT 2:**
```
Original Domain       : Criminal (IPC) — Locus to allege cheating
Target Domain         : Corporate Law — Shareholder disputes
Analogous Principle   : If a director transfers company property to himself and
                         another shareholder complains of cheating — does the OTHER
                         SHAREHOLDER have locus? Md. Ibrahim's logic suggests only
                         the company (the entity whose property was transferred) has
                         locus, not individual shareholders.
Viability             : HIGH — directly applicable in corporate fraud cases where
                         minority shareholders attempt to use S.420 against directors.
```

**TRANSPLANT 3:**
```
Original Domain       : Criminal — "False claim of ownership ≠ false document"
Target Domain         : Negotiable Instruments (Cheque Bounce — S.138 NI Act)
Analogous Principle   : If someone issues a cheque from their own account but for
                         a debt they dispute owing — is the cheque a "false document"?
                         Md. Ibrahim's logic: the cheque is signed by the actual
                         account holder, not an impersonator, so it cannot be a
                         "false document" even if the underlying claim is disputed.
Viability             : HIGH — directly useful in defending against S.138 cases
                         where the defence is "disputed liability."
```

---

## 4.6 THE TEMPORAL VULNERABILITY ANALYSIS

```
Current Bench Strength    : 2-Judge Bench
Can It Be Overruled By    : Any bench of 3+ judges of the Supreme Court
Legislative Override Risk : HIGH — The replacement of IPC with BNS (Bharatiya Nyaya
                            Sanhita, 2023) creates the biggest risk. If the BNS
                            provisions on forgery use broader or different language,
                            this interpretation may not apply to post-01.07.2024 cases.
Societal Shift Risk       : MEDIUM — Increasing property fraud and land-grabbing in
                            India may create judicial appetite for broader criminal
                            liability. Courts may feel that leaving true owners with
                            only civil remedies is inadequate.
Conflicting Trends        : Some High Courts have taken broader views of S.464 in
                            property fraud contexts. No direct Supreme Court conflict
                            as of the judgment date.
Survival Probability      : MEDIUM-HIGH for IPC-era cases (pre-01.07.2024).
                            UNCERTAIN for BNS-era cases — depends on new statutory
                            language.
```

---

# ═══════════════════════════════════════════════════════
# DIMENSION 5: THE SYNTHESIS
# ═══════════════════════════════════════════════════════

---

## 5.1 THE INTERPRETIVE LINEAGE MAP

### PROVISION: Section 464 IPC — "Making a False Document"

| Year | Case | Layer Added | Method | Status | Durability |
|------|------|------------|--------|--------|-----------|
| 1860 | IPC Enacted | Three categories of false documents defined | Legislative | Foundation | Permanent (within IPC) |
| 1963 | Dr. Vimla v. Delhi Admn. | "Defraud" = deceit + injury (including non-pecuniary) | Literal | Good Law | HIGH |
| 1999 | State of UP v. Ranjit Singh | Reaffirmed Dr. Vimla definition | — | Good Law | HIGH |
| 2000 | G. Sagar Suri v. State of UP | Gatekeeping: don't criminalize civil disputes | Purposive | Good Law | HIGH |
| 2006 | IOC v. NEPC India | Balance: civil disputes CAN contain criminal elements | Purposive | Good Law | HIGH |
| **2009** | **Md. Ibrahim v. State of Bihar** | **False ownership claim ≠ false document. Impersonation/false authority REQUIRED. Third-party owner cannot allege cheating in sale.** | **Literal/Strict** | **Current Position** | **7/10** |

---

## 5.2 THE ONE-PARAGRAPH GENOME SUMMARY

This judgment draws a deceptively simple but profoundly consequential bright line within the Indian Penal Code's forgery provisions: a person who sells property in his own name, claiming it as his own, does not create a "false document" under Section 464 — even if the property actually belongs to someone else — because the statutory definition of a false document requires the maker to either impersonate another person or falsely claim authorization from another person, and a false claim of ownership is neither. The judgment's hidden load-bearing structure rests on an unstated assumption that "identity" in Section 464 means personal identity (who signed the document), not legal capacity (whether the signer had the right to execute the document) — an assumption that a purposive court could challenge. Its most significant practical consequence is the creation of a "locus gap": the true owner cannot allege cheating (because no deception was practiced upon him) and the purchaser cannot allege cheating (because he's a co-accused), leaving the only criminal remedy for property fraud dependent on the prosecution's strategic framing — a framing that could have been different had Section 423 IPC or the Sub-Registrar-as-victim theory been argued. The judgment is structurally clean (four independent syllogistic chains), textually rigorous, and has survived 15+ years of citation, but its 2-judge bench status and the replacement of IPC with BNS create real, if not imminent, vulnerability.

---

## 5.3 THE PRACTITIONER'S CHEAT SHEET

```
CITE THIS JUDGMENT WHEN:
  1. Client executed a sale/gift/lease deed in own name for property 
     whose ownership is disputed → quash forgery charges.
  2. Client is a witness/scribe/stamp vendor in such a deed → if no 
     forgery by the principal, no conspiracy for accessories.
  3. Criminal complaint of cheating filed by a person OTHER than the 
     purchaser in a sale transaction → quash cheating charges.

DO NOT CITE THIS JUDGMENT WHEN:
  1. The accused impersonated the actual owner or forged the owner's 
     signature → S.464 Firstly is directly attracted.
  2. The complainant IS the purchaser alleging deception → the court 
     expressly preserved this remedy (¶15).
  3. The accused fabricated supporting documents (fake mutation entries, 
     forged inheritance certificates) IN ADDITION to the sale deed → 
     those fabricated documents ARE false documents.
  4. Post-BNS cases without first checking whether the new statutory 
     language changes the analysis.

THE KILLER PARAGRAPH: ¶12 —
  "There is a fundamental difference between a person executing a sale 
  deed claiming that the property conveyed is his property, and a person 
  executing a sale deed by impersonating the owner or falsely claiming 
  to be authorised or empowered by the owner, to execute the deed on 
  owner's behalf."

THE HIDDEN GEM: ¶16 —
  The catalogue of THIRTEEN specific fraudulent acts made punishable 
  under the IPC. Most practitioners miss this paragraph, but it contains 
  the complete taxonomy of criminal fraud under the Code — invaluable 
  for both prosecution and defence in any fraud-related case. It also 
  implicitly suggests that S.423 (fraudulent execution of deed with 
  false statement) COULD have been charged but wasn't.
```

---

## 5.4 QUESTIONS THIS JUDGMENT CREATES

**NEW QUESTION 1:**
```
The Question                          : If a non-owner sells property to a GENUINE (non-
                                        colluding) purchaser, and the purchaser later discovers
                                        the fraud, does the purchaser have a case under S.420
                                        EVEN IF the true owner had already filed a complaint that
                                        was quashed under Md. Ibrahim?
Why It Didn't Exist Before            : Before this judgment, both true owners and purchasers
                                        routinely filed combined complaints. This judgment
                                        SPLITS their remedies — creating the question of
                                        whether they can file sequentially.
Who Will Raise It First               : A cheated purchaser whose initial complaint was clubbed
                                        with the true owner's complaint and quashed together.
Likely Forum                          : Criminal Revision or S.482 CrPC petition before HC.
```

**NEW QUESTION 2:**
```
The Question                          : Can the Sub-Registrar (or the State on his behalf) file
                                        a complaint of cheating against a person who presented a
                                        sale deed for registration while falsely representing
                                        himself as the owner?
Why It Didn't Exist Before            : Nobody had previously separated the Sub-Registrar as an
                                        independent victim. This question is a DIRECT consequence
                                        of the court's locus analysis.
Who Will Raise It First               : An aggressive prosecution or a State seeking to combat
                                        organized land fraud.
Likely Forum                          : Magistrate's Court → potentially High Court.
```

**NEW QUESTION 3:**
```
The Question                          : Does the corresponding provision in the BNS (Bharatiya
                                        Nyaya Sanhita, 2023) have different or broader language
                                        than S.464 IPC, such that the Md. Ibrahim principle
                                        does NOT apply to offences committed after 01.07.2024?
Why It Didn't Exist Before            : The BNS didn't exist in 2009.
Who Will Raise It First               : Any prosecution opposing a quashing petition in a
                                        post-BNS property fraud case.
Likely Forum                          : High Courts across India, eventually Supreme Court.
```

**NEW QUESTION 4:**
```
The Question                          : If the true owner is left with ONLY civil remedies, but
                                        civil litigation takes 15-20 years in India, is the
                                        Md. Ibrahim framework constitutionally adequate? Does the
                                        absence of a criminal remedy for the true owner violate
                                        Article 21 (right to property as a facet of livelihood)?
Why It Didn't Exist Before            : This question emerges from the COMBINED effect of
                                        Md. Ibrahim (no criminal remedy) + systemic civil court
                                        delays.
Who Will Raise It First               : A PIL or a constitutional challenge by an affected
                                        true owner.
Likely Forum                          : High Court (PIL) → Supreme Court.
```

---

## 5.5 EXTRACTION CONFIDENCE & METADATA

```
Overall Confidence     : HIGH
Sections With Highest
Uncertainty            : 3.1 (Hidden Assumptions) and 3.5 (Alternative Interpretations)
                         — these involve analytical inference beyond the judgment text.
                         4.6 (Temporal Vulnerability) — BNS analysis requires
                         separate statutory comparison not available in this judgment.
Judgment Clarity Grade : A — Exceptionally well-written. Clear logical structure,
                         explicit reasoning, minimal ambiguity. Justice Raveendran
                         writes with a professor's clarity.
Extraction Limitations : (1) The BNS comparison could not be performed from the
                         judgment text alone. (2) Post-2009 judicial treatment
                         (whether this judgment has been followed, distinguished,
                         or doubted) requires external research. (3) The "silent
                         arguments" are analytical contributions of the extractor,
                         not findings from the judgment.
```

---

*Extracted using the Judgment Genome Project™ Framework v2.0*
*Source: Md. Ibrahim & Ors vs State of Bihar & Anr, (2009) 8 SCC 751*
*Indian Kanoon: http://indiankanoon.org/doc/409057/*
